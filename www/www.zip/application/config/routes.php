<?php

$config['_default'] = "main/index";
$config['collection'] = "main/collection";
$config["recipes"] = "main/recipes";
$config["partners"] = "main/partners";
$config["contacts"] = "main/contacts";


?>
