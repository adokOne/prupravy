<?php

class Main_Controller extends Controller {



	public function index() {
		$this->set_meta("main");
		$view = new View("main");
		$view->lang    =  Kohana::lang("main") ;
		$view->render(true);
	}
	public function collection() {
		$this->set_meta("collection");
		stylesheet::add(array("fancybox"));
		$view = new View("collection");
		$view->collection = $this->get_collection();
		$view->lang    =  Kohana::lang("main") ;
		$view->render(true);
	}
	public function recipes() {
		$this->set_meta("recipes");
		stylesheet::add(array("fancybox"));
		$view = new View("recipes");
		$view->collection = $this->get_recipes();
		$view->lang    =  Kohana::lang("main") ;
		$view->render(true);
	}

	public function partners() {
		$this->set_meta("partners");
		$view = new View("partners");
		$view->collection = $this->get_collection();
		$view->lang    =  Kohana::lang("main") ;
		$view->render(true);
	}

	public function contacts(){
		$this->set_meta("contacts");
		$view = new View("contacts");
		$view->lang    =  Kohana::lang("main") ;
		$view->render(true);
	}


	public function load_price(){
		$collection = $this->get_collection();
	}


	private function set_meta($seo){
		$page = ORM::factory("page")->where("seo_name",$seo)->find();
		Router::$site_title = $page->title();
		Router::$site_description = $page->desc();
		Router::$site_keywords = $page->keyw();
	}









	public function get_product_desc($id){
		$product = ORM::factory("product")->find($id);
		$view = new View("product_box");
		$view->product = $product;
		$view->lang    =  Kohana::lang("main") ;
		echo json_encode(array("success"=>true,"html"=>$view->render()));
	}
	public function get_recept_desc($id){
		$product = ORM::factory("recip")->find($id);
		$view = new View("recept_box");
		$view->recept = $product;
		$view->lang    =  Kohana::lang("main") ;
		echo json_encode(array("success"=>true,"html"=>$view->render()));
	}



	private function get_collection(){
		return ORM::factory("product")->find_all();
	}
	private function get_recipes(){
		return ORM::factory("recip")->find_all();
	}



	
}