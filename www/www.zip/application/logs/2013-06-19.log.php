2013-06-19 03:43:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-06-19 03:43:23 +03:00 --- debug: Session Library initialized
2013-06-19 03:43:23 +03:00 --- debug: Auth Library loaded
2013-06-19 03:43:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-06-19 03:43:23 +03:00 --- debug: Database Library initialized
2013-06-19 03:43:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-06-19 03:43:23 +03:00 --- debug: Database Library initialized
2013-06-19 03:49:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-06-19 03:49:28 +03:00 --- debug: Session Library initialized
2013-06-19 03:49:28 +03:00 --- debug: Auth Library loaded
2013-06-19 03:49:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-06-19 03:49:28 +03:00 --- debug: Database Library initialized
2013-06-19 03:49:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-06-19 03:49:28 +03:00 --- debug: Database Library initialized
2013-06-19 03:52:59 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Table 'dj_one.news' doesn't exist - SHOW COLUMNS FROM `news` в файле /home/adok/WWW/biluk.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-06-19 03:55:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-06-19 03:55:29 +03:00 --- debug: Session Library initialized
2013-06-19 03:55:29 +03:00 --- debug: Auth Library loaded
2013-06-19 03:55:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-06-19 03:55:29 +03:00 --- debug: Database Library initialized
2013-06-19 03:55:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-06-19 03:55:29 +03:00 --- debug: Database Library initialized
2013-06-19 03:58:46 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Table 'dj_one.news' doesn't exist - SHOW COLUMNS FROM `news` в файле /home/adok/WWW/biluk.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-06-19 04:00:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-06-19 04:00:40 +03:00 --- debug: Session Library initialized
2013-06-19 04:00:40 +03:00 --- debug: Auth Library loaded
2013-06-19 04:00:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-06-19 04:00:40 +03:00 --- debug: Database Library initialized
2013-06-19 04:00:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-06-19 04:00:40 +03:00 --- debug: Database Library initialized
2013-06-19 04:04:55 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Table 'dj_one.news' doesn't exist - SHOW COLUMNS FROM `news` в файле /home/adok/WWW/biluk.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-06-19 04:07:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-06-19 04:07:58 +03:00 --- debug: Session Library initialized
2013-06-19 04:07:58 +03:00 --- debug: Auth Library loaded
2013-06-19 04:07:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-06-19 04:07:58 +03:00 --- debug: Database Library initialized
2013-06-19 04:07:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-06-19 04:07:58 +03:00 --- debug: Database Library initialized
2013-06-19 04:09:35 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Table 'dj_one.news' doesn't exist - SHOW COLUMNS FROM `news` в файле /home/adok/WWW/biluk.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-06-19 04:13:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-06-19 04:13:12 +03:00 --- debug: Session Library initialized
2013-06-19 04:13:12 +03:00 --- debug: Auth Library loaded
2013-06-19 04:13:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-06-19 04:13:12 +03:00 --- debug: Database Library initialized
2013-06-19 04:13:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-06-19 04:13:12 +03:00 --- debug: Database Library initialized
2013-06-19 04:13:35 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Table 'dj_one.news' doesn't exist - SHOW COLUMNS FROM `news` в файле /home/adok/WWW/biluk.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-06-19 04:15:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-06-19 04:15:29 +03:00 --- debug: Session Library initialized
2013-06-19 04:15:29 +03:00 --- debug: Auth Library loaded
2013-06-19 04:15:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-06-19 04:15:29 +03:00 --- debug: Database Library initialized
2013-06-19 04:15:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-06-19 04:15:29 +03:00 --- debug: Database Library initialized
2013-06-19 04:15:53 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Table 'dj_one.news' doesn't exist - SHOW COLUMNS FROM `news` в файле /home/adok/WWW/biluk.local/system/libraries/drivers/Database/Mysql.php, на строке 371
