<?php defined('SYSPATH') or die('No direct script access.'); ?>

2013-07-16 11:55:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-07-16 11:55:52 +03:00 --- debug: Session Library initialized
2013-07-16 11:55:52 +03:00 --- debug: Auth Library loaded
2013-07-16 11:55:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-07-16 11:55:52 +03:00 --- debug: Database Library initialized
2013-07-16 11:55:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-07-16 11:55:52 +03:00 --- debug: Database Library initialized
2013-07-16 11:55:58 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Table 'dj_one.news' doesn't exist - SHOW COLUMNS FROM `news` в файле /home/adok/WWW/biluk.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-07-16 11:55:58 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/biluk.local/system/core/Kohana.php, на строке 862
