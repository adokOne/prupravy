<?php defined('SYSPATH') or die('No direct script access.'); ?>

2013-08-06 11:01:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:01:21 +03:00 --- debug: Session Library initialized
2013-08-06 11:01:21 +03:00 --- debug: Auth Library loaded
2013-08-06 11:01:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:01:21 +03:00 --- debug: Database Library initialized
2013-08-06 11:01:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:01:21 +03:00 --- debug: Database Library initialized
2013-08-06 11:01:28 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Table 'dj_one.news' doesn't exist - SHOW COLUMNS FROM `news` в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 11:01:28 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:02:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:02:34 +03:00 --- debug: Session Library initialized
2013-08-06 11:02:34 +03:00 --- debug: Auth Library loaded
2013-08-06 11:02:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:02:34 +03:00 --- debug: Database Library initialized
2013-08-06 11:02:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:02:34 +03:00 --- debug: Database Library initialized
2013-08-06 11:02:40 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Table 'do_smaky.de_types' doesn't exist - SELECT *
FROM (`de_types`) в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 11:02:40 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:06:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:06:20 +03:00 --- debug: Session Library initialized
2013-08-06 11:06:20 +03:00 --- debug: Auth Library loaded
2013-08-06 11:06:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:06:20 +03:00 --- debug: Database Library initialized
2013-08-06 11:06:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:06:20 +03:00 --- debug: Database Library initialized
2013-08-06 11:06:20 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Table 'do_smaky.de_types' doesn't exist - SELECT *
FROM (`de_types`) в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 11:06:20 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:06:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:06:23 +03:00 --- debug: Session Library initialized
2013-08-06 11:06:23 +03:00 --- debug: Auth Library loaded
2013-08-06 11:06:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:06:23 +03:00 --- debug: Database Library initialized
2013-08-06 11:06:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:06:23 +03:00 --- debug: Database Library initialized
2013-08-06 11:06:23 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Table 'do_smaky.de_types' doesn't exist - SELECT *
FROM (`de_types`) в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 11:06:23 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:06:59 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, main/index, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:06:59 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:07:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:07:46 +03:00 --- debug: Database Library initialized
2013-08-06 11:07:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:07:46 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:08:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:08:04 +03:00 --- debug: Database Library initialized
2013-08-06 11:08:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:08:04 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:13:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:13:52 +03:00 --- debug: Database Library initialized
2013-08-06 11:13:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:13:52 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:14:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:14:11 +03:00 --- debug: Database Library initialized
2013-08-06 11:14:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:14:11 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:15:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:15:13 +03:00 --- debug: Database Library initialized
2013-08-06 11:15:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:15:13 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:16:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:16:36 +03:00 --- debug: Database Library initialized
2013-08-06 11:16:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:16:36 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:16:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:16:55 +03:00 --- debug: Database Library initialized
2013-08-06 11:16:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:16:55 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, js/cufon-yui.js, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:16:55 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, js/OfficinaSansC_700.font.js, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:16:55 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, js/cufon-settings.js, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:16:55 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:17:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:17:16 +03:00 --- debug: Database Library initialized
2013-08-06 11:17:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:17:16 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:19:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:19:36 +03:00 --- debug: Database Library initialized
2013-08-06 11:19:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:19:36 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:19:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:19:59 +03:00 --- debug: Database Library initialized
2013-08-06 11:19:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:19:59 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:20:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:20:12 +03:00 --- debug: Database Library initialized
2013-08-06 11:20:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:20:12 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:34:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:34:39 +03:00 --- debug: Database Library initialized
2013-08-06 11:34:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:34:40 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:36:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:36:14 +03:00 --- debug: Database Library initialized
2013-08-06 11:36:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:36:15 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:36:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:36:40 +03:00 --- debug: Database Library initialized
2013-08-06 11:36:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:36:40 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:37:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:37:43 +03:00 --- debug: Database Library initialized
2013-08-06 11:37:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:37:43 +03:00 --- error: Не пойманное PHP Error: var_dump() expects at least 1 parameter, 0 given в файле /home/adok/WWW/prupravy.local/application/views/header.php, на строке 14
2013-08-06 11:37:43 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:37:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:37:49 +03:00 --- debug: Database Library initialized
2013-08-06 11:37:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:37:49 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:40:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:40:35 +03:00 --- debug: Database Library initialized
2013-08-06 11:40:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:40:35 +03:00 --- error: Не пойманное PHP Error: Undefined index: menu в файле /home/adok/WWW/prupravy.local/application/views/header.php, на строке 29
2013-08-06 11:40:35 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:40:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:40:52 +03:00 --- debug: Database Library initialized
2013-08-06 11:40:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:40:52 +03:00 --- error: Не пойманное PHP Error: Undefined index: menu в файле /home/adok/WWW/prupravy.local/application/views/header.php, на строке 29
2013-08-06 11:40:52 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:42:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:42:04 +03:00 --- debug: Database Library initialized
2013-08-06 11:42:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:42:04 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:42:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:42:11 +03:00 --- debug: Database Library initialized
2013-08-06 11:42:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:42:12 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:42:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:42:34 +03:00 --- debug: Database Library initialized
2013-08-06 11:42:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:42:34 +03:00 --- error: Не пойманное PHP Error: Undefined index: menu в файле /home/adok/WWW/prupravy.local/application/views/header.php, на строке 29
2013-08-06 11:42:34 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:42:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:42:58 +03:00 --- debug: Database Library initialized
2013-08-06 11:42:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:42:58 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:43:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:43:21 +03:00 --- debug: Database Library initialized
2013-08-06 11:43:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:43:21 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:44:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:44:28 +03:00 --- debug: Database Library initialized
2013-08-06 11:44:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:44:28 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:46:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:46:55 +03:00 --- debug: Database Library initialized
2013-08-06 11:46:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:46:55 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:48:41 +03:00 --- error: Не пойманное Kohana_Exception: Запрошенный конфигурация, ignore, не найден в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 1189
2013-08-06 11:48:41 +03:00 --- error: Не пойманное Kohana_Exception: Запрошенный конфигурация, ignore, не найден в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 1189
2013-08-06 11:49:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:49:03 +03:00 --- debug: Session Library initialized
2013-08-06 11:49:03 +03:00 --- debug: Auth Library loaded
2013-08-06 11:49:03 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, gd_main/index, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:49:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:49:03 +03:00 --- debug: Session Library initialized
2013-08-06 11:49:03 +03:00 --- debug: Auth Library loaded
2013-08-06 11:49:03 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, gd_favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:49:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:49:49 +03:00 --- debug: Session Library initialized
2013-08-06 11:49:49 +03:00 --- debug: Auth Library loaded
2013-08-06 11:49:49 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, _main/index, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:49:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:49:49 +03:00 --- debug: Session Library initialized
2013-08-06 11:49:49 +03:00 --- debug: Auth Library loaded
2013-08-06 11:49:49 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, _favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:50:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:50:43 +03:00 --- debug: Session Library initialized
2013-08-06 11:50:43 +03:00 --- debug: Auth Library loaded
2013-08-06 11:50:43 +03:00 --- error: Missing i18n entry core.vendor for language ru_RU
2013-08-06 11:50:43 +03:00 --- error: Не пойманное Kohana_Exception: Запрошенный core.vendor, htmlpurifier/HTMLPurifier.auto, не найден в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 1189
2013-08-06 11:50:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:50:43 +03:00 --- debug: Session Library initialized
2013-08-06 11:50:43 +03:00 --- debug: Auth Library loaded
2013-08-06 11:50:43 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:51:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:51:08 +03:00 --- debug: Session Library initialized
2013-08-06 11:51:08 +03:00 --- debug: Auth Library loaded
2013-08-06 11:51:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:51:08 +03:00 --- debug: Database Library initialized
2013-08-06 11:51:08 +03:00 --- error: Не пойманное PHP Error: Undefined variable: lang_lc в файле /home/adok/WWW/prupravy.local/application/views/header.php, на строке 24
2013-08-06 11:51:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:51:08 +03:00 --- debug: Session Library initialized
2013-08-06 11:51:08 +03:00 --- debug: Auth Library loaded
2013-08-06 11:51:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:51:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:51:34 +03:00 --- debug: Session Library initialized
2013-08-06 11:51:34 +03:00 --- debug: Auth Library loaded
2013-08-06 11:51:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:51:34 +03:00 --- debug: Database Library initialized
2013-08-06 11:51:34 +03:00 --- error: Не пойманное PHP Error: Undefined variable: lang_lc в файле /home/adok/WWW/prupravy.local/application/views/header.php, на строке 24
2013-08-06 11:51:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:51:34 +03:00 --- debug: Session Library initialized
2013-08-06 11:51:34 +03:00 --- debug: Auth Library loaded
2013-08-06 11:51:34 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:51:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:51:46 +03:00 --- debug: Session Library initialized
2013-08-06 11:51:46 +03:00 --- debug: Auth Library loaded
2013-08-06 11:51:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:51:46 +03:00 --- debug: Database Library initialized
2013-08-06 11:51:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:51:46 +03:00 --- debug: Session Library initialized
2013-08-06 11:51:46 +03:00 --- debug: Auth Library loaded
2013-08-06 11:51:46 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:53:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:53:26 +03:00 --- debug: Session Library initialized
2013-08-06 11:53:26 +03:00 --- debug: Auth Library loaded
2013-08-06 11:53:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:53:26 +03:00 --- debug: Database Library initialized
2013-08-06 11:53:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:53:26 +03:00 --- debug: Session Library initialized
2013-08-06 11:53:26 +03:00 --- debug: Auth Library loaded
2013-08-06 11:53:26 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:53:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:53:48 +03:00 --- debug: Session Library initialized
2013-08-06 11:53:48 +03:00 --- debug: Auth Library loaded
2013-08-06 11:53:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:53:48 +03:00 --- debug: Database Library initialized
2013-08-06 11:53:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:53:49 +03:00 --- debug: Session Library initialized
2013-08-06 11:53:49 +03:00 --- debug: Auth Library loaded
2013-08-06 11:53:49 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:53:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:53:53 +03:00 --- debug: Session Library initialized
2013-08-06 11:53:53 +03:00 --- debug: Auth Library loaded
2013-08-06 11:53:53 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, ua, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:53:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:53:53 +03:00 --- debug: Session Library initialized
2013-08-06 11:53:53 +03:00 --- debug: Auth Library loaded
2013-08-06 11:53:53 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:54:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:54:00 +03:00 --- debug: Session Library initialized
2013-08-06 11:54:00 +03:00 --- debug: Auth Library loaded
2013-08-06 11:54:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:54:00 +03:00 --- debug: Database Library initialized
2013-08-06 11:54:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:54:01 +03:00 --- debug: Session Library initialized
2013-08-06 11:54:01 +03:00 --- debug: Auth Library loaded
2013-08-06 11:54:01 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:54:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:54:05 +03:00 --- debug: Session Library initialized
2013-08-06 11:54:05 +03:00 --- debug: Auth Library loaded
2013-08-06 11:54:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:54:05 +03:00 --- debug: Database Library initialized
2013-08-06 11:54:05 +03:00 --- error: Uncaught PHP Error: Undefined index: menu in file /home/adok/WWW/prupravy.local/application/views/header.php on line 29
2013-08-06 11:54:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:54:05 +03:00 --- debug: Session Library initialized
2013-08-06 11:54:05 +03:00 --- debug: Auth Library loaded
2013-08-06 11:54:05 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:54:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:54:08 +03:00 --- debug: Session Library initialized
2013-08-06 11:54:08 +03:00 --- debug: Auth Library loaded
2013-08-06 11:54:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:54:08 +03:00 --- debug: Database Library initialized
2013-08-06 11:54:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:54:08 +03:00 --- debug: Session Library initialized
2013-08-06 11:54:08 +03:00 --- debug: Auth Library loaded
2013-08-06 11:54:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:54:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:54:09 +03:00 --- debug: Session Library initialized
2013-08-06 11:54:09 +03:00 --- debug: Auth Library loaded
2013-08-06 11:54:09 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, ua, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:54:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:54:09 +03:00 --- debug: Session Library initialized
2013-08-06 11:54:09 +03:00 --- debug: Auth Library loaded
2013-08-06 11:54:09 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:54:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:54:20 +03:00 --- debug: Session Library initialized
2013-08-06 11:54:20 +03:00 --- debug: Auth Library loaded
2013-08-06 11:54:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:54:20 +03:00 --- debug: Database Library initialized
2013-08-06 11:54:20 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-06 11:54:20 +03:00 --- error: core.uncaught_exception
2013-08-06 11:54:20 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-06 11:54:20 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-06 11:54:20 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-06 11:54:20 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-06 11:54:20 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-06 11:54:20 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-06 11:54:20 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-06 11:54:20 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-06 11:54:20 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-06 11:54:20 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-06 11:54:20 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-06 11:54:20 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-06 11:54:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:54:20 +03:00 --- debug: Session Library initialized
2013-08-06 11:54:20 +03:00 --- debug: Auth Library loaded
2013-08-06 11:54:20 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:54:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:54:23 +03:00 --- debug: Session Library initialized
2013-08-06 11:54:23 +03:00 --- debug: Auth Library loaded
2013-08-06 11:54:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:54:23 +03:00 --- debug: Database Library initialized
2013-08-06 11:54:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:54:23 +03:00 --- debug: Session Library initialized
2013-08-06 11:54:23 +03:00 --- debug: Auth Library loaded
2013-08-06 11:54:23 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 11:54:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:54:52 +03:00 --- debug: Session Library initialized
2013-08-06 11:54:52 +03:00 --- debug: Auth Library loaded
2013-08-06 11:54:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 11:54:52 +03:00 --- debug: Database Library initialized
2013-08-06 11:54:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 11:54:52 +03:00 --- debug: Session Library initialized
2013-08-06 11:54:52 +03:00 --- debug: Auth Library loaded
2013-08-06 11:54:52 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:10:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:10:20 +03:00 --- debug: Session Library initialized
2013-08-06 12:10:20 +03:00 --- debug: Auth Library loaded
2013-08-06 12:10:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:10:20 +03:00 --- debug: Database Library initialized
2013-08-06 12:10:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:10:21 +03:00 --- debug: Session Library initialized
2013-08-06 12:10:21 +03:00 --- debug: Auth Library loaded
2013-08-06 12:10:21 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:11:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:11:11 +03:00 --- debug: Session Library initialized
2013-08-06 12:11:11 +03:00 --- debug: Auth Library loaded
2013-08-06 12:11:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:11:11 +03:00 --- debug: Database Library initialized
2013-08-06 12:11:11 +03:00 --- error: Не пойманное PHP Error: Use of undefined constant php - assumed 'php' в файле /home/adok/WWW/prupravy.local/application/views/header.php, на строке 6
2013-08-06 12:11:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:11:11 +03:00 --- debug: Session Library initialized
2013-08-06 12:11:11 +03:00 --- debug: Auth Library loaded
2013-08-06 12:11:11 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:11:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:11:27 +03:00 --- debug: Session Library initialized
2013-08-06 12:11:27 +03:00 --- debug: Auth Library loaded
2013-08-06 12:11:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:11:27 +03:00 --- debug: Database Library initialized
2013-08-06 12:11:27 +03:00 --- error: Не пойманное PHP Error: Use of undefined constant php - assumed 'php' в файле /home/adok/WWW/prupravy.local/application/views/header.php, на строке 6
2013-08-06 12:11:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:11:27 +03:00 --- debug: Session Library initialized
2013-08-06 12:11:27 +03:00 --- debug: Auth Library loaded
2013-08-06 12:11:27 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:11:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:11:54 +03:00 --- debug: Session Library initialized
2013-08-06 12:11:54 +03:00 --- debug: Auth Library loaded
2013-08-06 12:11:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:11:54 +03:00 --- debug: Database Library initialized
2013-08-06 12:11:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:11:55 +03:00 --- debug: Session Library initialized
2013-08-06 12:11:55 +03:00 --- debug: Auth Library loaded
2013-08-06 12:11:55 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:12:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:12:57 +03:00 --- debug: Session Library initialized
2013-08-06 12:12:57 +03:00 --- debug: Auth Library loaded
2013-08-06 12:12:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:12:57 +03:00 --- debug: Database Library initialized
2013-08-06 12:12:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:12:57 +03:00 --- debug: Session Library initialized
2013-08-06 12:12:57 +03:00 --- debug: Auth Library loaded
2013-08-06 12:12:57 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:13:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:13:55 +03:00 --- debug: Session Library initialized
2013-08-06 12:13:55 +03:00 --- debug: Auth Library loaded
2013-08-06 12:13:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:13:55 +03:00 --- debug: Database Library initialized
2013-08-06 12:13:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:13:55 +03:00 --- debug: Session Library initialized
2013-08-06 12:13:55 +03:00 --- debug: Auth Library loaded
2013-08-06 12:13:55 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:17:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:17:33 +03:00 --- debug: Session Library initialized
2013-08-06 12:17:33 +03:00 --- debug: Auth Library loaded
2013-08-06 12:17:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:17:33 +03:00 --- debug: Database Library initialized
2013-08-06 12:17:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:17:34 +03:00 --- debug: Session Library initialized
2013-08-06 12:17:34 +03:00 --- debug: Auth Library loaded
2013-08-06 12:17:34 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:17:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:17:52 +03:00 --- debug: Session Library initialized
2013-08-06 12:17:52 +03:00 --- debug: Auth Library loaded
2013-08-06 12:17:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:17:52 +03:00 --- debug: Database Library initialized
2013-08-06 12:17:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:17:52 +03:00 --- debug: Session Library initialized
2013-08-06 12:17:52 +03:00 --- debug: Auth Library loaded
2013-08-06 12:17:52 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:20:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:20:49 +03:00 --- debug: Session Library initialized
2013-08-06 12:20:49 +03:00 --- debug: Auth Library loaded
2013-08-06 12:20:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:20:49 +03:00 --- debug: Database Library initialized
2013-08-06 12:20:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:20:50 +03:00 --- debug: Session Library initialized
2013-08-06 12:20:50 +03:00 --- debug: Auth Library loaded
2013-08-06 12:20:50 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:20:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:20:51 +03:00 --- debug: Session Library initialized
2013-08-06 12:20:51 +03:00 --- debug: Auth Library loaded
2013-08-06 12:20:51 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, collection, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:20:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:20:51 +03:00 --- debug: Session Library initialized
2013-08-06 12:20:51 +03:00 --- debug: Auth Library loaded
2013-08-06 12:20:51 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:21:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:21:04 +03:00 --- debug: Session Library initialized
2013-08-06 12:21:04 +03:00 --- debug: Auth Library loaded
2013-08-06 12:21:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:21:04 +03:00 --- debug: Database Library initialized
2013-08-06 12:21:04 +03:00 --- error: Не пойманное Kohana_Exception: Запрошенный вид, collection, не найден в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 1189
2013-08-06 12:21:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:21:04 +03:00 --- debug: Session Library initialized
2013-08-06 12:21:04 +03:00 --- debug: Auth Library loaded
2013-08-06 12:21:04 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:21:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:21:29 +03:00 --- debug: Session Library initialized
2013-08-06 12:21:29 +03:00 --- debug: Auth Library loaded
2013-08-06 12:21:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:21:29 +03:00 --- debug: Database Library initialized
2013-08-06 12:21:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:21:29 +03:00 --- debug: Session Library initialized
2013-08-06 12:21:29 +03:00 --- debug: Auth Library loaded
2013-08-06 12:21:29 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:21:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:21:47 +03:00 --- debug: Session Library initialized
2013-08-06 12:21:47 +03:00 --- debug: Auth Library loaded
2013-08-06 12:21:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:21:47 +03:00 --- debug: Database Library initialized
2013-08-06 12:21:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:21:47 +03:00 --- debug: Session Library initialized
2013-08-06 12:21:47 +03:00 --- debug: Auth Library loaded
2013-08-06 12:21:47 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:22:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:22:25 +03:00 --- debug: Session Library initialized
2013-08-06 12:22:25 +03:00 --- debug: Auth Library loaded
2013-08-06 12:22:25 +03:00 --- debug:2013-08-06 12:37:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:37:26 +03:00 --- debug: Session Library initialized
2013-08-06 12:37:26 +03:00 --- debug: Auth Library loaded
2013-08-06 12:37:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:37:26 +03:00 --- debug: Database Library initialized
2013-08-06 12:37:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:37:27 +03:00 --- debug: Session Library initialized
2013-08-06 12:37:27 +03:00 --- debug: Auth Library loaded
2013-08-06 12:37:27 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:39:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:39:46 +03:00 --- debug: Session Library initialized
2013-08-06 12:39:46 +03:00 --- debug: Auth Library loaded
2013-08-06 12:39:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:39:46 +03:00 --- debug: Database Library initialized
2013-08-06 12:39:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:39:47 +03:00 --- debug: Session Library initialized
2013-08-06 12:39:47 +03:00 --- debug: Auth Library loaded
2013-08-06 12:39:47 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:39:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:39:50 +03:00 --- debug: Session Library initialized
2013-08-06 12:39:50 +03:00 --- debug: Auth Library loaded
2013-08-06 12:39:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:39:50 +03:00 --- debug: Database Library initialized
2013-08-06 12:39:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:39:50 +03:00 --- debug: Session Library initialized
2013-08-06 12:39:50 +03:00 --- debug: Auth Library loaded
2013-08-06 12:39:50 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:39:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:39:55 +03:00 --- debug: Session Library initialized
2013-08-06 12:39:55 +03:00 --- debug: Auth Library loaded
2013-08-06 12:39:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:39:55 +03:00 --- debug: Database Library initialized
2013-08-06 12:39:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:39:55 +03:00 --- debug: Session Library initialized
2013-08-06 12:39:55 +03:00 --- debug: Auth Library loaded
2013-08-06 12:39:55 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/logo.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:39:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:39:55 +03:00 --- debug: Session Library initialized
2013-08-06 12:39:55 +03:00 --- debug: Auth Library loaded
2013-08-06 12:39:55 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:40:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:40:01 +03:00 --- debug: Session Library initialized
2013-08-06 12:40:01 +03:00 --- debug: Auth Library loaded
2013-08-06 12:40:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:40:01 +03:00 --- debug: Database Library initialized
2013-08-06 12:40:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:40:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:40:01 +03:00 --- debug: Database Library initialized
2013-08-06 12:40:01 +03:00 --- debug: Session Library initialized
2013-08-06 12:40:01 +03:00 --- debug: Auth Library loaded
2013-08-06 12:40:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:40:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:40:01 +03:00 --- debug: Database Library initialized
2013-08-06 12:40:01 +03:00 --- debug: Session Library initialized
2013-08-06 12:40:01 +03:00 --- debug: Auth Library loaded
2013-08-06 12:40:01 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:40:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:40:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:40:08 +03:00 --- debug: Database Library initialized
2013-08-06 12:40:08 +03:00 --- debug: Session Library initialized
2013-08-06 12:40:08 +03:00 --- debug: Auth Library loaded
2013-08-06 12:40:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:40:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:40:08 +03:00 --- debug: Database Library initialized
2013-08-06 12:40:08 +03:00 --- debug: Session Library initialized
2013-08-06 12:40:08 +03:00 --- debug: Auth Library loaded
2013-08-06 12:40:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:40:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:40:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:40:11 +03:00 --- debug: Database Library initialized
2013-08-06 12:40:11 +03:00 --- debug: Session Library initialized
2013-08-06 12:40:11 +03:00 --- debug: Auth Library loaded
2013-08-06 12:40:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:40:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:40:11 +03:00 --- debug: Database Library initialized
2013-08-06 12:40:11 +03:00 --- debug: Session Library initialized
2013-08-06 12:40:11 +03:00 --- debug: Auth Library loaded
2013-08-06 12:40:11 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:41:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:41:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:41:58 +03:00 --- debug: Database Library initialized
2013-08-06 12:41:58 +03:00 --- debug: Session Library initialized
2013-08-06 12:41:58 +03:00 --- debug: Auth Library loaded
2013-08-06 12:41:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:41:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:41:58 +03:00 --- debug: Database Library initialized
2013-08-06 12:41:58 +03:00 --- debug: Session Library initialized
2013-08-06 12:41:58 +03:00 --- debug: Auth Library loaded
2013-08-06 12:41:58 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:42:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:42:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:42:14 +03:00 --- debug: Database Library initialized
2013-08-06 12:42:14 +03:00 --- debug: Session Library initialized
2013-08-06 12:42:14 +03:00 --- debug: Auth Library loaded
2013-08-06 12:42:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:42:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:42:14 +03:00 --- debug: Database Library initialized
2013-08-06 12:42:14 +03:00 --- debug: Session Library initialized
2013-08-06 12:42:14 +03:00 --- debug: Auth Library loaded
2013-08-06 12:42:14 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:47:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:47:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:47:34 +03:00 --- debug: Database Library initialized
2013-08-06 12:47:34 +03:00 --- debug: Session Library initialized
2013-08-06 12:47:34 +03:00 --- debug: Auth Library loaded
2013-08-06 12:47:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:47:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:47:34 +03:00 --- debug: Database Library initialized
2013-08-06 12:47:34 +03:00 --- debug: Session Library initialized
2013-08-06 12:47:34 +03:00 --- debug: Auth Library loaded
2013-08-06 12:47:34 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:47:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:47:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:47:38 +03:00 --- debug: Database Library initialized
2013-08-06 12:47:38 +03:00 --- debug: Session Library initialized
2013-08-06 12:47:38 +03:00 --- debug: Auth Library loaded
2013-08-06 12:47:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:47:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:47:38 +03:00 --- debug: Database Library initialized
2013-08-06 12:47:38 +03:00 --- debug: Session Library initialized
2013-08-06 12:47:38 +03:00 --- debug: Auth Library loaded
2013-08-06 12:47:38 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:47:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:47:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:47:39 +03:00 --- debug: Database Library initialized
2013-08-06 12:47:39 +03:00 --- debug: Session Library initialized
2013-08-06 12:47:39 +03:00 --- debug: Auth Library loaded
2013-08-06 12:47:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:47:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:47:39 +03:00 --- debug: Database Library initialized
2013-08-06 12:47:39 +03:00 --- debug: Session Library initialized
2013-08-06 12:47:39 +03:00 --- debug: Auth Library loaded
2013-08-06 12:47:39 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:47:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:47:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:47:42 +03:00 --- debug: Database Library initialized
2013-08-06 12:47:42 +03:00 --- debug: Session Library initialized
2013-08-06 12:47:42 +03:00 --- debug: Auth Library loaded
2013-08-06 12:47:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:47:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:47:42 +03:00 --- debug: Database Library initialized
2013-08-06 12:47:42 +03:00 --- debug: Session Library initialized
2013-08-06 12:47:42 +03:00 --- debug: Auth Library loaded
2013-08-06 12:47:42 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:47:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:47:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:47:44 +03:00 --- debug: Database Library initialized
2013-08-06 12:47:44 +03:00 --- debug: Session Library initialized
2013-08-06 12:47:44 +03:00 --- debug: Auth Library loaded
2013-08-06 12:47:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:47:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:47:45 +03:00 --- debug: Database Library initialized
2013-08-06 12:47:45 +03:00 --- debug: Session Library initialized
2013-08-06 12:47:45 +03:00 --- debug: Auth Library loaded
2013-08-06 12:47:45 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:51:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:04 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:04 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:04 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:04 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:04 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:04 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:04 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:51:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:05 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:05 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:05 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:05 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:05 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:05 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:05 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:51:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:05 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:05 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:05 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:05 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:05 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:05 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:05 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:51:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:05 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:05 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:05 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:05 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:05 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:05 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:05 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:51:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:05 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:05 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:05 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:05 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:05 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:05 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:05 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:51:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:06 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:06 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:06 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:06 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:06 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:06 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:06 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:51:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:23 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:23 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:23 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:23 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:23 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:23 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:23 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:51:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:23 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:23 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:23 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:23 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:23 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:23 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:23 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:51:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:24 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:24 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:24 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:24 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:24 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:24 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:24 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:51:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:24 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:24 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:24 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:24 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:24 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:24 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:24 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:51:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:24 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:24 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:24 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:24 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:24 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:24 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:24 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:51:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:27 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:27 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:27 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:27 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:27 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:27 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:27 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:51:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:29 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:29 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:29 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:30 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:30 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:30 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:30 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:51:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:39 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:39 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:39 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:39 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:39 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:39 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:39 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:51:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:44 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:44 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:44 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:51:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:51:44 +03:00 --- debug: Database Library initialized
2013-08-06 12:51:44 +03:00 --- debug: Session Library initialized
2013-08-06 12:51:44 +03:00 --- debug: Auth Library loaded
2013-08-06 12:51:44 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:52:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:52:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:52:07 +03:00 --- debug: Database Library initialized
2013-08-06 12:52:07 +03:00 --- debug: Session Library initialized
2013-08-06 12:52:07 +03:00 --- debug: Auth Library loaded
2013-08-06 12:52:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:52:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:52:08 +03:00 --- debug: Database Library initialized
2013-08-06 12:52:08 +03:00 --- debug: Session Library initialized
2013-08-06 12:52:08 +03:00 --- debug: Auth Library loaded
2013-08-06 12:52:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:52:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:52:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:52:16 +03:00 --- debug: Database Library initialized
2013-08-06 12:52:16 +03:00 --- debug: Session Library initialized
2013-08-06 12:52:16 +03:00 --- debug: Auth Library loaded
2013-08-06 12:52:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:52:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:52:16 +03:00 --- debug: Database Library initialized
2013-08-06 12:52:16 +03:00 --- debug: Session Library initialized
2013-08-06 12:52:16 +03:00 --- debug: Auth Library loaded
2013-08-06 12:52:16 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:52:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:52:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:52:16 +03:00 --- debug: Database Library initialized
2013-08-06 12:52:16 +03:00 --- debug: Session Library initialized
2013-08-06 12:52:16 +03:00 --- debug: Auth Library loaded
2013-08-06 12:52:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:52:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:52:16 +03:00 --- debug: Database Library initialized
2013-08-06 12:52:16 +03:00 --- debug: Session Library initialized
2013-08-06 12:52:16 +03:00 --- debug: Auth Library loaded
2013-08-06 12:52:16 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:52:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:52:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:52:54 +03:00 --- debug: Database Library initialized
2013-08-06 12:52:54 +03:00 --- debug: Session Library initialized
2013-08-06 12:52:54 +03:00 --- debug: Auth Library loaded
2013-08-06 12:52:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:52:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:52:54 +03:00 --- debug: Database Library initialized
2013-08-06 12:52:54 +03:00 --- debug: Session Library initialized
2013-08-06 12:52:54 +03:00 --- debug: Auth Library loaded
2013-08-06 12:52:54 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:53:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:53:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:53:00 +03:00 --- debug: Database Library initialized
2013-08-06 12:53:00 +03:00 --- debug: Session Library initialized
2013-08-06 12:53:00 +03:00 --- debug: Auth Library loaded
2013-08-06 12:53:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:53:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:53:00 +03:00 --- debug: Database Library initialized
2013-08-06 12:53:00 +03:00 --- debug: Session Library initialized
2013-08-06 12:53:00 +03:00 --- debug: Auth Library loaded
2013-08-06 12:53:00 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:53:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:53:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:53:09 +03:00 --- debug: Database Library initialized
2013-08-06 12:53:09 +03:00 --- debug: Session Library initialized
2013-08-06 12:53:09 +03:00 --- debug: Auth Library loaded
2013-08-06 12:53:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:53:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:53:09 +03:00 --- debug: Database Library initialized
2013-08-06 12:53:09 +03:00 --- debug: Session Library initialized
2013-08-06 12:53:09 +03:00 --- debug: Auth Library loaded
2013-08-06 12:53:09 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:53:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:53:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:53:10 +03:00 --- debug: Database Library initialized
2013-08-06 12:53:10 +03:00 --- debug: Session Library initialized
2013-08-06 12:53:10 +03:00 --- debug: Auth Library loaded
2013-08-06 12:53:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:53:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:53:10 +03:00 --- debug: Database Library initialized
2013-08-06 12:53:10 +03:00 --- debug: Session Library initialized
2013-08-06 12:53:10 +03:00 --- debug: Auth Library loaded
2013-08-06 12:53:10 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:53:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:53:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:53:10 +03:00 --- debug: Database Library initialized
2013-08-06 12:53:10 +03:00 --- debug: Session Library initialized
2013-08-06 12:53:10 +03:00 --- debug: Auth Library loaded
2013-08-06 12:53:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:53:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:53:10 +03:00 --- debug: Database Library initialized
2013-08-06 12:53:10 +03:00 --- debug: Session Library initialized
2013-08-06 12:53:10 +03:00 --- debug: Auth Library loaded
2013-08-06 12:53:10 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:53:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:53:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:53:13 +03:00 --- debug: Database Library initialized
2013-08-06 12:53:13 +03:00 --- debug: Session Library initialized
2013-08-06 12:53:13 +03:00 --- debug: Auth Library loaded
2013-08-06 12:53:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:53:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:53:13 +03:00 --- debug: Database Library initialized
2013-08-06 12:53:13 +03:00 --- debug: Session Library initialized
2013-08-06 12:53:13 +03:00 --- debug: Auth Library loaded
2013-08-06 12:53:13 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:53:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:53:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:53:17 +03:00 --- debug: Database Library initialized
2013-08-06 12:53:17 +03:00 --- debug: Session Library initialized
2013-08-06 12:53:17 +03:00 --- debug: Auth Library loaded
2013-08-06 12:53:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:53:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:53:17 +03:00 --- debug: Database Library initialized
2013-08-06 12:53:17 +03:00 --- debug: Session Library initialized
2013-08-06 12:53:17 +03:00 --- debug: Auth Library loaded
2013-08-06 12:53:17 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:53:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:53:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:53:22 +03:00 --- debug: Database Library initialized
2013-08-06 12:53:22 +03:00 --- debug: Session Library initialized
2013-08-06 12:53:22 +03:00 --- debug: Auth Library loaded
2013-08-06 12:53:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:53:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:53:22 +03:00 --- debug: Database Library initialized
2013-08-06 12:53:22 +03:00 --- debug: Session Library initialized
2013-08-06 12:53:22 +03:00 --- debug: Auth Library loaded
2013-08-06 12:53:22 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:54:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:54:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:54:04 +03:00 --- debug: Database Library initialized
2013-08-06 12:54:04 +03:00 --- debug: Session Library initialized
2013-08-06 12:54:04 +03:00 --- debug: Auth Library loaded
2013-08-06 12:54:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:54:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:54:04 +03:00 --- debug: Database Library initialized
2013-08-06 12:54:04 +03:00 --- debug: Session Library initialized
2013-08-06 12:54:04 +03:00 --- debug: Auth Library loaded
2013-08-06 12:54:04 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:54:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:54:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:54:09 +03:00 --- debug: Database Library initialized
2013-08-06 12:54:09 +03:00 --- debug: Session Library initialized
2013-08-06 12:54:09 +03:00 --- debug: Auth Library loaded
2013-08-06 12:54:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:54:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:54:09 +03:00 --- debug: Database Library initialized
2013-08-06 12:54:09 +03:00 --- debug: Session Library initialized
2013-08-06 12:54:09 +03:00 --- debug: Auth Library loaded
2013-08-06 12:54:09 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:54:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:54:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:54:15 +03:00 --- debug: Database Library initialized
2013-08-06 12:54:15 +03:00 --- debug: Session Library initialized
2013-08-06 12:54:15 +03:00 --- debug: Auth Library loaded
2013-08-06 12:54:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:54:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:54:15 +03:00 --- debug: Database Library initialized
2013-08-06 12:54:15 +03:00 --- debug: Session Library initialized
2013-08-06 12:54:15 +03:00 --- debug: Auth Library loaded
2013-08-06 12:54:15 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:54:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:54:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:54:20 +03:00 --- debug: Database Library initialized
2013-08-06 12:54:20 +03:00 --- debug: Session Library initialized
2013-08-06 12:54:20 +03:00 --- debug: Auth Library loaded
2013-08-06 12:54:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:54:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:54:20 +03:00 --- debug: Database Library initialized
2013-08-06 12:54:20 +03:00 --- debug: Session Library initialized
2013-08-06 12:54:20 +03:00 --- debug: Auth Library loaded
2013-08-06 12:54:20 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:54:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:54:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:54:34 +03:00 --- debug: Database Library initialized
2013-08-06 12:54:34 +03:00 --- debug: Session Library initialized
2013-08-06 12:54:34 +03:00 --- debug: Auth Library loaded
2013-08-06 12:54:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:54:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:54:34 +03:00 --- debug: Database Library initialized
2013-08-06 12:54:34 +03:00 --- debug: Session Library initialized
2013-08-06 12:54:34 +03:00 --- debug: Auth Library loaded
2013-08-06 12:54:34 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:54:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:54:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:54:35 +03:00 --- debug: Database Library initialized
2013-08-06 12:54:35 +03:00 --- debug: Session Library initialized
2013-08-06 12:54:35 +03:00 --- debug: Auth Library loaded
2013-08-06 12:54:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:54:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:54:35 +03:00 --- debug: Database Library initialized
2013-08-06 12:54:35 +03:00 --- debug: Session Library initialized
2013-08-06 12:54:35 +03:00 --- debug: Auth Library loaded
2013-08-06 12:54:35 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:54:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:54:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:54:51 +03:00 --- debug: Database Library initialized
2013-08-06 12:54:51 +03:00 --- debug: Session Library initialized
2013-08-06 12:54:51 +03:00 --- debug: Auth Library loaded
2013-08-06 12:54:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:54:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:54:51 +03:00 --- debug: Database Library initialized
2013-08-06 12:54:51 +03:00 --- debug: Session Library initialized
2013-08-06 12:54:51 +03:00 --- debug: Auth Library loaded
2013-08-06 12:54:51 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:55:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:55:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:55:42 +03:00 --- debug: Database Library initialized
2013-08-06 12:55:42 +03:00 --- debug: Session Library initialized
2013-08-06 12:55:42 +03:00 --- debug: Auth Library loaded
2013-08-06 12:55:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:55:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:55:43 +03:00 --- debug: Database Library initialized
2013-08-06 12:55:43 +03:00 --- debug: Session Library initialized
2013-08-06 12:55:43 +03:00 --- debug: Auth Library loaded
2013-08-06 12:55:44 +03:00 --- error: Не пойманное PHP Error: include(/home/adok/WWW/prupravy.local/modules/admin/views/constructor/grids/products.php): failed to open stream: No such file or directory в файле /home/adok/WWW/prupravy.local/modules/admin/views/constructor/main/base.php, на строке 488
2013-08-06 12:55:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:55:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:55:44 +03:00 --- debug: Database Library initialized
2013-08-06 12:55:44 +03:00 --- debug: Session Library initialized
2013-08-06 12:55:44 +03:00 --- debug: Auth Library loaded
2013-08-06 12:55:44 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:56:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:56:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:56:14 +03:00 --- debug: Database Library initialized
2013-08-06 12:56:14 +03:00 --- debug: Session Library initialized
2013-08-06 12:56:14 +03:00 --- debug: Auth Library loaded
2013-08-06 12:56:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:56:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:56:15 +03:00 --- debug: Database Library initialized
2013-08-06 12:56:15 +03:00 --- debug: Session Library initialized
2013-08-06 12:56:15 +03:00 --- debug: Auth Library loaded
2013-08-06 12:56:15 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 12:56:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 12:56:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 12:56:15 +03:00 --- debug: Database Library initialized
2013-08-06 12:56:15 +03:00 --- debug: Session Library initialized
2013-08-06 12:56:15 +03:00 --- debug: Auth Library loaded
2013-08-06 13:00:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:00:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:00:36 +03:00 --- debug: Database Library initialized
2013-08-06 13:00:36 +03:00 --- debug: Session Library initialized
2013-08-06 13:00:36 +03:00 --- debug: Auth Library loaded
2013-08-06 13:00:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:00:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:00:37 +03:00 --- debug: Database Library initialized
2013-08-06 13:00:37 +03:00 --- debug: Session Library initialized
2013-08-06 13:00:37 +03:00 --- debug: Auth Library loaded
2013-08-06 13:00:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:00:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:00:37 +03:00 --- debug: Database Library initialized
2013-08-06 13:00:37 +03:00 --- debug: Session Library initialized
2013-08-06 13:00:37 +03:00 --- debug: Auth Library loaded
2013-08-06 13:00:37 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:01:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:01:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:01:56 +03:00 --- debug: Database Library initialized
2013-08-06 13:01:56 +03:00 --- debug: Session Library initialized
2013-08-06 13:01:56 +03:00 --- debug: Auth Library loaded
2013-08-06 13:01:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:01:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:01:57 +03:00 --- debug: Database Library initialized
2013-08-06 13:01:57 +03:00 --- debug: Session Library initialized
2013-08-06 13:01:57 +03:00 --- debug: Auth Library loaded
2013-08-06 13:01:57 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:01:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:01:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:01:57 +03:00 --- debug: Database Library initialized
2013-08-06 13:01:57 +03:00 --- debug: Session Library initialized
2013-08-06 13:01:57 +03:00 --- debug: Auth Library loaded
2013-08-06 13:02:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:02:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:02:04 +03:00 --- debug: Database Library initialized
2013-08-06 13:02:04 +03:00 --- debug: Session Library initialized
2013-08-06 13:02:04 +03:00 --- debug: Auth Library loaded
2013-08-06 13:02:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:02:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:02:05 +03:00 --- debug: Database Library initialized
2013-08-06 13:02:05 +03:00 --- debug: Session Library initialized
2013-08-06 13:02:05 +03:00 --- debug: Auth Library loaded
2013-08-06 13:02:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:02:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:02:05 +03:00 --- debug: Database Library initialized
2013-08-06 13:02:05 +03:00 --- debug: Session Library initialized
2013-08-06 13:02:05 +03:00 --- debug: Auth Library loaded
2013-08-06 13:02:05 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:02:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:02:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:02:19 +03:00 --- debug: Database Library initialized
2013-08-06 13:02:19 +03:00 --- debug: Session Library initialized
2013-08-06 13:02:19 +03:00 --- debug: Auth Library loaded
2013-08-06 13:02:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:02:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:02:19 +03:00 --- debug: Database Library initialized
2013-08-06 13:02:19 +03:00 --- debug: Session Library initialized
2013-08-06 13:02:19 +03:00 --- debug: Auth Library loaded
2013-08-06 13:02:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:02:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:02:19 +03:00 --- debug: Database Library initialized
2013-08-06 13:02:19 +03:00 --- debug: Session Library initialized
2013-08-06 13:02:19 +03:00 --- debug: Auth Library loaded
2013-08-06 13:02:19 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:02:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:02:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:02:23 +03:00 --- debug: Database Library initialized
2013-08-06 13:02:23 +03:00 --- debug: Session Library initialized
2013-08-06 13:02:23 +03:00 --- debug: Auth Library loaded
2013-08-06 13:02:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:02:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:02:32 +03:00 --- debug: Database Library initialized
2013-08-06 13:02:32 +03:00 --- debug: Session Library initialized
2013-08-06 13:02:32 +03:00 --- debug: Auth Library loaded
2013-08-06 13:02:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:02:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:02:56 +03:00 --- debug: Database Library initialized
2013-08-06 13:02:56 +03:00 --- debug: Session Library initialized
2013-08-06 13:02:56 +03:00 --- debug: Auth Library loaded
2013-08-06 13:02:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:02:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:02:59 +03:00 --- debug: Database Library initialized
2013-08-06 13:02:59 +03:00 --- debug: Session Library initialized
2013-08-06 13:02:59 +03:00 --- debug: Auth Library loaded
2013-08-06 13:02:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:02:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:02:59 +03:00 --- debug: Database Library initialized
2013-08-06 13:02:59 +03:00 --- debug: Session Library initialized
2013-08-06 13:02:59 +03:00 --- debug: Auth Library loaded
2013-08-06 13:02:59 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:03:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:03:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:03:26 +03:00 --- debug: Database Library initialized
2013-08-06 13:03:26 +03:00 --- debug: Session Library initialized
2013-08-06 13:03:26 +03:00 --- debug: Auth Library loaded
2013-08-06 13:03:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:03:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:03:27 +03:00 --- debug: Database Library initialized
2013-08-06 13:03:27 +03:00 --- debug: Session Library initialized
2013-08-06 13:03:27 +03:00 --- debug: Auth Library loaded
2013-08-06 13:03:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:03:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:03:27 +03:00 --- debug: Database Library initialized
2013-08-06 13:03:27 +03:00 --- debug: Session Library initialized
2013-08-06 13:03:27 +03:00 --- debug: Auth Library loaded
2013-08-06 13:03:27 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:13:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:13:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:13:31 +03:00 --- debug: Database Library initialized
2013-08-06 13:13:31 +03:00 --- debug: Session Library initialized
2013-08-06 13:13:31 +03:00 --- debug: Auth Library loaded
2013-08-06 13:13:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:13:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:13:31 +03:00 --- debug: Database Library initialized
2013-08-06 13:13:31 +03:00 --- debug: Session Library initialized
2013-08-06 13:13:31 +03:00 --- debug: Auth Library loaded
2013-08-06 13:13:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:13:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:13:31 +03:00 --- debug: Database Library initialized
2013-08-06 13:13:31 +03:00 --- debug: Session Library initialized
2013-08-06 13:13:31 +03:00 --- debug: Auth Library loaded
2013-08-06 13:13:31 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:14:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:14:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:14:31 +03:00 --- debug: Database Library initialized
2013-08-06 13:14:31 +03:00 --- debug: Session Library initialized
2013-08-06 13:14:31 +03:00 --- debug: Auth Library loaded
2013-08-06 13:14:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:14:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:14:31 +03:00 --- debug: Database Library initialized
2013-08-06 13:14:31 +03:00 --- debug: Session Library initialized
2013-08-06 13:14:31 +03:00 --- debug: Auth Library loaded
2013-08-06 13:14:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:14:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:14:31 +03:00 --- debug: Database Library initialized
2013-08-06 13:14:31 +03:00 --- debug: Session Library initialized
2013-08-06 13:14:31 +03:00 --- debug: Auth Library loaded
2013-08-06 13:14:31 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:14:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:14:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:14:49 +03:00 --- debug: Database Library initialized
2013-08-06 13:14:49 +03:00 --- debug: Session Library initialized
2013-08-06 13:14:49 +03:00 --- debug: Auth Library loaded
2013-08-06 13:14:49 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'name' in 'field list' - INSERT INTO `products` (`name`, `code`, `weight`, `consist`) VALUES ('wedwefewf', 'wefwefqewf', 'wefwefewfw', 'wefwefwefwefewfqew') в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 13:15:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:15:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:15:06 +03:00 --- debug: Database Library initialized
2013-08-06 13:15:06 +03:00 --- debug: Session Library initialized
2013-08-06 13:15:06 +03:00 --- debug: Auth Library loaded
2013-08-06 13:15:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:15:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:15:19 +03:00 --- debug: Database Library initialized
2013-08-06 13:15:19 +03:00 --- debug: Session Library initialized
2013-08-06 13:15:19 +03:00 --- debug: Auth Library loaded
2013-08-06 13:15:19 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'name' in 'field list' - INSERT INTO `products` (`name`, `code`, `weight`, `consist`) VALUES ('swfqewfqewfw', 'wefwefqew', 'wefwefqewf', 'wefwefqew') в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 13:15:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:15:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:15:51 +03:00 --- debug: Database Library initialized
2013-08-06 13:15:51 +03:00 --- debug: Session Library initialized
2013-08-06 13:15:51 +03:00 --- debug: Auth Library loaded
2013-08-06 13:34:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:34:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:34:58 +03:00 --- debug: Database Library initialized
2013-08-06 13:34:58 +03:00 --- debug: Session Library initialized
2013-08-06 13:34:58 +03:00 --- debug: Auth Library loaded
2013-08-06 13:34:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:34:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:34:58 +03:00 --- debug: Database Library initialized
2013-08-06 13:34:58 +03:00 --- debug: Session Library initialized
2013-08-06 13:34:58 +03:00 --- debug: Auth Library loaded
2013-08-06 13:34:58 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'name' in 'field list' - SELECT SQL_CALC_FOUND_ROWS `id`, `code`, `weight`, `has_logo`, `name`, `consist`, `code_ru`, `weight_ru`, `has_logo_ru`, `name_ru`, `consist_ru`
FROM (`products` AS `daddy`)
ORDER BY `id` DESC
LIMIT 0, 20 в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 13:34:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:34:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:34:58 +03:00 --- debug: Database Library initialized
2013-08-06 13:34:58 +03:00 --- debug: Session Library initialized
2013-08-06 13:34:58 +03:00 --- debug: Auth Library loaded
2013-08-06 13:34:58 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:35:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:35:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:35:30 +03:00 --- debug: Database Library initialized
2013-08-06 13:35:30 +03:00 --- debug: Session Library initialized
2013-08-06 13:35:30 +03:00 --- debug: Auth Library loaded
2013-08-06 13:35:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:35:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:35:31 +03:00 --- debug: Database Library initialized
2013-08-06 13:35:31 +03:00 --- debug: Session Library initialized
2013-08-06 13:35:31 +03:00 --- debug: Auth Library loaded
2013-08-06 13:35:31 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'name' in 'field list' - SELECT SQL_CALC_FOUND_ROWS `id`, `code`, `weight`, `has_logo`, `name`, `consist`, `code_ru`, `weight_ru`, `has_logo_ru`, `name_ru`, `consist_ru`
FROM (`products` AS `daddy`)
ORDER BY `id` DESC
LIMIT 0, 20 в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 13:35:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:35:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:35:31 +03:00 --- debug: Database Library initialized
2013-08-06 13:35:31 +03:00 --- debug: Session Library initialized
2013-08-06 13:35:31 +03:00 --- debug: Auth Library loaded
2013-08-06 13:35:31 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:35:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:35:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:35:53 +03:00 --- debug: Database Library initialized
2013-08-06 13:35:53 +03:00 --- debug: Session Library initialized
2013-08-06 13:35:53 +03:00 --- debug: Auth Library loaded
2013-08-06 13:35:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:35:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:35:53 +03:00 --- debug: Database Library initialized
2013-08-06 13:35:53 +03:00 --- debug: Session Library initialized
2013-08-06 13:35:53 +03:00 --- debug: Auth Library loaded
2013-08-06 13:35:53 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'name' in 'field list' - SELECT SQL_CALC_FOUND_ROWS `id`, `code`, `weight`, `has_logo`, `name`, `consist`, `consist_ru`, `consist_ru`, `consist_ru`, `name_ru`, `consist_ru`
FROM (`products` AS `daddy`)
ORDER BY `id` DESC
LIMIT 0, 20 в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 13:35:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:35:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:35:53 +03:00 --- debug: Database Library initialized
2013-08-06 13:35:53 +03:00 --- debug: Session Library initialized
2013-08-06 13:35:53 +03:00 --- debug: Auth Library loaded
2013-08-06 13:35:53 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:36:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:36:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:36:11 +03:00 --- debug: Database Library initialized
2013-08-06 13:36:11 +03:00 --- debug: Session Library initialized
2013-08-06 13:36:11 +03:00 --- debug: Auth Library loaded
2013-08-06 13:36:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:36:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:36:12 +03:00 --- debug: Database Library initialized
2013-08-06 13:36:12 +03:00 --- debug: Session Library initialized
2013-08-06 13:36:12 +03:00 --- debug: Auth Library loaded
2013-08-06 13:36:12 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'name' in 'field list' - SELECT SQL_CALC_FOUND_ROWS `id`, `code`, `weight`, `has_logo`, `name`, `consist`, `code`, `weight`, `has_logo`, `name_ru`, `consist_ru`
FROM (`products` AS `daddy`)
ORDER BY `id` DESC
LIMIT 0, 20 в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 13:36:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:36:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:36:12 +03:00 --- debug: Database Library initialized
2013-08-06 13:36:12 +03:00 --- debug: Session Library initialized
2013-08-06 13:36:12 +03:00 --- debug: Auth Library loaded
2013-08-06 13:36:12 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:41:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:41:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:41:52 +03:00 --- debug: Database Library initialized
2013-08-06 13:41:52 +03:00 --- debug: Session Library initialized
2013-08-06 13:41:52 +03:00 --- debug: Auth Library loaded
2013-08-06 13:41:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:41:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:41:53 +03:00 --- debug: Database Library initialized
2013-08-06 13:41:53 +03:00 --- debug: Session Library initialized
2013-08-06 13:41:53 +03:00 --- debug: Auth Library loaded
2013-08-06 13:41:53 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'name' in 'field list' - SELECT SQL_CALC_FOUND_ROWS `id`, `code`, `weight`, `has_logo`, `name`, `consist`, `code`, `weight`, `has_logo`, `name_ru`, `consist_ru`
FROM (`products` AS `daddy`)
ORDER BY `id` DESC
LIMIT 0, 20 в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 13:41:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:41:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:41:53 +03:00 --- debug: Database Library initialized
2013-08-06 13:41:53 +03:00 --- debug: Session Library initialized
2013-08-06 13:41:53 +03:00 --- debug: Auth Library loaded
2013-08-06 13:41:53 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:42:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:42:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:42:52 +03:00 --- debug: Database Library initialized
2013-08-06 13:42:52 +03:00 --- debug: Session Library initialized
2013-08-06 13:42:52 +03:00 --- debug: Auth Library loaded
2013-08-06 13:42:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:42:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:42:53 +03:00 --- debug: Database Library initialized
2013-08-06 13:42:53 +03:00 --- debug: Session Library initialized
2013-08-06 13:42:53 +03:00 --- debug: Auth Library loaded
2013-08-06 13:42:53 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'name' in 'field list' - SELECT SQL_CALC_FOUND_ROWS `id`, `code`, `weight`, `has_logo`, `name`, `consist`, `code`, `weight`, `has_logo`, `name_ru`, `consist_ru`
FROM (`products` AS `daddy`)
ORDER BY `id` DESC
LIMIT 0, 20 в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 13:42:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:42:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:42:53 +03:00 --- debug: Database Library initialized
2013-08-06 13:42:53 +03:00 --- debug: Session Library initialized
2013-08-06 13:42:53 +03:00 --- debug: Auth Library loaded
2013-08-06 13:42:53 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:44:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:44:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:44:07 +03:00 --- debug: Database Library initialized
2013-08-06 13:44:07 +03:00 --- debug: Session Library initialized
2013-08-06 13:44:07 +03:00 --- debug: Auth Library loaded
2013-08-06 13:44:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:44:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:44:08 +03:00 --- debug: Database Library initialized
2013-08-06 13:44:08 +03:00 --- debug: Session Library initialized
2013-08-06 13:44:08 +03:00 --- debug: Auth Library loaded
2013-08-06 13:44:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:44:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:44:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:44:08 +03:00 --- debug: Database Library initialized
2013-08-06 13:44:08 +03:00 --- debug: Session Library initialized
2013-08-06 13:44:08 +03:00 --- debug: Auth Library loaded
2013-08-06 13:44:08 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'name' in 'field list' - SELECT SQL_CALC_FOUND_ROWS `id`, `code`, `weight`, `has_logo`, `name`, `consist`
FROM (`products` AS `daddy`)
ORDER BY `id` DESC
LIMIT 0, 20 в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 13:44:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:44:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:44:54 +03:00 --- debug: Database Library initialized
2013-08-06 13:44:54 +03:00 --- debug: Session Library initialized
2013-08-06 13:44:54 +03:00 --- debug: Auth Library loaded
2013-08-06 13:44:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:44:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:44:55 +03:00 --- debug: Database Library initialized
2013-08-06 13:44:55 +03:00 --- debug: Session Library initialized
2013-08-06 13:44:55 +03:00 --- debug: Auth Library loaded
2013-08-06 13:44:55 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'name' in 'field list' - SELECT SQL_CALC_FOUND_ROWS `id`, `code`, `weight`, `has_logo`, `name`, `consist`
FROM (`products` AS `daddy`)
ORDER BY `id` DESC
LIMIT 0, 20 в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 13:44:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:44:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:44:55 +03:00 --- debug: Database Library initialized
2013-08-06 13:44:55 +03:00 --- debug: Session Library initialized
2013-08-06 13:44:55 +03:00 --- debug: Auth Library loaded
2013-08-06 13:44:55 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:45:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:45:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:45:24 +03:00 --- debug: Database Library initialized
2013-08-06 13:45:24 +03:00 --- debug: Session Library initialized
2013-08-06 13:45:24 +03:00 --- debug: Auth Library loaded
2013-08-06 13:45:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:45:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:45:25 +03:00 --- debug: Database Library initialized
2013-08-06 13:45:25 +03:00 --- debug: Session Library initialized
2013-08-06 13:45:25 +03:00 --- debug: Auth Library loaded
2013-08-06 13:45:25 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'name' in 'field list' - SELECT SQL_CALC_FOUND_ROWS `id`, `code`, `weight`, `has_logo`, `name`, `consist`
FROM (`products` AS `daddy`)
ORDER BY `id` DESC
LIMIT 0, 20 в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 13:45:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:45:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:45:25 +03:00 --- debug: Database Library initialized
2013-08-06 13:45:25 +03:00 --- debug: Session Library initialized
2013-08-06 13:45:25 +03:00 --- debug: Auth Library loaded
2013-08-06 13:45:25 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:45:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:45:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:45:42 +03:00 --- debug: Database Library initialized
2013-08-06 13:45:42 +03:00 --- debug: Session Library initialized
2013-08-06 13:45:42 +03:00 --- debug: Auth Library loaded
2013-08-06 13:45:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:45:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:45:43 +03:00 --- debug: Database Library initialized
2013-08-06 13:45:43 +03:00 --- debug: Session Library initialized
2013-08-06 13:45:43 +03:00 --- debug: Auth Library loaded
2013-08-06 13:45:43 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'name' in 'field list' - SELECT SQL_CALC_FOUND_ROWS `id`, `code`, `weight`, `has_logo`, `name`, `consist`, `code`, `weight`, `has_logo`, `name_ru`, `consist_ru`
FROM (`products` AS `daddy`)
ORDER BY `id` DESC
LIMIT 0, 20 в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 13:45:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:45:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:45:43 +03:00 --- debug: Database Library initialized
2013-08-06 13:45:43 +03:00 --- debug: Session Library initialized
2013-08-06 13:45:43 +03:00 --- debug: Auth Library loaded
2013-08-06 13:45:43 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:49:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:49:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:49:38 +03:00 --- debug: Database Library initialized
2013-08-06 13:49:38 +03:00 --- debug: Session Library initialized
2013-08-06 13:49:38 +03:00 --- debug: Auth Library loaded
2013-08-06 13:49:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:49:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:49:38 +03:00 --- debug: Database Library initialized
2013-08-06 13:49:38 +03:00 --- debug: Session Library initialized
2013-08-06 13:49:38 +03:00 --- debug: Auth Library loaded
2013-08-06 13:49:38 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'name' in 'field list' - SELECT SQL_CALC_FOUND_ROWS `id`, `code`, `weight`, `has_logo`, `name`, `consist`, `code`, `weight`, `has_logo`, `name_ru`, `consist_ru`
FROM (`products` AS `daddy`)
ORDER BY `id` DESC
LIMIT 0, 20 в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 13:49:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:49:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:49:38 +03:00 --- debug: Database Library initialized
2013-08-06 13:49:38 +03:00 --- debug: Session Library initialized
2013-08-06 13:49:38 +03:00 --- debug: Auth Library loaded
2013-08-06 13:49:38 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:50:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:50:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:50:09 +03:00 --- debug: Database Library initialized
2013-08-06 13:50:09 +03:00 --- debug: Session Library initialized
2013-08-06 13:50:09 +03:00 --- debug: Auth Library loaded
2013-08-06 13:50:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:50:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:50:09 +03:00 --- debug: Database Library initialized
2013-08-06 13:50:09 +03:00 --- debug: Session Library initialized
2013-08-06 13:50:09 +03:00 --- debug: Auth Library loaded
2013-08-06 13:50:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:50:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:50:09 +03:00 --- debug: Database Library initialized
2013-08-06 13:50:09 +03:00 --- debug: Session Library initialized
2013-08-06 13:50:09 +03:00 --- debug: Auth Library loaded
2013-08-06 13:50:09 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:50:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:50:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:50:20 +03:00 --- debug: Database Library initialized
2013-08-06 13:50:20 +03:00 --- debug: Session Library initialized
2013-08-06 13:50:20 +03:00 --- debug: Auth Library loaded
2013-08-06 13:50:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:50:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:50:40 +03:00 --- debug: Database Library initialized
2013-08-06 13:50:40 +03:00 --- debug: Session Library initialized
2013-08-06 13:50:40 +03:00 --- debug: Auth Library loaded
2013-08-06 13:50:40 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'name' in 'field list' - INSERT INTO `products` (`name`, `code`, `weight`, `consist`) VALUES ('ewfwefqewf', 'wefqewfw', 'wefwefqew', 'wefwefwefwefw') в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 13:51:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:51:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:51:26 +03:00 --- debug: Database Library initialized
2013-08-06 13:51:26 +03:00 --- debug: Session Library initialized
2013-08-06 13:51:26 +03:00 --- debug: Auth Library loaded
2013-08-06 13:51:26 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'name' in 'field list' - INSERT INTO `products` (`name`, `code`, `weight`, `consist`) VALUES ('ewfwefqewfqewdew', 'wefqewfw', 'wefwefqew', 'wefwefwefwefw') в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 13:51:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:51:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:51:59 +03:00 --- debug: Database Library initialized
2013-08-06 13:51:59 +03:00 --- debug: Session Library initialized
2013-08-06 13:51:59 +03:00 --- debug: Auth Library loaded
2013-08-06 13:52:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:52:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:52:13 +03:00 --- debug: Database Library initialized
2013-08-06 13:52:13 +03:00 --- debug: Session Library initialized
2013-08-06 13:52:13 +03:00 --- debug: Auth Library loaded
2013-08-06 13:52:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:52:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:52:38 +03:00 --- debug: Database Library initialized
2013-08-06 13:52:38 +03:00 --- debug: Session Library initialized
2013-08-06 13:52:38 +03:00 --- debug: Auth Library loaded
2013-08-06 13:53:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:53:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:53:14 +03:00 --- debug: Database Library initialized
2013-08-06 13:53:14 +03:00 --- debug: Session Library initialized
2013-08-06 13:53:14 +03:00 --- debug: Auth Library loaded
2013-08-06 13:53:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:53:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:53:15 +03:00 --- debug: Database Library initialized
2013-08-06 13:53:15 +03:00 --- debug: Session Library initialized
2013-08-06 13:53:15 +03:00 --- debug: Auth Library loaded
2013-08-06 13:53:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:53:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:53:15 +03:00 --- debug: Database Library initialized
2013-08-06 13:53:15 +03:00 --- debug: Session Library initialized
2013-08-06 13:53:15 +03:00 --- debug: Auth Library loaded
2013-08-06 13:53:15 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:53:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:53:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:53:25 +03:00 --- debug: Database Library initialized
2013-08-06 13:53:25 +03:00 --- debug: Session Library initialized
2013-08-06 13:53:25 +03:00 --- debug: Auth Library loaded
2013-08-06 13:53:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:53:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:53:26 +03:00 --- debug: Database Library initialized
2013-08-06 13:53:26 +03:00 --- debug: Session Library initialized
2013-08-06 13:53:26 +03:00 --- debug: Auth Library loaded
2013-08-06 13:53:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:53:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:53:26 +03:00 --- debug: Database Library initialized
2013-08-06 13:53:26 +03:00 --- debug: Session Library initialized
2013-08-06 13:53:26 +03:00 --- debug: Auth Library loaded
2013-08-06 13:53:26 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:53:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:53:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:53:32 +03:00 --- debug: Database Library initialized
2013-08-06 13:53:32 +03:00 --- debug: Session Library initialized
2013-08-06 13:53:32 +03:00 --- debug: Auth Library loaded
2013-08-06 13:53:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:53:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:53:46 +03:00 --- debug: Database Library initialized
2013-08-06 13:53:46 +03:00 --- debug: Session Library initialized
2013-08-06 13:53:46 +03:00 --- debug: Auth Library loaded
2013-08-06 13:53:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:53:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:53:57 +03:00 --- debug: Database Library initialized
2013-08-06 13:53:57 +03:00 --- debug: Session Library initialized
2013-08-06 13:53:57 +03:00 --- debug: Auth Library loaded
2013-08-06 13:55:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:55:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:55:08 +03:00 --- debug: Database Library initialized
2013-08-06 13:55:08 +03:00 --- debug: Session Library initialized
2013-08-06 13:55:08 +03:00 --- debug: Auth Library loaded
2013-08-06 13:55:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:55:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:55:09 +03:00 --- debug: Database Library initialized
2013-08-06 13:55:09 +03:00 --- debug: Session Library initialized
2013-08-06 13:55:09 +03:00 --- debug: Auth Library loaded
2013-08-06 13:55:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:55:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:55:09 +03:00 --- debug: Database Library initialized
2013-08-06 13:55:09 +03:00 --- debug: Session Library initialized
2013-08-06 13:55:09 +03:00 --- debug: Auth Library loaded
2013-08-06 13:55:09 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:55:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:55:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:55:20 +03:00 --- debug: Database Library initialized
2013-08-06 13:55:20 +03:00 --- debug: Session Library initialized
2013-08-06 13:55:20 +03:00 --- debug: Auth Library loaded
2013-08-06 13:55:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:55:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:55:21 +03:00 --- debug: Database Library initialized
2013-08-06 13:55:21 +03:00 --- debug: Session Library initialized
2013-08-06 13:55:21 +03:00 --- debug: Auth Library loaded
2013-08-06 13:55:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:55:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:55:21 +03:00 --- debug: Database Library initialized
2013-08-06 13:55:21 +03:00 --- debug: Session Library initialized
2013-08-06 13:55:21 +03:00 --- debug: Auth Library loaded
2013-08-06 13:55:21 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:55:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:55:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:55:26 +03:00 --- debug: Database Library initialized
2013-08-06 13:55:26 +03:00 --- debug: Session Library initialized
2013-08-06 13:55:26 +03:00 --- debug: Auth Library loaded
2013-08-06 13:56:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:56:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:56:02 +03:00 --- debug: Database Library initialized
2013-08-06 13:56:03 +03:00 --- debug: Session Library initialized
2013-08-06 13:56:03 +03:00 --- debug: Auth Library loaded
2013-08-06 13:56:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:56:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:56:03 +03:00 --- debug: Database Library initialized
2013-08-06 13:56:03 +03:00 --- debug: Session Library initialized
2013-08-06 13:56:03 +03:00 --- debug: Auth Library loaded
2013-08-06 13:56:03 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 13:56:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:56:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:56:03 +03:00 --- debug: Database Library initialized
2013-08-06 13:56:03 +03:00 --- debug: Session Library initialized
2013-08-06 13:56:03 +03:00 --- debug: Auth Library loaded
2013-08-06 13:57:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:57:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:57:44 +03:00 --- debug: Database Library initialized
2013-08-06 13:57:44 +03:00 --- debug: Session Library initialized
2013-08-06 13:57:44 +03:00 --- debug: Auth Library loaded
2013-08-06 13:57:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:57:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:57:45 +03:00 --- debug: Database Library initialized
2013-08-06 13:57:45 +03:00 --- debug: Session Library initialized
2013-08-06 13:57:45 +03:00 --- debug: Auth Library loaded
2013-08-06 13:57:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 13:57:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 13:57:45 +03:00 --- debug: Database Library initialized
2013-08-06 13:57:45 +03:00 --- debug: Session Library initialized
2013-08-06 13:57:45 +03:00 --- debug: Auth Library loaded
2013-08-06 13:57:45 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 14:01:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:01:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:01:49 +03:00 --- debug: Database Library initialized
2013-08-06 14:01:49 +03:00 --- debug: Session Library initialized
2013-08-06 14:01:49 +03:00 --- debug: Auth Library loaded
2013-08-06 14:02:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:02:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:02:03 +03:00 --- debug: Database Library initialized
2013-08-06 14:02:03 +03:00 --- debug: Session Library initialized
2013-08-06 14:02:03 +03:00 --- debug: Auth Library loaded
2013-08-06 14:02:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:02:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:02:07 +03:00 --- debug: Database Library initialized
2013-08-06 14:02:07 +03:00 --- debug: Session Library initialized
2013-08-06 14:02:07 +03:00 --- debug: Auth Library loaded
2013-08-06 14:02:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:02:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:02:44 +03:00 --- debug: Database Library initialized
2013-08-06 14:02:44 +03:00 --- debug: Session Library initialized
2013-08-06 14:02:44 +03:00 --- debug: Auth Library loaded
2013-08-06 14:02:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:02:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:02:45 +03:00 --- debug: Database Library initialized
2013-08-06 14:02:45 +03:00 --- debug: Session Library initialized
2013-08-06 14:02:45 +03:00 --- debug: Auth Library loaded
2013-08-06 14:02:45 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 14:02:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:02:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:02:45 +03:00 --- debug: Database Library initialized
2013-08-06 14:02:45 +03:00 --- debug: Session Library initialized
2013-08-06 14:02:45 +03:00 --- debug: Auth Library loaded
2013-08-06 14:02:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:02:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:02:51 +03:00 --- debug: Database Library initialized
2013-08-06 14:02:51 +03:00 --- debug: Session Library initialized
2013-08-06 14:02:51 +03:00 --- debug: Auth Library loaded
2013-08-06 14:03:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:03:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:03:37 +03:00 --- debug: Database Library initialized
2013-08-06 14:03:37 +03:00 --- debug: Session Library initialized
2013-08-06 14:03:37 +03:00 --- debug: Auth Library loaded
2013-08-06 14:03:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:03:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:03:38 +03:00 --- debug: Database Library initialized
2013-08-06 14:03:38 +03:00 --- debug: Session Library initialized
2013-08-06 14:03:38 +03:00 --- debug: Auth Library loaded
2013-08-06 14:03:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:03:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:03:38 +03:00 --- debug: Database Library initialized
2013-08-06 14:03:38 +03:00 --- debug: Session Library initialized
2013-08-06 14:03:38 +03:00 --- debug: Auth Library loaded
2013-08-06 14:03:38 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 14:03:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:03:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:03:45 +03:00 --- debug: Database Library initialized
2013-08-06 14:03:45 +03:00 --- debug: Session Library initialized
2013-08-06 14:03:45 +03:00 --- debug: Auth Library loaded
2013-08-06 14:04:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:04:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:04:35 +03:00 --- debug: Database Library initialized
2013-08-06 14:04:35 +03:00 --- debug: Session Library initialized
2013-08-06 14:04:35 +03:00 --- debug: Auth Library loaded
2013-08-06 14:04:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:04:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:04:36 +03:00 --- debug: Database Library initialized
2013-08-06 14:04:36 +03:00 --- debug: Session Library initialized
2013-08-06 14:04:36 +03:00 --- debug: Auth Library loaded
2013-08-06 14:04:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:04:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:04:36 +03:00 --- debug: Database Library initialized
2013-08-06 14:04:36 +03:00 --- debug: Session Library initialized
2013-08-06 14:04:36 +03:00 --- debug: Auth Library loaded
2013-08-06 14:04:36 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 14:04:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:04:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:04:39 +03:00 --- debug: Database Library initialized
2013-08-06 14:04:39 +03:00 --- debug: Session Library initialized
2013-08-06 14:04:39 +03:00 --- debug: Auth Library loaded
2013-08-06 14:04:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:04:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:04:46 +03:00 --- debug: Database Library initialized
2013-08-06 14:04:46 +03:00 --- debug: Session Library initialized
2013-08-06 14:04:46 +03:00 --- debug: Auth Library loaded
2013-08-06 14:04:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:04:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:04:47 +03:00 --- debug: Database Library initialized
2013-08-06 14:04:47 +03:00 --- debug: Session Library initialized
2013-08-06 14:04:47 +03:00 --- debug: Auth Library loaded
2013-08-06 14:04:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:04:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:04:49 +03:00 --- debug: Database Library initialized
2013-08-06 14:04:49 +03:00 --- debug: Session Library initialized
2013-08-06 14:04:49 +03:00 --- debug: Auth Library loaded
2013-08-06 14:04:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:04:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:04:52 +03:00 --- debug: Database Library initialized
2013-08-06 14:04:52 +03:00 --- debug: Session Library initialized
2013-08-06 14:04:52 +03:00 --- debug: Auth Library loaded
2013-08-06 14:04:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:04:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:04:54 +03:00 --- debug: Database Library initialized
2013-08-06 14:04:54 +03:00 --- debug: Session Library initialized
2013-08-06 14:04:54 +03:00 --- debug: Auth Library loaded
2013-08-06 14:05:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:05:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:05:00 +03:00 --- debug: Database Library initialized
2013-08-06 14:05:00 +03:00 --- debug: Session Library initialized
2013-08-06 14:05:00 +03:00 --- debug: Auth Library loaded
2013-08-06 14:05:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:05:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:05:26 +03:00 --- debug: Database Library initialized
2013-08-06 14:05:26 +03:00 --- debug: Session Library initialized
2013-08-06 14:05:26 +03:00 --- debug: Auth Library loaded
2013-08-06 14:06:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:06:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:06:03 +03:00 --- debug: Database Library initialized
2013-08-06 14:06:03 +03:00 --- debug: Session Library initialized
2013-08-06 14:06:03 +03:00 --- debug: Auth Library loaded
2013-08-06 14:06:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:06:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:06:31 +03:00 --- debug: Database Library initialized
2013-08-06 14:06:31 +03:00 --- debug: Session Library initialized
2013-08-06 14:06:31 +03:00 --- debug: Auth Library loaded
2013-08-06 14:06:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:06:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:06:33 +03:00 --- debug: Database Library initialized
2013-08-06 14:06:33 +03:00 --- debug: Session Library initialized
2013-08-06 14:06:33 +03:00 --- debug: Auth Library loaded
2013-08-06 14:06:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:06:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:06:35 +03:00 --- debug: Database Library initialized
2013-08-06 14:06:35 +03:00 --- debug: Session Library initialized
2013-08-06 14:06:35 +03:00 --- debug: Auth Library loaded
2013-08-06 14:06:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:06:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:06:36 +03:00 --- debug: Database Library initialized
2013-08-06 14:06:36 +03:00 --- debug: Session Library initialized
2013-08-06 14:06:36 +03:00 --- debug: Auth Library loaded
2013-08-06 14:07:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:07:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:07:52 +03:00 --- debug: Database Library initialized
2013-08-06 14:07:52 +03:00 --- debug: Session Library initialized
2013-08-06 14:07:52 +03:00 --- debug: Auth Library loaded
2013-08-06 14:07:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:07:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:07:53 +03:00 --- debug: Database Library initialized
2013-08-06 14:07:53 +03:00 --- debug: Session Library initialized
2013-08-06 14:07:53 +03:00 --- debug: Auth Library loaded
2013-08-06 14:07:53 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'name' in 'field list' - SELECT SQL_CALC_FOUND_ROWS `id`, `code`, `weight`, `has_logo`, `name`, `consist`, `code`, `weight`, `has_logo`, `name_ru` AS `name`, `consist_ru` AS `consist`
FROM (`products` AS `daddy`)
ORDER BY `id` DESC
LIMIT 0, 20 в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 14:07:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:07:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:07:53 +03:00 --- debug: Database Library initialized
2013-08-06 14:07:53 +03:00 --- debug: Session Library initialized
2013-08-06 14:07:53 +03:00 --- debug: Auth Library loaded
2013-08-06 14:07:53 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 14:08:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:08:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:08:35 +03:00 --- debug: Database Library initialized
2013-08-06 14:08:35 +03:00 --- debug: Session Library initialized
2013-08-06 14:08:35 +03:00 --- debug: Auth Library loaded
2013-08-06 14:08:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:08:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:08:35 +03:00 --- debug: Database Library initialized
2013-08-06 14:08:35 +03:00 --- debug: Session Library initialized
2013-08-06 14:08:35 +03:00 --- debug: Auth Library loaded
2013-08-06 14:08:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:08:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:08:35 +03:00 --- debug: Database Library initialized
2013-08-06 14:08:35 +03:00 --- debug: Session Library initialized
2013-08-06 14:08:35 +03:00 --- debug: Auth Library loaded
2013-08-06 14:08:35 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 14:09:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:09:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:09:32 +03:00 --- debug: Database Library initialized
2013-08-06 14:09:32 +03:00 --- debug: Session Library initialized
2013-08-06 14:09:32 +03:00 --- debug: Auth Library loaded
2013-08-06 14:09:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:09:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:09:33 +03:00 --- debug: Database Library initialized
2013-08-06 14:09:33 +03:00 --- debug: Session Library initialized
2013-08-06 14:09:33 +03:00 --- debug: Auth Library loaded
2013-08-06 14:09:33 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 14:09:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:09:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:09:33 +03:00 --- debug: Database Library initialized
2013-08-06 14:09:33 +03:00 --- debug: Session Library initialized
2013-08-06 14:09:33 +03:00 --- debug: Auth Library loaded
2013-08-06 14:09:33 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: No tables used - SELECT *
LIMIT 0, 20 в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 14:09:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:09:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:09:45 +03:00 --- debug: Database Library initialized
2013-08-06 14:09:45 +03:00 --- debug: Session Library initialized
2013-08-06 14:09:45 +03:00 --- debug: Auth Library loaded
2013-08-06 14:09:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:09:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:09:46 +03:00 --- debug: Database Library initialized
2013-08-06 14:09:46 +03:00 --- debug: Session Library initialized
2013-08-06 14:09:46 +03:00 --- debug: Auth Library loaded
2013-08-06 14:09:46 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: No tables used - SELECT *
LIMIT 0, 20 в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-06 14:09:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:09:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:09:46 +03:00 --- debug: Database Library initialized
2013-08-06 14:09:46 +03:00 --- debug: Session Library initialized
2013-08-06 14:09:46 +03:00 --- debug: Auth Library loaded
2013-08-06 14:09:46 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 14:10:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:10:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:10:10 +03:00 --- debug: Database Library initialized
2013-08-06 14:10:10 +03:00 --- debug: Session Library initialized
2013-08-06 14:10:10 +03:00 --- debug: Auth Library loaded
2013-08-06 14:10:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:10:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:10:11 +03:00 --- debug: Database Library initialized
2013-08-06 14:10:11 +03:00 --- debug: Session Library initialized
2013-08-06 14:10:11 +03:00 --- debug: Auth Library loaded
2013-08-06 14:10:11 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 14:10:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:10:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:10:11 +03:00 --- debug: Database Library initialized
2013-08-06 14:10:11 +03:00 --- debug: Session Library initialized
2013-08-06 14:10:11 +03:00 --- debug: Auth Library loaded
2013-08-06 14:10:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:10:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:10:18 +03:00 --- debug: Database Library initialized
2013-08-06 14:10:18 +03:00 --- debug: Session Library initialized
2013-08-06 14:10:18 +03:00 --- debug: Auth Library loaded
2013-08-06 14:10:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:10:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:10:26 +03:00 --- debug: Database Library initialized
2013-08-06 14:10:26 +03:00 --- debug: Session Library initialized
2013-08-06 14:10:26 +03:00 --- debug: Auth Library loaded
2013-08-06 14:10:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:10:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:10:27 +03:00 --- debug: Database Library initialized
2013-08-06 14:10:27 +03:00 --- debug: Session Library initialized
2013-08-06 14:10:27 +03:00 --- debug: Auth Library loaded
2013-08-06 14:10:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:10:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:10:28 +03:00 --- debug: Database Library initialized
2013-08-06 14:10:28 +03:00 --- debug: Session Library initialized
2013-08-06 14:10:28 +03:00 --- debug: Auth Library loaded
2013-08-06 14:10:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:10:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:10:28 +03:00 --- debug: Database Library initialized
2013-08-06 14:10:28 +03:00 --- debug: Session Library initialized
2013-08-06 14:10:28 +03:00 --- debug: Auth Library loaded
2013-08-06 14:10:28 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 14:10:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:10:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:10:34 +03:00 --- debug: Database Library initialized
2013-08-06 14:10:34 +03:00 --- debug: Session Library initialized
2013-08-06 14:10:34 +03:00 --- debug: Auth Library loaded
2013-08-06 14:10:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:10:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:10:43 +03:00 --- debug: Database Library initialized
2013-08-06 14:10:43 +03:00 --- debug: Session Library initialized
2013-08-06 14:10:43 +03:00 --- debug: Auth Library loaded
2013-08-06 14:10:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:10:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:10:53 +03:00 --- debug: Database Library initialized
2013-08-06 14:10:53 +03:00 --- debug: Session Library initialized
2013-08-06 14:10:53 +03:00 --- debug: Auth Library loaded
2013-08-06 14:10:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:10:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:10:54 +03:00 --- debug: Database Library initialized
2013-08-06 14:10:54 +03:00 --- debug: Session Library initialized
2013-08-06 14:10:54 +03:00 --- debug: Auth Library loaded
2013-08-06 14:10:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 14:10:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 14:10:54 +03:00 --- debug: Database Library initialized
2013-08-06 14:10:54 +03:00 --- debug: Session Library initialized
2013-08-06 14:10:54 +03:00 --- debug: Auth Library loaded
2013-08-06 14:10:54 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 16:57:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 16:57:33 +03:00 --- debug: Session Library initialized
2013-08-06 16:57:33 +03:00 --- debug: Auth Library loaded
2013-08-06 16:57:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 16:57:33 +03:00 --- debug: Database Library initialized
2013-08-06 16:57:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 16:57:33 +03:00 --- debug: Session Library initialized
2013-08-06 16:57:33 +03:00 --- debug: Auth Library loaded
2013-08-06 16:57:33 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/logo.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 16:57:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 16:57:33 +03:00 --- debug: Session Library initialized
2013-08-06 16:57:33 +03:00 --- debug: Auth Library loaded
2013-08-06 16:57:33 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 16:57:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 16:57:37 +03:00 --- debug: Session Library initialized
2013-08-06 16:57:37 +03:00 --- debug: Auth Library loaded
2013-08-06 16:57:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 16:57:37 +03:00 --- debug: Database Library initialized
2013-08-06 16:57:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 16:57:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 16:57:37 +03:00 --- debug: Database Library initialized
2013-08-06 16:57:37 +03:00 --- debug: Session Library initialized
2013-08-06 16:57:37 +03:00 --- debug: Auth Library loaded
2013-08-06 16:57:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 16:57:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 16:57:38 +03:00 --- debug: Database Library initialized
2013-08-06 16:57:38 +03:00 --- debug: Session Library initialized
2013-08-06 16:57:38 +03:00 --- debug: Auth Library loaded
2013-08-06 16:57:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 16:57:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 16:57:38 +03:00 --- debug: Database Library initialized
2013-08-06 16:57:38 +03:00 --- debug: Session Library initialized
2013-08-06 16:57:38 +03:00 --- debug: Auth Library loaded
2013-08-06 16:57:38 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 16:57:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 16:57:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 16:57:42 +03:00 --- debug: Database Library initialized
2013-08-06 16:57:42 +03:00 --- debug: Session Library initialized
2013-08-06 16:57:42 +03:00 --- debug: Auth Library loaded
2013-08-06 16:57:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 16:57:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 16:57:44 +03:00 --- debug: Database Library initialized
2013-08-06 16:57:44 +03:00 --- debug: Session Library initialized
2013-08-06 16:57:44 +03:00 --- debug: Auth Library loaded
2013-08-06 16:57:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 16:57:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 16:57:44 +03:00 --- debug: Database Library initialized
2013-08-06 16:57:44 +03:00 --- debug: Session Library initialized
2013-08-06 16:57:44 +03:00 --- debug: Auth Library loaded
2013-08-06 16:57:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 16:57:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 16:57:44 +03:00 --- debug: Database Library initialized
2013-08-06 16:57:44 +03:00 --- debug: Session Library initialized
2013-08-06 16:57:44 +03:00 --- debug: Auth Library loaded
2013-08-06 16:57:44 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-06 16:58:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 16:58:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 16:58:04 +03:00 --- debug: Database Library initialized
2013-08-06 16:58:04 +03:00 --- debug: Session Library initialized
2013-08-06 16:58:04 +03:00 --- debug: Auth Library loaded
2013-08-06 17:00:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 17:00:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 17:00:35 +03:00 --- debug: Database Library initialized
2013-08-06 17:00:35 +03:00 --- debug: Session Library initialized
2013-08-06 17:00:35 +03:00 --- debug: Auth Library loaded
2013-08-06 17:01:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-06 17:01:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-06 17:01:42 +03:00 --- debug: Database Library initialized
2013-08-06 17:01:42 +03:00 --- debug: Session Library initialized
2013-08-06 17:01:42 +03:00 --- debug: Auth Library loaded
