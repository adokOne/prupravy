<?php defined('SYSPATH') or die('No direct script access.'); ?>

2013-08-07 12:22:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:22:58 +03:00 --- debug: Session Library initialized
2013-08-07 12:22:58 +03:00 --- debug: Auth Library loaded
2013-08-07 12:22:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:22:58 +03:00 --- debug: Database Library initialized
2013-08-07 12:22:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:22:58 +03:00 --- debug: Session Library initialized
2013-08-07 12:22:58 +03:00 --- debug: Auth Library loaded
2013-08-07 12:22:58 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:23:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:23:10 +03:00 --- debug: Session Library initialized
2013-08-07 12:23:10 +03:00 --- debug: Auth Library loaded
2013-08-07 12:23:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:23:10 +03:00 --- debug: Database Library initialized
2013-08-07 12:23:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:23:10 +03:00 --- debug: Session Library initialized
2013-08-07 12:23:10 +03:00 --- debug: Auth Library loaded
2013-08-07 12:23:10 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:23:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:23:11 +03:00 --- debug: Session Library initialized
2013-08-07 12:23:11 +03:00 --- debug: Auth Library loaded
2013-08-07 12:23:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:23:11 +03:00 --- debug: Database Library initialized
2013-08-07 12:23:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:23:11 +03:00 --- debug: Session Library initialized
2013-08-07 12:23:11 +03:00 --- debug: Auth Library loaded
2013-08-07 12:23:11 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:23:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:23:40 +03:00 --- debug: Session Library initialized
2013-08-07 12:23:40 +03:00 --- debug: Auth Library loaded
2013-08-07 12:23:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:23:40 +03:00 --- debug: Database Library initialized
2013-08-07 12:23:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:23:41 +03:00 --- debug: Session Library initialized
2013-08-07 12:23:41 +03:00 --- debug: Auth Library loaded
2013-08-07 12:23:41 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:24:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:24:46 +03:00 --- debug: Session Library initialized
2013-08-07 12:24:46 +03:00 --- debug: Auth Library loaded
2013-08-07 12:24:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:24:46 +03:00 --- debug: Database Library initialized
2013-08-07 12:24:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:24:46 +03:00 --- debug: Session Library initialized
2013-08-07 12:24:46 +03:00 --- debug: Auth Library loaded
2013-08-07 12:24:46 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/logo.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:24:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:24:47 +03:00 --- debug: Session Library initialized
2013-08-07 12:24:47 +03:00 --- debug: Auth Library loaded
2013-08-07 12:24:47 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:24:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:24:51 +03:00 --- debug: Session Library initialized
2013-08-07 12:24:51 +03:00 --- debug: Auth Library loaded
2013-08-07 12:24:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:24:51 +03:00 --- debug: Database Library initialized
2013-08-07 12:24:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:24:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:24:51 +03:00 --- debug: Database Library initialized
2013-08-07 12:24:51 +03:00 --- debug: Session Library initialized
2013-08-07 12:24:51 +03:00 --- debug: Auth Library loaded
2013-08-07 12:24:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:24:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:24:52 +03:00 --- debug: Database Library initialized
2013-08-07 12:24:52 +03:00 --- debug: Session Library initialized
2013-08-07 12:24:52 +03:00 --- debug: Auth Library loaded
2013-08-07 12:24:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:24:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:24:52 +03:00 --- debug: Database Library initialized
2013-08-07 12:24:52 +03:00 --- debug: Session Library initialized
2013-08-07 12:24:52 +03:00 --- debug: Auth Library loaded
2013-08-07 12:24:52 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:24:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:24:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:24:57 +03:00 --- debug: Database Library initialized
2013-08-07 12:24:57 +03:00 --- debug: Session Library initialized
2013-08-07 12:24:57 +03:00 --- debug: Auth Library loaded
2013-08-07 12:24:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:24:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:24:59 +03:00 --- debug: Database Library initialized
2013-08-07 12:24:59 +03:00 --- debug: Session Library initialized
2013-08-07 12:24:59 +03:00 --- debug: Auth Library loaded
2013-08-07 12:25:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:25:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:25:22 +03:00 --- debug: Database Library initialized
2013-08-07 12:25:22 +03:00 --- debug: Session Library initialized
2013-08-07 12:25:22 +03:00 --- debug: Auth Library loaded
2013-08-07 12:25:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:25:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:25:38 +03:00 --- debug: Database Library initialized
2013-08-07 12:25:38 +03:00 --- debug: Session Library initialized
2013-08-07 12:25:38 +03:00 --- debug: Auth Library loaded
2013-08-07 12:26:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:26:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:26:05 +03:00 --- debug: Database Library initialized
2013-08-07 12:26:05 +03:00 --- debug: Session Library initialized
2013-08-07 12:26:05 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:14 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:14 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:14 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:14 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:14 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:14 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:14 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:14 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:14 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:14 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:27:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:18 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:18 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:18 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:34 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:34 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:34 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:35 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:35 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:35 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:35 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:35 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:35 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:35 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:27:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:40 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:40 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:40 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:44 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:44 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:44 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:45 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:45 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:45 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:45 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:45 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:45 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:45 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:45 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:45 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:45 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:45 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:45 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:46 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:46 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:46 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:46 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:46 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:46 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:47 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:47 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:47 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:54 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:54 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:54 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:57 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:57 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:57 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:58 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:58 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:58 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:58 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:58 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:58 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:58 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:58 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:58 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:58 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:58 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:58 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:58 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:58 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:58 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:59 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:59 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:59 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:59 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:59 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:59 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:59 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:59 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:59 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:59 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:59 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:59 +03:00 --- debug: Auth Library loaded
2013-08-07 12:27:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:27:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:27:59 +03:00 --- debug: Database Library initialized
2013-08-07 12:27:59 +03:00 --- debug: Session Library initialized
2013-08-07 12:27:59 +03:00 --- debug: Auth Library loaded
2013-08-07 12:28:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:28:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:28:00 +03:00 --- debug: Database Library initialized
2013-08-07 12:28:00 +03:00 --- debug: Session Library initialized
2013-08-07 12:28:00 +03:00 --- debug: Auth Library loaded
2013-08-07 12:28:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:28:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:28:01 +03:00 --- debug: Database Library initialized
2013-08-07 12:28:01 +03:00 --- debug: Session Library initialized
2013-08-07 12:28:01 +03:00 --- debug: Auth Library loaded
2013-08-07 12:28:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:28:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:28:08 +03:00 --- debug: Database Library initialized
2013-08-07 12:28:08 +03:00 --- debug: Session Library initialized
2013-08-07 12:28:08 +03:00 --- debug: Auth Library loaded
2013-08-07 12:28:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:28:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:28:10 +03:00 --- debug: Database Library initialized
2013-08-07 12:28:10 +03:00 --- debug: Session Library initialized
2013-08-07 12:28:10 +03:00 --- debug: Auth Library loaded
2013-08-07 12:28:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:28:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:28:10 +03:00 --- debug: Database Library initialized
2013-08-07 12:28:10 +03:00 --- debug: Session Library initialized
2013-08-07 12:28:10 +03:00 --- debug: Auth Library loaded
2013-08-07 12:28:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:28:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:28:11 +03:00 --- debug: Database Library initialized
2013-08-07 12:28:11 +03:00 --- debug: Session Library initialized
2013-08-07 12:28:11 +03:00 --- debug: Auth Library loaded
2013-08-07 12:28:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:28:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:28:12 +03:00 --- debug: Database Library initialized
2013-08-07 12:28:12 +03:00 --- debug: Session Library initialized
2013-08-07 12:28:12 +03:00 --- debug: Auth Library loaded
2013-08-07 12:28:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:28:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:28:12 +03:00 --- debug: Database Library initialized
2013-08-07 12:28:12 +03:00 --- debug: Session Library initialized
2013-08-07 12:28:12 +03:00 --- debug: Auth Library loaded
2013-08-07 12:28:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:28:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:28:12 +03:00 --- debug: Database Library initialized
2013-08-07 12:28:12 +03:00 --- debug: Session Library initialized
2013-08-07 12:28:12 +03:00 --- debug: Auth Library loaded
2013-08-07 12:28:12 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:28:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:28:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:28:15 +03:00 --- debug: Database Library initialized
2013-08-07 12:28:15 +03:00 --- debug: Session Library initialized
2013-08-07 12:28:15 +03:00 --- debug: Auth Library loaded
2013-08-07 12:29:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:29:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:29:32 +03:00 --- debug: Database Library initialized
2013-08-07 12:29:32 +03:00 --- debug: Session Library initialized
2013-08-07 12:29:32 +03:00 --- debug: Auth Library loaded
2013-08-07 12:29:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:29:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:29:33 +03:00 --- debug: Database Library initialized
2013-08-07 12:29:33 +03:00 --- debug: Session Library initialized
2013-08-07 12:29:33 +03:00 --- debug: Auth Library loaded
2013-08-07 12:29:33 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'desc' in 'field list' - SELECT SQL_CALC_FOUND_ROWS `id`, `code`, `weight`, `has_logo`, `desc`, `code`, `weight`, `has_logo`, `name_ru` AS `name`, `consist_ru` AS `consist`, `desc_ru` AS `desc`
FROM (`products` AS `daddy`)
ORDER BY `id` DESC
LIMIT 0, 20 в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-07 12:29:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:29:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:29:33 +03:00 --- debug: Database Library initialized
2013-08-07 12:29:33 +03:00 --- debug: Session Library initialized
2013-08-07 12:29:33 +03:00 --- debug: Auth Library loaded
2013-08-07 12:29:33 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:30:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:30:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:30:38 +03:00 --- debug: Database Library initialized
2013-08-07 12:30:38 +03:00 --- debug: Session Library initialized
2013-08-07 12:30:38 +03:00 --- debug: Auth Library loaded
2013-08-07 12:30:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:30:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:30:40 +03:00 --- debug: Database Library initialized
2013-08-07 12:30:40 +03:00 --- debug: Session Library initialized
2013-08-07 12:30:40 +03:00 --- debug: Auth Library loaded
2013-08-07 12:30:40 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:30:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:30:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:30:40 +03:00 --- debug: Database Library initialized
2013-08-07 12:30:40 +03:00 --- debug: Session Library initialized
2013-08-07 12:30:40 +03:00 --- debug: Auth Library loaded
2013-08-07 12:30:40 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'desc' in 'field list' - SELECT SQL_CALC_FOUND_ROWS `id`, `code`, `weight`, `has_logo`, `desc`, `code`, `weight`, `has_logo`, `name_ru` AS `name`, `consist_ru` AS `consist`, `desc_ru` AS `desc`
FROM (`products` AS `daddy`)
ORDER BY `id` DESC
LIMIT 0, 20 в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-07 12:31:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:31:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:31:49 +03:00 --- debug: Database Library initialized
2013-08-07 12:31:49 +03:00 --- debug: Session Library initialized
2013-08-07 12:31:49 +03:00 --- debug: Auth Library loaded
2013-08-07 12:31:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:31:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:31:49 +03:00 --- debug: Database Library initialized
2013-08-07 12:31:49 +03:00 --- debug: Session Library initialized
2013-08-07 12:31:49 +03:00 --- debug: Auth Library loaded
2013-08-07 12:31:49 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'descr' in 'field list' - SELECT SQL_CALC_FOUND_ROWS `id`, `code`, `weight`, `has_logo`, `descr`, `code`, `weight`, `has_logo`, `name_ru` AS `name`, `consist_ru` AS `consist`, `descr_ru` AS `descr`
FROM (`products` AS `daddy`)
ORDER BY `id` DESC
LIMIT 0, 20 в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-07 12:31:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:31:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:31:49 +03:00 --- debug: Database Library initialized
2013-08-07 12:31:49 +03:00 --- debug: Session Library initialized
2013-08-07 12:31:49 +03:00 --- debug: Auth Library loaded
2013-08-07 12:31:49 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:32:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:32:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:32:50 +03:00 --- debug: Database Library initialized
2013-08-07 12:32:50 +03:00 --- debug: Session Library initialized
2013-08-07 12:32:50 +03:00 --- debug: Auth Library loaded
2013-08-07 12:32:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:32:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:32:51 +03:00 --- debug: Database Library initialized
2013-08-07 12:32:51 +03:00 --- debug: Session Library initialized
2013-08-07 12:32:51 +03:00 --- debug: Auth Library loaded
2013-08-07 12:32:51 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'descr' in 'field list' - SELECT SQL_CALC_FOUND_ROWS `id`, `code`, `weight`, `has_logo`, `descr`, `code`, `weight`, `has_logo`, `name_ru` AS `name`, `consist_ru` AS `consist`, `descr_ru` AS `descr`
FROM (`products` AS `daddy`)
ORDER BY `id` DESC
LIMIT 0, 20 в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-07 12:32:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:32:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:32:51 +03:00 --- debug: Database Library initialized
2013-08-07 12:32:51 +03:00 --- debug: Session Library initialized
2013-08-07 12:32:51 +03:00 --- debug: Auth Library loaded
2013-08-07 12:32:51 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:33:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:33:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:33:38 +03:00 --- debug: Database Library initialized
2013-08-07 12:33:38 +03:00 --- debug: Session Library initialized
2013-08-07 12:33:38 +03:00 --- debug: Auth Library loaded
2013-08-07 12:33:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:33:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:33:39 +03:00 --- debug: Database Library initialized
2013-08-07 12:33:39 +03:00 --- debug: Session Library initialized
2013-08-07 12:33:39 +03:00 --- debug: Auth Library loaded
2013-08-07 12:33:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:33:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:33:39 +03:00 --- debug: Database Library initialized
2013-08-07 12:33:39 +03:00 --- debug: Session Library initialized
2013-08-07 12:33:39 +03:00 --- debug: Auth Library loaded
2013-08-07 12:33:39 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:33:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:33:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:33:45 +03:00 --- debug: Database Library initialized
2013-08-07 12:33:45 +03:00 --- debug: Session Library initialized
2013-08-07 12:33:45 +03:00 --- debug: Auth Library loaded
2013-08-07 12:33:45 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'desc' in 'field list' - UPDATE `products` SET `id` = 2, `code` = 'wefewfewf', `weight` = 0, `has_logo` = 0, `name_ru` = 'qwdqwdqwdq', `consist_ru` = 'qwdqwdqwdqw', `descr_ru` = NULL, `desc` = 'dqwdqwd' WHERE id = 2 в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-07 12:33:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:33:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:33:59 +03:00 --- debug: Database Library initialized
2013-08-07 12:33:59 +03:00 --- debug: Session Library initialized
2013-08-07 12:33:59 +03:00 --- debug: Auth Library loaded
2013-08-07 12:34:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:34:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:34:00 +03:00 --- debug: Database Library initialized
2013-08-07 12:34:00 +03:00 --- debug: Session Library initialized
2013-08-07 12:34:00 +03:00 --- debug: Auth Library loaded
2013-08-07 12:34:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:34:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:34:00 +03:00 --- debug: Database Library initialized
2013-08-07 12:34:00 +03:00 --- debug: Session Library initialized
2013-08-07 12:34:00 +03:00 --- debug: Auth Library loaded
2013-08-07 12:34:00 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:34:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:34:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:34:03 +03:00 --- debug: Database Library initialized
2013-08-07 12:34:03 +03:00 --- debug: Session Library initialized
2013-08-07 12:34:03 +03:00 --- debug: Auth Library loaded
2013-08-07 12:34:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:34:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:34:17 +03:00 --- debug: Database Library initialized
2013-08-07 12:34:18 +03:00 --- debug: Session Library initialized
2013-08-07 12:34:18 +03:00 --- debug: Auth Library loaded
2013-08-07 12:34:18 +03:00 --- error: Не пойманное PHP Error: move_uploaded_file(/home/adok/WWW/prupravy.local/www//tmp/2.jpg): failed to open stream: No such file or directory в файле /home/adok/WWW/prupravy.local/modules/admin/libraries/Constructor.php, на строке 518
2013-08-07 12:34:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:34:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:34:18 +03:00 --- debug: Database Library initialized
2013-08-07 12:34:18 +03:00 --- debug: Session Library initialized
2013-08-07 12:34:18 +03:00 --- debug: Auth Library loaded
2013-08-07 12:34:18 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:34:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:34:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:34:18 +03:00 --- debug: Database Library initialized
2013-08-07 12:34:18 +03:00 --- debug: Session Library initialized
2013-08-07 12:34:18 +03:00 --- debug: Auth Library loaded
2013-08-07 12:34:18 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:35:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:35:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:35:20 +03:00 --- debug: Database Library initialized
2013-08-07 12:35:20 +03:00 --- debug: Session Library initialized
2013-08-07 12:35:20 +03:00 --- debug: Auth Library loaded
2013-08-07 12:35:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:35:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:35:21 +03:00 --- debug: Database Library initialized
2013-08-07 12:35:21 +03:00 --- debug: Session Library initialized
2013-08-07 12:35:21 +03:00 --- debug: Auth Library loaded
2013-08-07 12:35:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:35:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:35:21 +03:00 --- debug: Database Library initialized
2013-08-07 12:35:21 +03:00 --- debug: Session Library initialized
2013-08-07 12:35:21 +03:00 --- debug: Auth Library loaded
2013-08-07 12:35:21 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:35:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:35:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:35:23 +03:00 --- debug: Database Library initialized
2013-08-07 12:35:23 +03:00 --- debug: Session Library initialized
2013-08-07 12:35:23 +03:00 --- debug: Auth Library loaded
2013-08-07 12:35:23 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/products/2/pic_320.jpg?0.27011117804795504, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:35:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:35:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:35:29 +03:00 --- debug: Database Library initialized
2013-08-07 12:35:29 +03:00 --- debug: Session Library initialized
2013-08-07 12:35:29 +03:00 --- debug: Auth Library loaded
2013-08-07 12:35:29 +03:00 --- error: Не пойманное PHP Error: move_uploaded_file(/home/adok/WWW/prupravy.local/www//tmp/2.jpg): failed to open stream: No such file or directory в файле /home/adok/WWW/prupravy.local/modules/admin/libraries/Constructor.php, на строке 518
2013-08-07 12:35:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:35:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:35:29 +03:00 --- debug: Database Library initialized
2013-08-07 12:35:29 +03:00 --- debug: Session Library initialized
2013-08-07 12:35:29 +03:00 --- debug: Auth Library loaded
2013-08-07 12:35:29 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:35:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:35:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:35:29 +03:00 --- debug: Database Library initialized
2013-08-07 12:35:29 +03:00 --- debug: Session Library initialized
2013-08-07 12:35:29 +03:00 --- debug: Auth Library loaded
2013-08-07 12:35:29 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:36:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:36:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:36:14 +03:00 --- debug: Database Library initialized
2013-08-07 12:36:14 +03:00 --- debug: Session Library initialized
2013-08-07 12:36:14 +03:00 --- debug: Auth Library loaded
2013-08-07 12:36:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:36:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:36:15 +03:00 --- debug: Database Library initialized
2013-08-07 12:36:15 +03:00 --- debug: Session Library initialized
2013-08-07 12:36:15 +03:00 --- debug: Auth Library loaded
2013-08-07 12:36:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:36:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:36:15 +03:00 --- debug: Database Library initialized
2013-08-07 12:36:15 +03:00 --- debug: Session Library initialized
2013-08-07 12:36:15 +03:00 --- debug: Auth Library loaded
2013-08-07 12:36:15 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:36:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:36:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:36:17 +03:00 --- debug: Database Library initialized
2013-08-07 12:36:17 +03:00 --- debug: Session Library initialized
2013-08-07 12:36:17 +03:00 --- debug: Auth Library loaded
2013-08-07 12:36:17 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/products/2/pic_320.jpg?0.1410405181813985, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:36:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:36:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:36:21 +03:00 --- debug: Database Library initialized
2013-08-07 12:36:21 +03:00 --- debug: Session Library initialized
2013-08-07 12:36:21 +03:00 --- debug: Auth Library loaded
2013-08-07 12:36:21 +03:00 --- error: Не пойманное PHP Error: mkdir(): No such file or directory в файле /home/adok/WWW/prupravy.local/modules/user/libraries/MOJOUser.php, на строке 74
2013-08-07 12:36:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:36:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:36:21 +03:00 --- debug: Database Library initialized
2013-08-07 12:36:21 +03:00 --- debug: Session Library initialized
2013-08-07 12:36:21 +03:00 --- debug: Auth Library loaded
2013-08-07 12:36:21 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:36:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:36:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:36:21 +03:00 --- debug: Database Library initialized
2013-08-07 12:36:21 +03:00 --- debug: Session Library initialized
2013-08-07 12:36:21 +03:00 --- debug: Auth Library loaded
2013-08-07 12:36:21 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:39:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:39:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:39:19 +03:00 --- debug: Database Library initialized
2013-08-07 12:39:19 +03:00 --- debug: Session Library initialized
2013-08-07 12:39:19 +03:00 --- debug: Auth Library loaded
2013-08-07 12:39:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:39:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:39:20 +03:00 --- debug: Database Library initialized
2013-08-07 12:39:20 +03:00 --- debug: Session Library initialized
2013-08-07 12:39:20 +03:00 --- debug: Auth Library loaded
2013-08-07 12:39:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:39:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:39:20 +03:00 --- debug: Database Library initialized
2013-08-07 12:39:20 +03:00 --- debug: Session Library initialized
2013-08-07 12:39:20 +03:00 --- debug: Auth Library loaded
2013-08-07 12:39:20 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:39:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:39:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:39:21 +03:00 --- debug: Database Library initialized
2013-08-07 12:39:21 +03:00 --- debug: Session Library initialized
2013-08-07 12:39:21 +03:00 --- debug: Auth Library loaded
2013-08-07 12:39:21 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/products/2/pic_320.jpg?0.4127159370109439, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:39:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:39:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:39:27 +03:00 --- debug: Database Library initialized
2013-08-07 12:39:27 +03:00 --- debug: Session Library initialized
2013-08-07 12:39:27 +03:00 --- debug: Auth Library loaded
2013-08-07 12:39:27 +03:00 --- error: Не пойманное PHP Error: mkdir(): No such file or directory в файле /home/adok/WWW/prupravy.local/modules/user/libraries/MOJOUser.php, на строке 74
2013-08-07 12:39:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:39:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:39:27 +03:00 --- debug: Database Library initialized
2013-08-07 12:39:27 +03:00 --- debug: Session Library initialized
2013-08-07 12:39:27 +03:00 --- debug: Auth Library loaded
2013-08-07 12:39:27 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:39:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:39:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:39:27 +03:00 --- debug: Database Library initialized
2013-08-07 12:39:27 +03:00 --- debug: Session Library initialized
2013-08-07 12:39:27 +03:00 --- debug: Auth Library loaded
2013-08-07 12:39:27 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:39:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:39:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:39:55 +03:00 --- debug: Database Library initialized
2013-08-07 12:39:55 +03:00 --- debug: Session Library initialized
2013-08-07 12:39:55 +03:00 --- debug: Auth Library loaded
2013-08-07 12:39:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:39:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:39:56 +03:00 --- debug: Database Library initialized
2013-08-07 12:39:56 +03:00 --- debug: Session Library initialized
2013-08-07 12:39:56 +03:00 --- debug: Auth Library loaded
2013-08-07 12:39:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:39:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:39:56 +03:00 --- debug: Database Library initialized
2013-08-07 12:39:56 +03:00 --- debug: Session Library initialized
2013-08-07 12:39:56 +03:00 --- debug: Auth Library loaded
2013-08-07 12:39:56 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:39:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:39:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:39:58 +03:00 --- debug: Database Library initialized
2013-08-07 12:39:58 +03:00 --- debug: Session Library initialized
2013-08-07 12:39:58 +03:00 --- debug: Auth Library loaded
2013-08-07 12:39:58 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/products/2/pic_320.jpg?0.006189980544149876, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:40:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:40:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:40:04 +03:00 --- debug: Database Library initialized
2013-08-07 12:40:04 +03:00 --- debug: Session Library initialized
2013-08-07 12:40:04 +03:00 --- debug: Auth Library loaded
2013-08-07 12:40:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:40:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:40:04 +03:00 --- debug: Database Library initialized
2013-08-07 12:40:04 +03:00 --- debug: Session Library initialized
2013-08-07 12:40:04 +03:00 --- debug: Auth Library loaded
2013-08-07 12:40:04 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:40:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:40:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:40:04 +03:00 --- debug: Database Library initialized
2013-08-07 12:40:04 +03:00 --- debug: Session Library initialized
2013-08-07 12:40:04 +03:00 --- debug: Auth Library loaded
2013-08-07 12:40:04 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:48:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:48:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:48:51 +03:00 --- debug: Database Library initialized
2013-08-07 12:48:51 +03:00 --- debug: Session Library initialized
2013-08-07 12:48:51 +03:00 --- debug: Auth Library loaded
2013-08-07 12:48:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:48:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:48:52 +03:00 --- debug: Database Library initialized
2013-08-07 12:48:52 +03:00 --- debug: Session Library initialized
2013-08-07 12:48:52 +03:00 --- debug: Auth Library loaded
2013-08-07 12:48:52 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:48:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:48:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:48:52 +03:00 --- debug: Database Library initialized
2013-08-07 12:48:52 +03:00 --- debug: Session Library initialized
2013-08-07 12:48:52 +03:00 --- debug: Auth Library loaded
2013-08-07 12:48:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:48:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:48:52 +03:00 --- debug: Database Library initialized
2013-08-07 12:48:52 +03:00 --- debug: Session Library initialized
2013-08-07 12:48:52 +03:00 --- debug: Auth Library loaded
2013-08-07 12:48:52 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/products/2/pr_big.jpg?0.49364436441101134, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:49:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:49:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:49:00 +03:00 --- debug: Database Library initialized
2013-08-07 12:49:00 +03:00 --- debug: Session Library initialized
2013-08-07 12:49:00 +03:00 --- debug: Auth Library loaded
2013-08-07 12:49:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:49:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:49:00 +03:00 --- debug: Database Library initialized
2013-08-07 12:49:00 +03:00 --- debug: Session Library initialized
2013-08-07 12:49:00 +03:00 --- debug: Auth Library loaded
2013-08-07 12:49:00 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:49:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:49:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:49:00 +03:00 --- debug: Database Library initialized
2013-08-07 12:49:00 +03:00 --- debug: Session Library initialized
2013-08-07 12:49:00 +03:00 --- debug: Auth Library loaded
2013-08-07 12:49:00 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:49:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:49:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:49:08 +03:00 --- debug: Database Library initialized
2013-08-07 12:49:08 +03:00 --- debug: Session Library initialized
2013-08-07 12:49:08 +03:00 --- debug: Auth Library loaded
2013-08-07 12:49:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:49:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:49:08 +03:00 --- debug: Database Library initialized
2013-08-07 12:49:08 +03:00 --- debug: Session Library initialized
2013-08-07 12:49:08 +03:00 --- debug: Auth Library loaded
2013-08-07 12:49:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:49:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:49:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:49:08 +03:00 --- debug: Database Library initialized
2013-08-07 12:49:08 +03:00 --- debug: Session Library initialized
2013-08-07 12:49:08 +03:00 --- debug: Auth Library loaded
2013-08-07 12:49:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:49:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:49:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:49:44 +03:00 --- debug: Database Library initialized
2013-08-07 12:49:44 +03:00 --- debug: Session Library initialized
2013-08-07 12:49:44 +03:00 --- debug: Auth Library loaded
2013-08-07 12:49:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:49:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:49:47 +03:00 --- debug: Database Library initialized
2013-08-07 12:49:47 +03:00 --- debug: Session Library initialized
2013-08-07 12:49:47 +03:00 --- debug: Auth Library loaded
2013-08-07 12:52:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:52:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:52:03 +03:00 --- debug: Database Library initialized
2013-08-07 12:52:03 +03:00 --- debug: Session Library initialized
2013-08-07 12:52:03 +03:00 --- debug: Auth Library loaded
2013-08-07 12:52:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:52:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:52:03 +03:00 --- debug: Database Library initialized
2013-08-07 12:52:03 +03:00 --- debug: Session Library initialized
2013-08-07 12:52:03 +03:00 --- debug: Auth Library loaded
2013-08-07 12:52:03 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:55:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:55:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:55:08 +03:00 --- debug: Database Library initialized
2013-08-07 12:55:08 +03:00 --- debug: Session Library initialized
2013-08-07 12:55:08 +03:00 --- debug: Auth Library loaded
2013-08-07 12:55:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:55:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:55:08 +03:00 --- debug: Database Library initialized
2013-08-07 12:55:08 +03:00 --- debug: Session Library initialized
2013-08-07 12:55:08 +03:00 --- debug: Auth Library loaded
2013-08-07 12:55:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:56:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:56:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:56:18 +03:00 --- debug: Database Library initialized
2013-08-07 12:56:18 +03:00 --- debug: Session Library initialized
2013-08-07 12:56:18 +03:00 --- debug: Auth Library loaded
2013-08-07 12:56:18 +03:00 --- error: Не пойманное Kohana_Exception: Свойство nameж не входит в состав класса Product_Model. в файле /home/adok/WWW/prupravy.local/system/libraries/ORM.php, на строке 364
2013-08-07 12:56:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:56:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:56:18 +03:00 --- debug: Database Library initialized
2013-08-07 12:56:18 +03:00 --- debug: Session Library initialized
2013-08-07 12:56:18 +03:00 --- debug: Auth Library loaded
2013-08-07 12:56:18 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:56:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:56:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:56:30 +03:00 --- debug: Database Library initialized
2013-08-07 12:56:30 +03:00 --- debug: Session Library initialized
2013-08-07 12:56:30 +03:00 --- debug: Auth Library loaded
2013-08-07 12:56:30 +03:00 --- error: Не пойманное Kohana_Exception: Свойство name не входит в состав класса Product_Model. в файле /home/adok/WWW/prupravy.local/system/libraries/ORM.php, на строке 364
2013-08-07 12:56:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:56:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:56:30 +03:00 --- debug: Database Library initialized
2013-08-07 12:56:30 +03:00 --- debug: Session Library initialized
2013-08-07 12:56:30 +03:00 --- debug: Auth Library loaded
2013-08-07 12:56:30 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:56:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:56:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:56:42 +03:00 --- debug: Database Library initialized
2013-08-07 12:56:42 +03:00 --- debug: Session Library initialized
2013-08-07 12:56:42 +03:00 --- debug: Auth Library loaded
2013-08-07 12:56:42 +03:00 --- error: Не пойманное Kohana_Exception: Свойство name не входит в состав класса Product_Model. в файле /home/adok/WWW/prupravy.local/system/libraries/ORM.php, на строке 364
2013-08-07 12:56:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:56:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:56:42 +03:00 --- debug: Database Library initialized
2013-08-07 12:56:42 +03:00 --- debug: Session Library initialized
2013-08-07 12:56:42 +03:00 --- debug: Auth Library loaded
2013-08-07 12:56:42 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:56:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:56:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:56:58 +03:00 --- debug: Database Library initialized
2013-08-07 12:56:58 +03:00 --- debug: Session Library initialized
2013-08-07 12:56:58 +03:00 --- debug: Auth Library loaded
2013-08-07 12:56:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:56:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:56:58 +03:00 --- debug: Database Library initialized
2013-08-07 12:56:58 +03:00 --- debug: Session Library initialized
2013-08-07 12:56:58 +03:00 --- debug: Auth Library loaded
2013-08-07 12:56:58 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/products/3/pr_small.jpg, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:56:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:56:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:56:58 +03:00 --- debug: Database Library initialized
2013-08-07 12:56:58 +03:00 --- debug: Session Library initialized
2013-08-07 12:56:58 +03:00 --- debug: Auth Library loaded
2013-08-07 12:56:58 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/products/4/pr_small.jpg, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:56:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:56:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:56:58 +03:00 --- debug: Database Library initialized
2013-08-07 12:56:58 +03:00 --- debug: Session Library initialized
2013-08-07 12:56:58 +03:00 --- debug: Auth Library loaded
2013-08-07 12:56:58 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:59:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:59:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:59:29 +03:00 --- debug: Database Library initialized
2013-08-07 12:59:29 +03:00 --- debug: Session Library initialized
2013-08-07 12:59:29 +03:00 --- debug: Auth Library loaded
2013-08-07 12:59:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:59:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:59:29 +03:00 --- debug: Database Library initialized
2013-08-07 12:59:29 +03:00 --- debug: Session Library initialized
2013-08-07 12:59:29 +03:00 --- debug: Auth Library loaded
2013-08-07 12:59:29 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:59:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:59:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:59:29 +03:00 --- debug: Database Library initialized
2013-08-07 12:59:29 +03:00 --- debug: Session Library initialized
2013-08-07 12:59:29 +03:00 --- debug: Auth Library loaded
2013-08-07 12:59:29 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:59:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:59:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:59:34 +03:00 --- debug: Database Library initialized
2013-08-07 12:59:34 +03:00 --- debug: Session Library initialized
2013-08-07 12:59:34 +03:00 --- debug: Auth Library loaded
2013-08-07 12:59:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:59:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:59:34 +03:00 --- debug: Database Library initialized
2013-08-07 12:59:34 +03:00 --- debug: Session Library initialized
2013-08-07 12:59:34 +03:00 --- debug: Auth Library loaded
2013-08-07 12:59:34 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:59:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:59:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:59:34 +03:00 --- debug: Database Library initialized
2013-08-07 12:59:34 +03:00 --- debug: Session Library initialized
2013-08-07 12:59:34 +03:00 --- debug: Auth Library loaded
2013-08-07 12:59:34 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:59:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:59:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:59:38 +03:00 --- debug: Database Library initialized
2013-08-07 12:59:38 +03:00 --- debug: Session Library initialized
2013-08-07 12:59:38 +03:00 --- debug: Auth Library loaded
2013-08-07 12:59:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:59:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:59:38 +03:00 --- debug: Database Library initialized
2013-08-07 12:59:38 +03:00 --- debug: Session Library initialized
2013-08-07 12:59:38 +03:00 --- debug: Auth Library loaded
2013-08-07 12:59:38 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:59:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:59:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:59:38 +03:00 --- debug: Database Library initialized
2013-08-07 12:59:38 +03:00 --- debug: Session Library initialized
2013-08-07 12:59:38 +03:00 --- debug: Auth Library loaded
2013-08-07 12:59:38 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:59:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:59:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:59:43 +03:00 --- debug: Database Library initialized
2013-08-07 12:59:43 +03:00 --- debug: Session Library initialized
2013-08-07 12:59:43 +03:00 --- debug: Auth Library loaded
2013-08-07 12:59:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:59:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:59:43 +03:00 --- debug: Database Library initialized
2013-08-07 12:59:43 +03:00 --- debug: Session Library initialized
2013-08-07 12:59:43 +03:00 --- debug: Auth Library loaded
2013-08-07 12:59:43 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:59:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:59:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:59:43 +03:00 --- debug: Database Library initialized
2013-08-07 12:59:43 +03:00 --- debug: Session Library initialized
2013-08-07 12:59:43 +03:00 --- debug: Auth Library loaded
2013-08-07 12:59:43 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 12:59:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:59:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:59:46 +03:00 --- debug: Database Library initialized
2013-08-07 12:59:46 +03:00 --- debug: Session Library initialized
2013-08-07 12:59:46 +03:00 --- debug: Auth Library loaded
2013-08-07 12:59:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 12:59:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 12:59:46 +03:00 --- debug: Database Library initialized
2013-08-07 12:59:46 +03:00 --- debug: Session Library initialized
2013-08-07 12:59:46 +03:00 --- debug: Auth Library loaded
2013-08-07 12:59:46 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:00:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:00:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:00:51 +03:00 --- debug: Database Library initialized
2013-08-07 13:00:51 +03:00 --- debug: Session Library initialized
2013-08-07 13:00:51 +03:00 --- debug: Auth Library loaded
2013-08-07 13:00:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:00:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:00:51 +03:00 --- debug: Database Library initialized
2013-08-07 13:00:51 +03:00 --- debug: Session Library initialized
2013-08-07 13:00:51 +03:00 --- debug: Auth Library loaded
2013-08-07 13:00:51 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:01:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:01:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:01:28 +03:00 --- debug: Database Library initialized
2013-08-07 13:01:28 +03:00 --- debug: Session Library initialized
2013-08-07 13:01:28 +03:00 --- debug: Auth Library loaded
2013-08-07 13:01:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:01:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:01:28 +03:00 --- debug: Database Library initialized
2013-08-07 13:01:28 +03:00 --- debug: Session Library initialized
2013-08-07 13:01:28 +03:00 --- debug: Auth Library loaded
2013-08-07 13:01:28 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:34:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:34:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:34:36 +03:00 --- debug: Database Library initialized
2013-08-07 13:34:36 +03:00 --- debug: Session Library initialized
2013-08-07 13:34:36 +03:00 --- debug: Auth Library loaded
2013-08-07 13:34:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:34:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:34:36 +03:00 --- debug: Database Library initialized
2013-08-07 13:34:36 +03:00 --- debug: Session Library initialized
2013-08-07 13:34:36 +03:00 --- debug: Auth Library loaded
2013-08-07 13:34:36 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:34:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:34:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:34:40 +03:00 --- debug: Database Library initialized
2013-08-07 13:34:40 +03:00 --- debug: Session Library initialized
2013-08-07 13:34:40 +03:00 --- debug: Auth Library loaded
2013-08-07 13:34:40 +03:00 --- error: Не пойманное PHP Error: Undefined variable: lang в файле /home/adok/WWW/prupravy.local/application/views/product_box.php, на строке 5
2013-08-07 13:34:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:34:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:34:40 +03:00 --- debug: Database Library initialized
2013-08-07 13:34:40 +03:00 --- debug: Session Library initialized
2013-08-07 13:34:40 +03:00 --- debug: Auth Library loaded
2013-08-07 13:34:40 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:34:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:34:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:34:44 +03:00 --- debug: Database Library initialized
2013-08-07 13:34:44 +03:00 --- debug: Session Library initialized
2013-08-07 13:34:44 +03:00 --- debug: Auth Library loaded
2013-08-07 13:34:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:34:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:34:44 +03:00 --- debug: Database Library initialized
2013-08-07 13:34:44 +03:00 --- debug: Session Library initialized
2013-08-07 13:34:44 +03:00 --- debug: Auth Library loaded
2013-08-07 13:34:44 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:35:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:12 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:12 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:12 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:12 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:12 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:12 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:12 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:35:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:14 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:14 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:14 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:14 +03:00 --- error: Не пойманное PHP Error: Undefined variable: lang в файле /home/adok/WWW/prupravy.local/application/views/product_box.php, на строке 5
2013-08-07 13:35:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:14 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:14 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:14 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:14 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:35:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:30 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:30 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:30 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:30 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:30 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:30 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:30 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:35:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:33 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:33 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:33 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:33 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:33 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:33 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:33 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:35:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:34 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:34 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:34 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:34 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:34 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:34 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:34 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:35:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:35 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:35 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:35 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:35 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:35 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:35 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:35 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:35 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:35 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:35 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:35:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:35 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:35 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:35 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:35 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:35 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:35 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:35 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:35:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:35 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:35 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:35 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:35 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:35:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:35 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:35 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:35 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:35 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:35 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:35 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:36 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:35:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:37 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:37 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:37 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:37 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:37 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:37 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:37 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:35:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:39 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:39 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:39 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:35:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:35:39 +03:00 --- debug: Database Library initialized
2013-08-07 13:35:39 +03:00 --- debug: Session Library initialized
2013-08-07 13:35:39 +03:00 --- debug: Auth Library loaded
2013-08-07 13:35:39 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:36:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:40 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:40 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:40 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:40 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:40 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:40 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:40 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:36:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:40 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:40 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:40 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:41 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:41 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:41 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:41 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:36:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:41 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:41 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:41 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:41 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:41 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:41 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:41 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:36:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:41 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:41 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:41 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:41 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:41 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:41 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:41 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:41 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:41 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:41 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:36:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:41 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:41 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:41 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:41 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:41 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:41 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:41 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:36:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:42 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:42 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:42 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:36:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:42 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:42 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:42 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:36:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:42 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:42 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:42 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:36:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:42 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:42 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:42 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:36:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:42 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:42 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:42 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:36:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:42 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:42 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:42 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:42 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:36:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:43 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:43 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:43 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:43 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:36:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:43 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:43 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:43 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:43 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:43 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:43 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:43 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:43 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:43 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:43 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:36:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:36:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:36:43 +03:00 --- debug: Database Library initialized
2013-08-07 13:36:43 +03:00 --- debug: Session Library initialized
2013-08-07 13:36:43 +03:00 --- debug: Auth Library loaded
2013-08-07 13:36:43 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:37:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:37:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:37:37 +03:00 --- debug: Database Library initialized
2013-08-07 13:37:37 +03:00 --- debug: Session Library initialized
2013-08-07 13:37:37 +03:00 --- debug: Auth Library loaded
2013-08-07 13:37:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:37:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:37:37 +03:00 --- debug: Database Library initialized
2013-08-07 13:37:37 +03:00 --- debug: Session Library initialized
2013-08-07 13:37:37 +03:00 --- debug: Auth Library loaded
2013-08-07 13:37:37 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:37:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:37:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:37:38 +03:00 --- debug: Database Library initialized
2013-08-07 13:37:38 +03:00 --- debug: Session Library initialized
2013-08-07 13:37:38 +03:00 --- debug: Auth Library loaded
2013-08-07 13:37:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:37:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:37:38 +03:00 --- debug: Database Library initialized
2013-08-07 13:37:38 +03:00 --- debug: Session Library initialized
2013-08-07 13:37:38 +03:00 --- debug: Auth Library loaded
2013-08-07 13:37:38 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:37:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:37:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:37:38 +03:00 --- debug: Database Library initialized
2013-08-07 13:37:38 +03:00 --- debug: Session Library initialized
2013-08-07 13:37:38 +03:00 --- debug: Auth Library loaded
2013-08-07 13:37:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:37:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:37:38 +03:00 --- debug: Database Library initialized
2013-08-07 13:37:38 +03:00 --- debug: Session Library initialized
2013-08-07 13:37:38 +03:00 --- debug: Auth Library loaded
2013-08-07 13:37:38 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:37:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:37:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:37:38 +03:00 --- debug: Database Library initialized
2013-08-07 13:37:38 +03:00 --- debug: Session Library initialized
2013-08-07 13:37:38 +03:00 --- debug: Auth Library loaded
2013-08-07 13:37:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:37:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:37:38 +03:00 --- debug: Database Library initialized
2013-08-07 13:37:38 +03:00 --- debug: Session Library initialized
2013-08-07 13:37:38 +03:00 --- debug: Auth Library loaded
2013-08-07 13:37:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:37:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:37:38 +03:00 --- debug: Database Library initialized
2013-08-07 13:37:38 +03:00 --- debug: Session Library initialized
2013-08-07 13:37:38 +03:00 --- debug: Auth Library loaded
2013-08-07 13:37:38 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:37:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:37:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:37:38 +03:00 --- debug: Database Library initialized
2013-08-07 13:37:38 +03:00 --- debug: Session Library initialized
2013-08-07 13:37:38 +03:00 --- debug: Auth Library loaded
2013-08-07 13:37:38 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:37:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:37:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:37:41 +03:00 --- debug: Database Library initialized
2013-08-07 13:37:41 +03:00 --- debug: Session Library initialized
2013-08-07 13:37:41 +03:00 --- debug: Auth Library loaded
2013-08-07 13:37:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:37:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:37:41 +03:00 --- debug: Database Library initialized
2013-08-07 13:37:41 +03:00 --- debug: Session Library initialized
2013-08-07 13:37:41 +03:00 --- debug: Auth Library loaded
2013-08-07 13:37:41 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:37:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:37:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:37:42 +03:00 --- debug: Database Library initialized
2013-08-07 13:37:42 +03:00 --- debug: Session Library initialized
2013-08-07 13:37:42 +03:00 --- debug: Auth Library loaded
2013-08-07 13:37:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:37:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:37:43 +03:00 --- debug: Database Library initialized
2013-08-07 13:37:43 +03:00 --- debug: Session Library initialized
2013-08-07 13:37:43 +03:00 --- debug: Auth Library loaded
2013-08-07 13:37:43 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:38:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:38:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:38:12 +03:00 --- debug: Database Library initialized
2013-08-07 13:38:12 +03:00 --- debug: Session Library initialized
2013-08-07 13:38:12 +03:00 --- debug: Auth Library loaded
2013-08-07 13:38:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:38:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:38:12 +03:00 --- debug: Database Library initialized
2013-08-07 13:38:12 +03:00 --- debug: Session Library initialized
2013-08-07 13:38:12 +03:00 --- debug: Auth Library loaded
2013-08-07 13:38:12 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:38:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:38:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:38:14 +03:00 --- debug: Database Library initialized
2013-08-07 13:38:14 +03:00 --- debug: Session Library initialized
2013-08-07 13:38:14 +03:00 --- debug: Auth Library loaded
2013-08-07 13:38:14 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox-x.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:38:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:38:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:38:14 +03:00 --- debug: Database Library initialized
2013-08-07 13:38:14 +03:00 --- debug: Session Library initialized
2013-08-07 13:38:14 +03:00 --- debug: Auth Library loaded
2013-08-07 13:38:14 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:38:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:38:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:38:14 +03:00 --- debug: Database Library initialized
2013-08-07 13:38:14 +03:00 --- debug: Session Library initialized
2013-08-07 13:38:14 +03:00 --- debug: Auth Library loaded
2013-08-07 13:38:14 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/blank.gif, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:38:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:38:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:38:14 +03:00 --- debug: Database Library initialized
2013-08-07 13:38:14 +03:00 --- debug: Session Library initialized
2013-08-07 13:38:14 +03:00 --- debug: Auth Library loaded
2013-08-07 13:38:14 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox-y.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:38:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:38:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:38:31 +03:00 --- debug: Database Library initialized
2013-08-07 13:38:31 +03:00 --- debug: Session Library initialized
2013-08-07 13:38:31 +03:00 --- debug: Auth Library loaded
2013-08-07 13:38:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:38:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:38:31 +03:00 --- debug: Database Library initialized
2013-08-07 13:38:31 +03:00 --- debug: Session Library initialized
2013-08-07 13:38:31 +03:00 --- debug: Auth Library loaded
2013-08-07 13:38:31 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:04 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:04 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:04 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:05 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:05 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:05 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:05 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:05 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:05 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:05 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:05 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:05 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:05 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:05 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:06 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:06 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:06 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:06 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:06 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:06 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:06 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:07 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:07 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:07 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:07 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:07 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:07 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:07 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:07 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:07 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:07 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:08 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:08 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:08 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:08 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:08 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:08 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:08 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:08 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:08 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:08 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:08 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:08 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:08 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:08 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:08 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:08 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:08 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:08 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:08 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:08 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:08 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:08 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:08 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:08 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:09 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:09 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:09 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:09 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:09 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:09 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:09 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:09 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:09 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:09 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:09 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:09 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:09 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:09 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:09 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:09 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:09 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:09 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:09 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:09 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:09 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:09 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:09 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:09 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:09 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:09 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:09 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:09 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:09 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:09 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:09 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:09 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:09 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:09 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:09 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:10 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:10 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:10 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:10 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:10 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:10 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:10 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:10 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:10 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:10 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:10 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:10 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:10 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:10 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:10 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:10 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:10 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:10 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:11 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:11 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:11 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:11 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:11 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:11 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:11 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:13 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:13 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:13 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:13 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:13 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:13 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:13 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:13 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:13 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:13 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:13 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox-x.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:13 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:13 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:13 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:13 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/blank.gif, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:13 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:13 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:13 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:13 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox-y.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:34 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:34 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:34 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:34 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:34 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:34 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:34 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:37 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:37 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:37 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:37 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:37 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:37 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:37 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:37 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:37 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:37 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:37 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox-y.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:37 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:37 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:37 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:37 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox-x.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:37 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:37 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:37 +03:00 --- debug: Auth Library loaded
2013-08-07 13:40:37 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/blank.gif, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:40:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:40:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:40:41 +03:00 --- debug: Database Library initialized
2013-08-07 13:40:41 +03:00 --- debug: Session Library initialized
2013-08-07 13:40:41 +03:00 --- debug: Auth Library loaded
2013-08-07 13:41:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:41:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:41:39 +03:00 --- debug: Database Library initialized
2013-08-07 13:41:39 +03:00 --- debug: Session Library initialized
2013-08-07 13:41:39 +03:00 --- debug: Auth Library loaded
2013-08-07 13:41:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:41:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:41:39 +03:00 --- debug: Database Library initialized
2013-08-07 13:41:39 +03:00 --- debug: Session Library initialized
2013-08-07 13:41:39 +03:00 --- debug: Auth Library loaded
2013-08-07 13:41:39 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:41:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:41:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:41:41 +03:00 --- debug: Database Library initialized
2013-08-07 13:41:41 +03:00 --- debug: Session Library initialized
2013-08-07 13:41:41 +03:00 --- debug: Auth Library loaded
2013-08-07 13:41:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:41:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:41:41 +03:00 --- debug: Database Library initialized
2013-08-07 13:41:41 +03:00 --- debug: Session Library initialized
2013-08-07 13:41:41 +03:00 --- debug: Auth Library loaded
2013-08-07 13:41:41 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:41:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:41:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:41:41 +03:00 --- debug: Database Library initialized
2013-08-07 13:41:41 +03:00 --- debug: Session Library initialized
2013-08-07 13:41:41 +03:00 --- debug: Auth Library loaded
2013-08-07 13:41:41 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox-x.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:41:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:41:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:41:41 +03:00 --- debug: Database Library initialized
2013-08-07 13:41:41 +03:00 --- debug: Session Library initialized
2013-08-07 13:41:41 +03:00 --- debug: Auth Library loaded
2013-08-07 13:41:41 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox-y.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:41:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:41:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:41:41 +03:00 --- debug: Database Library initialized
2013-08-07 13:41:41 +03:00 --- debug: Session Library initialized
2013-08-07 13:41:41 +03:00 --- debug: Auth Library loaded
2013-08-07 13:41:41 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/blank.gif, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:42:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:42:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:42:32 +03:00 --- debug: Database Library initialized
2013-08-07 13:42:32 +03:00 --- debug: Session Library initialized
2013-08-07 13:42:32 +03:00 --- debug: Auth Library loaded
2013-08-07 13:42:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:42:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:42:49 +03:00 --- debug: Database Library initialized
2013-08-07 13:42:49 +03:00 --- debug: Session Library initialized
2013-08-07 13:42:49 +03:00 --- debug: Auth Library loaded
2013-08-07 13:42:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:42:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:42:52 +03:00 --- debug: Database Library initialized
2013-08-07 13:42:52 +03:00 --- debug: Session Library initialized
2013-08-07 13:42:52 +03:00 --- debug: Auth Library loaded
2013-08-07 13:42:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:42:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:42:52 +03:00 --- debug: Database Library initialized
2013-08-07 13:42:52 +03:00 --- debug: Session Library initialized
2013-08-07 13:42:52 +03:00 --- debug: Auth Library loaded
2013-08-07 13:42:52 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:42:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:42:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:42:53 +03:00 --- debug: Database Library initialized
2013-08-07 13:42:53 +03:00 --- debug: Session Library initialized
2013-08-07 13:42:53 +03:00 --- debug: Auth Library loaded
2013-08-07 13:43:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:43:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:43:06 +03:00 --- debug: Database Library initialized
2013-08-07 13:43:06 +03:00 --- debug: Session Library initialized
2013-08-07 13:43:06 +03:00 --- debug: Auth Library loaded
2013-08-07 13:43:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:43:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:43:09 +03:00 --- debug: Database Library initialized
2013-08-07 13:43:09 +03:00 --- debug: Session Library initialized
2013-08-07 13:43:09 +03:00 --- debug: Auth Library loaded
2013-08-07 13:43:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:43:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:43:09 +03:00 --- debug: Database Library initialized
2013-08-07 13:43:09 +03:00 --- debug: Session Library initialized
2013-08-07 13:43:09 +03:00 --- debug: Auth Library loaded
2013-08-07 13:43:09 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:43:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:43:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:43:11 +03:00 --- debug: Database Library initialized
2013-08-07 13:43:11 +03:00 --- debug: Session Library initialized
2013-08-07 13:43:11 +03:00 --- debug: Auth Library loaded
2013-08-07 13:43:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:43:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:43:11 +03:00 --- debug: Database Library initialized
2013-08-07 13:43:11 +03:00 --- debug: Session Library initialized
2013-08-07 13:43:11 +03:00 --- debug: Auth Library loaded
2013-08-07 13:43:11 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:43:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:43:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:43:12 +03:00 --- debug: Database Library initialized
2013-08-07 13:43:12 +03:00 --- debug: Session Library initialized
2013-08-07 13:43:12 +03:00 --- debug: Auth Library loaded
2013-08-07 13:43:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:43:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:43:12 +03:00 --- debug: Database Library initialized
2013-08-07 13:43:12 +03:00 --- debug: Session Library initialized
2013-08-07 13:43:12 +03:00 --- debug: Auth Library loaded
2013-08-07 13:43:12 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:43:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:43:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:43:12 +03:00 --- debug: Database Library initialized
2013-08-07 13:43:12 +03:00 --- debug: Session Library initialized
2013-08-07 13:43:12 +03:00 --- debug: Auth Library loaded
2013-08-07 13:43:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:43:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:43:12 +03:00 --- debug: Database Library initialized
2013-08-07 13:43:12 +03:00 --- debug: Session Library initialized
2013-08-07 13:43:12 +03:00 --- debug: Auth Library loaded
2013-08-07 13:43:12 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:43:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:43:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:43:13 +03:00 --- debug: Database Library initialized
2013-08-07 13:43:13 +03:00 --- debug: Session Library initialized
2013-08-07 13:43:13 +03:00 --- debug: Auth Library loaded
2013-08-07 13:43:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:43:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:43:15 +03:00 --- debug: Database Library initialized
2013-08-07 13:43:15 +03:00 --- debug: Session Library initialized
2013-08-07 13:43:15 +03:00 --- debug: Auth Library loaded
2013-08-07 13:43:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:43:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:43:17 +03:00 --- debug: Database Library initialized
2013-08-07 13:43:17 +03:00 --- debug: Session Library initialized
2013-08-07 13:43:17 +03:00 --- debug: Auth Library loaded
2013-08-07 13:43:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:43:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:43:19 +03:00 --- debug: Database Library initialized
2013-08-07 13:43:19 +03:00 --- debug: Session Library initialized
2013-08-07 13:43:19 +03:00 --- debug: Auth Library loaded
2013-08-07 13:44:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:44:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:44:41 +03:00 --- debug: Database Library initialized
2013-08-07 13:44:41 +03:00 --- debug: Session Library initialized
2013-08-07 13:44:41 +03:00 --- debug: Auth Library loaded
2013-08-07 13:44:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:44:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:44:41 +03:00 --- debug: Database Library initialized
2013-08-07 13:44:41 +03:00 --- debug: Session Library initialized
2013-08-07 13:44:41 +03:00 --- debug: Auth Library loaded
2013-08-07 13:44:41 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:44:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:44:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:44:43 +03:00 --- debug: Database Library initialized
2013-08-07 13:44:43 +03:00 --- debug: Session Library initialized
2013-08-07 13:44:43 +03:00 --- debug: Auth Library loaded
2013-08-07 13:44:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:44:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:44:51 +03:00 --- debug: Database Library initialized
2013-08-07 13:44:51 +03:00 --- debug: Session Library initialized
2013-08-07 13:44:51 +03:00 --- debug: Auth Library loaded
2013-08-07 13:44:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:44:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:44:53 +03:00 --- debug: Database Library initialized
2013-08-07 13:44:53 +03:00 --- debug: Session Library initialized
2013-08-07 13:44:53 +03:00 --- debug: Auth Library loaded
2013-08-07 13:44:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:44:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:44:53 +03:00 --- debug: Database Library initialized
2013-08-07 13:44:53 +03:00 --- debug: Session Library initialized
2013-08-07 13:44:53 +03:00 --- debug: Auth Library loaded
2013-08-07 13:44:53 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:44:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:44:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:44:54 +03:00 --- debug: Database Library initialized
2013-08-07 13:44:54 +03:00 --- debug: Session Library initialized
2013-08-07 13:44:54 +03:00 --- debug: Auth Library loaded
2013-08-07 13:44:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:44:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:44:56 +03:00 --- debug: Database Library initialized
2013-08-07 13:44:56 +03:00 --- debug: Session Library initialized
2013-08-07 13:44:56 +03:00 --- debug: Auth Library loaded
2013-08-07 13:51:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:51:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:51:04 +03:00 --- debug: Database Library initialized
2013-08-07 13:51:04 +03:00 --- debug: Session Library initialized
2013-08-07 13:51:04 +03:00 --- debug: Auth Library loaded
2013-08-07 13:51:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:51:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:51:06 +03:00 --- debug: Database Library initialized
2013-08-07 13:51:06 +03:00 --- debug: Session Library initialized
2013-08-07 13:51:06 +03:00 --- debug: Auth Library loaded
2013-08-07 13:51:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:51:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:51:06 +03:00 --- debug: Database Library initialized
2013-08-07 13:51:06 +03:00 --- debug: Session Library initialized
2013-08-07 13:51:06 +03:00 --- debug: Auth Library loaded
2013-08-07 13:51:06 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:51:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:51:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:51:07 +03:00 --- debug: Database Library initialized
2013-08-07 13:51:07 +03:00 --- debug: Session Library initialized
2013-08-07 13:51:07 +03:00 --- debug: Auth Library loaded
2013-08-07 13:51:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:51:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:51:07 +03:00 --- debug: Database Library initialized
2013-08-07 13:51:07 +03:00 --- debug: Session Library initialized
2013-08-07 13:51:07 +03:00 --- debug: Auth Library loaded
2013-08-07 13:51:07 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:51:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:51:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:51:07 +03:00 --- debug: Database Library initialized
2013-08-07 13:51:07 +03:00 --- debug: Session Library initialized
2013-08-07 13:51:07 +03:00 --- debug: Auth Library loaded
2013-08-07 13:51:07 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox-y.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:51:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:51:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:51:07 +03:00 --- debug: Database Library initialized
2013-08-07 13:51:07 +03:00 --- debug: Session Library initialized
2013-08-07 13:51:07 +03:00 --- debug: Auth Library loaded
2013-08-07 13:51:07 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox-x.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:51:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:51:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:51:07 +03:00 --- debug: Database Library initialized
2013-08-07 13:51:07 +03:00 --- debug: Session Library initialized
2013-08-07 13:51:07 +03:00 --- debug: Auth Library loaded
2013-08-07 13:51:07 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/blank.gif, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:51:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:51:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:51:11 +03:00 --- debug: Database Library initialized
2013-08-07 13:51:11 +03:00 --- debug: Session Library initialized
2013-08-07 13:51:11 +03:00 --- debug: Auth Library loaded
2013-08-07 13:51:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:51:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:51:14 +03:00 --- debug: Database Library initialized
2013-08-07 13:51:14 +03:00 --- debug: Session Library initialized
2013-08-07 13:51:14 +03:00 --- debug: Auth Library loaded
2013-08-07 13:51:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:51:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:51:19 +03:00 --- debug: Database Library initialized
2013-08-07 13:51:19 +03:00 --- debug: Session Library initialized
2013-08-07 13:51:19 +03:00 --- debug: Auth Library loaded
2013-08-07 13:54:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:54:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:54:17 +03:00 --- debug: Database Library initialized
2013-08-07 13:54:17 +03:00 --- debug: Session Library initialized
2013-08-07 13:54:17 +03:00 --- debug: Auth Library loaded
2013-08-07 13:54:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:54:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:54:18 +03:00 --- debug: Database Library initialized
2013-08-07 13:54:18 +03:00 --- debug: Session Library initialized
2013-08-07 13:54:18 +03:00 --- debug: Auth Library loaded
2013-08-07 13:54:18 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:54:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:54:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:54:38 +03:00 --- debug: Database Library initialized
2013-08-07 13:54:38 +03:00 --- debug: Session Library initialized
2013-08-07 13:54:38 +03:00 --- debug: Auth Library loaded
2013-08-07 13:54:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:54:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:54:38 +03:00 --- debug: Database Library initialized
2013-08-07 13:54:38 +03:00 --- debug: Session Library initialized
2013-08-07 13:54:38 +03:00 --- debug: Auth Library loaded
2013-08-07 13:54:38 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:54:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:54:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:54:57 +03:00 --- debug: Database Library initialized
2013-08-07 13:54:57 +03:00 --- debug: Session Library initialized
2013-08-07 13:54:57 +03:00 --- debug: Auth Library loaded
2013-08-07 13:54:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:54:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:54:58 +03:00 --- debug: Database Library initialized
2013-08-07 13:54:58 +03:00 --- debug: Session Library initialized
2013-08-07 13:54:58 +03:00 --- debug: Auth Library loaded
2013-08-07 13:54:58 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:54:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:54:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:54:59 +03:00 --- debug: Database Library initialized
2013-08-07 13:54:59 +03:00 --- debug: Session Library initialized
2013-08-07 13:54:59 +03:00 --- debug: Auth Library loaded
2013-08-07 13:55:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:55:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:55:20 +03:00 --- debug: Database Library initialized
2013-08-07 13:55:20 +03:00 --- debug: Session Library initialized
2013-08-07 13:55:20 +03:00 --- debug: Auth Library loaded
2013-08-07 13:55:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:55:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:55:21 +03:00 --- debug: Database Library initialized
2013-08-07 13:55:21 +03:00 --- debug: Session Library initialized
2013-08-07 13:55:21 +03:00 --- debug: Auth Library loaded
2013-08-07 13:55:21 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:55:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:55:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:55:24 +03:00 --- debug: Database Library initialized
2013-08-07 13:55:24 +03:00 --- debug: Session Library initialized
2013-08-07 13:55:24 +03:00 --- debug: Auth Library loaded
2013-08-07 13:55:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:55:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:55:49 +03:00 --- debug: Database Library initialized
2013-08-07 13:55:49 +03:00 --- debug: Session Library initialized
2013-08-07 13:55:49 +03:00 --- debug: Auth Library loaded
2013-08-07 13:55:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:55:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:55:49 +03:00 --- debug: Database Library initialized
2013-08-07 13:55:49 +03:00 --- debug: Session Library initialized
2013-08-07 13:55:49 +03:00 --- debug: Auth Library loaded
2013-08-07 13:55:49 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:55:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:55:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:55:58 +03:00 --- debug: Database Library initialized
2013-08-07 13:55:58 +03:00 --- debug: Session Library initialized
2013-08-07 13:55:58 +03:00 --- debug: Auth Library loaded
2013-08-07 13:56:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:56:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:56:11 +03:00 --- debug: Database Library initialized
2013-08-07 13:56:11 +03:00 --- debug: Session Library initialized
2013-08-07 13:56:11 +03:00 --- debug: Auth Library loaded
2013-08-07 13:56:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:56:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:56:12 +03:00 --- debug: Database Library initialized
2013-08-07 13:56:12 +03:00 --- debug: Session Library initialized
2013-08-07 13:56:12 +03:00 --- debug: Auth Library loaded
2013-08-07 13:56:12 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:56:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:56:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:56:14 +03:00 --- debug: Database Library initialized
2013-08-07 13:56:14 +03:00 --- debug: Session Library initialized
2013-08-07 13:56:14 +03:00 --- debug: Auth Library loaded
2013-08-07 13:58:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:58:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:58:01 +03:00 --- debug: Database Library initialized
2013-08-07 13:58:01 +03:00 --- debug: Session Library initialized
2013-08-07 13:58:01 +03:00 --- debug: Auth Library loaded
2013-08-07 13:58:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:58:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:58:01 +03:00 --- debug: Database Library initialized
2013-08-07 13:58:01 +03:00 --- debug: Session Library initialized
2013-08-07 13:58:01 +03:00 --- debug: Auth Library loaded
2013-08-07 13:58:01 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:58:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:58:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:58:02 +03:00 --- debug: Database Library initialized
2013-08-07 13:58:02 +03:00 --- debug: Session Library initialized
2013-08-07 13:58:02 +03:00 --- debug: Auth Library loaded
2013-08-07 13:59:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:59:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:59:16 +03:00 --- debug: Database Library initialized
2013-08-07 13:59:16 +03:00 --- debug: Session Library initialized
2013-08-07 13:59:16 +03:00 --- debug: Auth Library loaded
2013-08-07 13:59:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:59:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:59:17 +03:00 --- debug: Database Library initialized
2013-08-07 13:59:17 +03:00 --- debug: Session Library initialized
2013-08-07 13:59:17 +03:00 --- debug: Auth Library loaded
2013-08-07 13:59:17 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 13:59:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 13:59:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 13:59:28 +03:00 --- debug: Database Library initialized
2013-08-07 13:59:28 +03:00 --- debug: Session Library initialized
2013-08-07 13:59:28 +03:00 --- debug: Auth Library loaded
2013-08-07 14:00:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:00:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:00:22 +03:00 --- debug: Database Library initialized
2013-08-07 14:00:22 +03:00 --- debug: Session Library initialized
2013-08-07 14:00:22 +03:00 --- debug: Auth Library loaded
2013-08-07 14:00:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:00:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:00:22 +03:00 --- debug: Database Library initialized
2013-08-07 14:00:22 +03:00 --- debug: Session Library initialized
2013-08-07 14:00:22 +03:00 --- debug: Auth Library loaded
2013-08-07 14:00:22 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:00:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:00:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:00:23 +03:00 --- debug: Database Library initialized
2013-08-07 14:00:23 +03:00 --- debug: Session Library initialized
2013-08-07 14:00:23 +03:00 --- debug: Auth Library loaded
2013-08-07 14:01:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:01:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:01:13 +03:00 --- debug: Database Library initialized
2013-08-07 14:01:13 +03:00 --- debug: Session Library initialized
2013-08-07 14:01:13 +03:00 --- debug: Auth Library loaded
2013-08-07 14:01:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:01:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:01:13 +03:00 --- debug: Database Library initialized
2013-08-07 14:01:13 +03:00 --- debug: Session Library initialized
2013-08-07 14:01:13 +03:00 --- debug: Auth Library loaded
2013-08-07 14:01:13 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:01:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:01:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:01:19 +03:00 --- debug: Database Library initialized
2013-08-07 14:01:19 +03:00 --- debug: Session Library initialized
2013-08-07 14:01:19 +03:00 --- debug: Auth Library loaded
2013-08-07 14:01:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:01:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:01:59 +03:00 --- debug: Database Library initialized
2013-08-07 14:01:59 +03:00 --- debug: Session Library initialized
2013-08-07 14:01:59 +03:00 --- debug: Auth Library loaded
2013-08-07 14:01:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:01:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:01:59 +03:00 --- debug: Database Library initialized
2013-08-07 14:01:59 +03:00 --- debug: Session Library initialized
2013-08-07 14:01:59 +03:00 --- debug: Auth Library loaded
2013-08-07 14:01:59 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:02:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:02:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:02:00 +03:00 --- debug: Database Library initialized
2013-08-07 14:02:00 +03:00 --- debug: Session Library initialized
2013-08-07 14:02:00 +03:00 --- debug: Auth Library loaded
2013-08-07 14:02:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:02:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:02:59 +03:00 --- debug: Database Library initialized
2013-08-07 14:02:59 +03:00 --- debug: Session Library initialized
2013-08-07 14:02:59 +03:00 --- debug: Auth Library loaded
2013-08-07 14:02:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:02:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:02:59 +03:00 --- debug: Database Library initialized
2013-08-07 14:02:59 +03:00 --- debug: Session Library initialized
2013-08-07 14:02:59 +03:00 --- debug: Auth Library loaded
2013-08-07 14:02:59 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:03:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:03:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:03:00 +03:00 --- debug: Database Library initialized
2013-08-07 14:03:00 +03:00 --- debug: Session Library initialized
2013-08-07 14:03:00 +03:00 --- debug: Auth Library loaded
2013-08-07 14:03:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:03:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:03:24 +03:00 --- debug: Database Library initialized
2013-08-07 14:03:24 +03:00 --- debug: Session Library initialized
2013-08-07 14:03:24 +03:00 --- debug: Auth Library loaded
2013-08-07 14:03:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:03:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:03:25 +03:00 --- debug: Database Library initialized
2013-08-07 14:03:25 +03:00 --- debug: Session Library initialized
2013-08-07 14:03:25 +03:00 --- debug: Auth Library loaded
2013-08-07 14:03:25 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:03:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:03:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:03:26 +03:00 --- debug: Database Library initialized
2013-08-07 14:03:26 +03:00 --- debug: Session Library initialized
2013-08-07 14:03:26 +03:00 --- debug: Auth Library loaded
2013-08-07 14:03:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:03:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:03:27 +03:00 --- debug: Database Library initialized
2013-08-07 14:03:27 +03:00 --- debug: Session Library initialized
2013-08-07 14:03:27 +03:00 --- debug: Auth Library loaded
2013-08-07 14:03:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:03:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:03:40 +03:00 --- debug: Database Library initialized
2013-08-07 14:03:40 +03:00 --- debug: Session Library initialized
2013-08-07 14:03:40 +03:00 --- debug: Auth Library loaded
2013-08-07 14:04:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:04:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:04:24 +03:00 --- debug: Database Library initialized
2013-08-07 14:04:24 +03:00 --- debug: Session Library initialized
2013-08-07 14:04:24 +03:00 --- debug: Auth Library loaded
2013-08-07 14:04:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:04:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:04:25 +03:00 --- debug: Database Library initialized
2013-08-07 14:04:25 +03:00 --- debug: Session Library initialized
2013-08-07 14:04:25 +03:00 --- debug: Auth Library loaded
2013-08-07 14:04:25 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:04:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:04:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:04:26 +03:00 --- debug: Database Library initialized
2013-08-07 14:04:26 +03:00 --- debug: Session Library initialized
2013-08-07 14:04:26 +03:00 --- debug: Auth Library loaded
2013-08-07 14:04:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:04:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:04:29 +03:00 --- debug: Database Library initialized
2013-08-07 14:04:29 +03:00 --- debug: Session Library initialized
2013-08-07 14:04:29 +03:00 --- debug: Auth Library loaded
2013-08-07 14:04:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:04:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:04:31 +03:00 --- debug: Database Library initialized
2013-08-07 14:04:31 +03:00 --- debug: Session Library initialized
2013-08-07 14:04:31 +03:00 --- debug: Auth Library loaded
2013-08-07 14:04:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:04:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:04:38 +03:00 --- debug: Database Library initialized
2013-08-07 14:04:38 +03:00 --- debug: Session Library initialized
2013-08-07 14:04:38 +03:00 --- debug: Auth Library loaded
2013-08-07 14:04:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:04:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:04:39 +03:00 --- debug: Database Library initialized
2013-08-07 14:04:39 +03:00 --- debug: Session Library initialized
2013-08-07 14:04:39 +03:00 --- debug: Auth Library loaded
2013-08-07 14:04:39 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:04:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:04:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:04:41 +03:00 --- debug: Database Library initialized
2013-08-07 14:04:41 +03:00 --- debug: Session Library initialized
2013-08-07 14:04:41 +03:00 --- debug: Auth Library loaded
2013-08-07 14:04:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:04:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:04:57 +03:00 --- debug: Database Library initialized
2013-08-07 14:04:57 +03:00 --- debug: Session Library initialized
2013-08-07 14:04:57 +03:00 --- debug: Auth Library loaded
2013-08-07 14:04:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:04:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:04:57 +03:00 --- debug: Database Library initialized
2013-08-07 14:04:57 +03:00 --- debug: Session Library initialized
2013-08-07 14:04:57 +03:00 --- debug: Auth Library loaded
2013-08-07 14:04:57 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:04:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:04:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:04:58 +03:00 --- debug: Database Library initialized
2013-08-07 14:04:58 +03:00 --- debug: Session Library initialized
2013-08-07 14:04:58 +03:00 --- debug: Auth Library loaded
2013-08-07 14:05:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:05:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:05:00 +03:00 --- debug: Database Library initialized
2013-08-07 14:05:00 +03:00 --- debug: Session Library initialized
2013-08-07 14:05:00 +03:00 --- debug: Auth Library loaded
2013-08-07 14:05:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:05:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:05:20 +03:00 --- debug: Database Library initialized
2013-08-07 14:05:20 +03:00 --- debug: Session Library initialized
2013-08-07 14:05:20 +03:00 --- debug: Auth Library loaded
2013-08-07 14:05:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:05:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:05:20 +03:00 --- debug: Database Library initialized
2013-08-07 14:05:20 +03:00 --- debug: Session Library initialized
2013-08-07 14:05:20 +03:00 --- debug: Auth Library loaded
2013-08-07 14:05:20 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:05:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:05:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:05:21 +03:00 --- debug: Database Library initialized
2013-08-07 14:05:21 +03:00 --- debug: Session Library initialized
2013-08-07 14:05:21 +03:00 --- debug: Auth Library loaded
2013-08-07 14:05:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:05:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:05:22 +03:00 --- debug: Database Library initialized
2013-08-07 14:05:22 +03:00 --- debug: Session Library initialized
2013-08-07 14:05:22 +03:00 --- debug: Auth Library loaded
2013-08-07 14:05:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:05:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:05:23 +03:00 --- debug: Database Library initialized
2013-08-07 14:05:23 +03:00 --- debug: Session Library initialized
2013-08-07 14:05:23 +03:00 --- debug: Auth Library loaded
2013-08-07 14:05:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:05:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:05:31 +03:00 --- debug: Database Library initialized
2013-08-07 14:05:31 +03:00 --- debug: Session Library initialized
2013-08-07 14:05:31 +03:00 --- debug: Auth Library loaded
2013-08-07 14:06:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:06:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:06:11 +03:00 --- debug: Database Library initialized
2013-08-07 14:06:11 +03:00 --- debug: Session Library initialized
2013-08-07 14:06:11 +03:00 --- debug: Auth Library loaded
2013-08-07 14:06:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:06:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:06:12 +03:00 --- debug: Database Library initialized
2013-08-07 14:06:12 +03:00 --- debug: Session Library initialized
2013-08-07 14:06:12 +03:00 --- debug: Auth Library loaded
2013-08-07 14:06:12 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:06:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:06:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:06:13 +03:00 --- debug: Database Library initialized
2013-08-07 14:06:13 +03:00 --- debug: Session Library initialized
2013-08-07 14:06:13 +03:00 --- debug: Auth Library loaded
2013-08-07 14:07:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:07:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:07:37 +03:00 --- debug: Database Library initialized
2013-08-07 14:07:37 +03:00 --- debug: Session Library initialized
2013-08-07 14:07:37 +03:00 --- debug: Auth Library loaded
2013-08-07 14:07:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:07:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:07:37 +03:00 --- debug: Database Library initialized
2013-08-07 14:07:37 +03:00 --- debug: Session Library initialized
2013-08-07 14:07:37 +03:00 --- debug: Auth Library loaded
2013-08-07 14:07:37 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:07:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:07:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:07:38 +03:00 --- debug: Database Library initialized
2013-08-07 14:07:38 +03:00 --- debug: Session Library initialized
2013-08-07 14:07:38 +03:00 --- debug: Auth Library loaded
2013-08-07 14:07:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:07:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:07:47 +03:00 --- debug: Database Library initialized
2013-08-07 14:07:47 +03:00 --- debug: Session Library initialized
2013-08-07 14:07:47 +03:00 --- debug: Auth Library loaded
2013-08-07 14:07:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:07:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:07:47 +03:00 --- debug: Database Library initialized
2013-08-07 14:07:47 +03:00 --- debug: Session Library initialized
2013-08-07 14:07:47 +03:00 --- debug: Auth Library loaded
2013-08-07 14:07:47 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:07:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:07:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:07:48 +03:00 --- debug: Database Library initialized
2013-08-07 14:07:48 +03:00 --- debug: Session Library initialized
2013-08-07 14:07:48 +03:00 --- debug: Auth Library loaded
2013-08-07 14:08:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:08:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:08:50 +03:00 --- debug: Database Library initialized
2013-08-07 14:08:50 +03:00 --- debug: Session Library initialized
2013-08-07 14:08:50 +03:00 --- debug: Auth Library loaded
2013-08-07 14:08:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:08:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:08:50 +03:00 --- debug: Database Library initialized
2013-08-07 14:08:50 +03:00 --- debug: Session Library initialized
2013-08-07 14:08:50 +03:00 --- debug: Auth Library loaded
2013-08-07 14:08:50 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:08:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:08:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:08:51 +03:00 --- debug: Database Library initialized
2013-08-07 14:08:51 +03:00 --- debug: Session Library initialized
2013-08-07 14:08:51 +03:00 --- debug: Auth Library loaded
2013-08-07 14:09:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:09:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:09:12 +03:00 --- debug: Database Library initialized
2013-08-07 14:09:12 +03:00 --- debug: Session Library initialized
2013-08-07 14:09:12 +03:00 --- debug: Auth Library loaded
2013-08-07 14:09:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:09:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:09:12 +03:00 --- debug: Database Library initialized
2013-08-07 14:09:12 +03:00 --- debug: Session Library initialized
2013-08-07 14:09:12 +03:00 --- debug: Auth Library loaded
2013-08-07 14:09:12 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:09:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:09:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:09:13 +03:00 --- debug: Database Library initialized
2013-08-07 14:09:13 +03:00 --- debug: Session Library initialized
2013-08-07 14:09:13 +03:00 --- debug: Auth Library loaded
2013-08-07 14:09:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:09:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:09:14 +03:00 --- debug: Database Library initialized
2013-08-07 14:09:14 +03:00 --- debug: Session Library initialized
2013-08-07 14:09:14 +03:00 --- debug: Auth Library loaded
2013-08-07 14:09:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:09:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:09:16 +03:00 --- debug: Database Library initialized
2013-08-07 14:09:16 +03:00 --- debug: Session Library initialized
2013-08-07 14:09:16 +03:00 --- debug: Auth Library loaded
2013-08-07 14:09:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:09:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:09:17 +03:00 --- debug: Database Library initialized
2013-08-07 14:09:17 +03:00 --- debug: Session Library initialized
2013-08-07 14:09:17 +03:00 --- debug: Auth Library loaded
2013-08-07 14:09:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:09:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:09:20 +03:00 --- debug: Database Library initialized
2013-08-07 14:09:20 +03:00 --- debug: Session Library initialized
2013-08-07 14:09:20 +03:00 --- debug: Auth Library loaded
2013-08-07 14:09:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:09:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:09:26 +03:00 --- debug: Database Library initialized
2013-08-07 14:09:26 +03:00 --- debug: Session Library initialized
2013-08-07 14:09:26 +03:00 --- debug: Auth Library loaded
2013-08-07 14:09:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:09:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:09:59 +03:00 --- debug: Database Library initialized
2013-08-07 14:09:59 +03:00 --- debug: Session Library initialized
2013-08-07 14:09:59 +03:00 --- debug: Auth Library loaded
2013-08-07 14:10:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:10:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:10:00 +03:00 --- debug: Database Library initialized
2013-08-07 14:10:00 +03:00 --- debug: Session Library initialized
2013-08-07 14:10:00 +03:00 --- debug: Auth Library loaded
2013-08-07 14:10:00 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:10:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:10:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:10:01 +03:00 --- debug: Database Library initialized
2013-08-07 14:10:01 +03:00 --- debug: Session Library initialized
2013-08-07 14:10:01 +03:00 --- debug: Auth Library loaded
2013-08-07 14:10:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:10:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:10:03 +03:00 --- debug: Database Library initialized
2013-08-07 14:10:03 +03:00 --- debug: Session Library initialized
2013-08-07 14:10:03 +03:00 --- debug: Auth Library loaded
2013-08-07 14:10:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:10:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:10:16 +03:00 --- debug: Database Library initialized
2013-08-07 14:10:16 +03:00 --- debug: Session Library initialized
2013-08-07 14:10:16 +03:00 --- debug: Auth Library loaded
2013-08-07 14:10:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:10:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:10:16 +03:00 --- debug: Database Library initialized
2013-08-07 14:10:16 +03:00 --- debug: Session Library initialized
2013-08-07 14:10:16 +03:00 --- debug: Auth Library loaded
2013-08-07 14:10:16 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:10:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:10:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:10:17 +03:00 --- debug: Database Library initialized
2013-08-07 14:10:17 +03:00 --- debug: Session Library initialized
2013-08-07 14:10:17 +03:00 --- debug: Auth Library loaded
2013-08-07 14:10:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:10:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:10:18 +03:00 --- debug: Database Library initialized
2013-08-07 14:10:18 +03:00 --- debug: Session Library initialized
2013-08-07 14:10:18 +03:00 --- debug: Auth Library loaded
2013-08-07 14:10:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:10:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:10:30 +03:00 --- debug: Database Library initialized
2013-08-07 14:10:30 +03:00 --- debug: Session Library initialized
2013-08-07 14:10:30 +03:00 --- debug: Auth Library loaded
2013-08-07 14:10:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:10:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:10:32 +03:00 --- debug: Database Library initialized
2013-08-07 14:10:32 +03:00 --- debug: Session Library initialized
2013-08-07 14:10:32 +03:00 --- debug: Auth Library loaded
2013-08-07 14:10:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:10:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:10:33 +03:00 --- debug: Database Library initialized
2013-08-07 14:10:33 +03:00 --- debug: Session Library initialized
2013-08-07 14:10:33 +03:00 --- debug: Auth Library loaded
2013-08-07 14:11:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:11:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:11:19 +03:00 --- debug: Database Library initialized
2013-08-07 14:11:19 +03:00 --- debug: Session Library initialized
2013-08-07 14:11:19 +03:00 --- debug: Auth Library loaded
2013-08-07 14:11:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:11:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:11:22 +03:00 --- debug: Database Library initialized
2013-08-07 14:11:22 +03:00 --- debug: Session Library initialized
2013-08-07 14:11:22 +03:00 --- debug: Auth Library loaded
2013-08-07 14:11:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:11:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:11:22 +03:00 --- debug: Database Library initialized
2013-08-07 14:11:22 +03:00 --- debug: Session Library initialized
2013-08-07 14:11:22 +03:00 --- debug: Auth Library loaded
2013-08-07 14:11:22 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/products/6/pr_small.jpg, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:11:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:11:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:11:22 +03:00 --- debug: Database Library initialized
2013-08-07 14:11:22 +03:00 --- debug: Session Library initialized
2013-08-07 14:11:22 +03:00 --- debug: Auth Library loaded
2013-08-07 14:11:22 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/products/5/pr_big.jpg, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:11:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:11:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:11:22 +03:00 --- debug: Database Library initialized
2013-08-07 14:11:22 +03:00 --- debug: Session Library initialized
2013-08-07 14:11:22 +03:00 --- debug: Auth Library loaded
2013-08-07 14:11:22 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/products/5/pr_small.jpg, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:11:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:11:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:11:22 +03:00 --- debug: Database Library initialized
2013-08-07 14:11:22 +03:00 --- debug: Session Library initialized
2013-08-07 14:11:22 +03:00 --- debug: Auth Library loaded
2013-08-07 14:11:22 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/products/6/pr_big.jpg, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:11:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:11:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:11:22 +03:00 --- debug: Database Library initialized
2013-08-07 14:11:22 +03:00 --- debug: Session Library initialized
2013-08-07 14:11:22 +03:00 --- debug: Auth Library loaded
2013-08-07 14:11:22 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/products/7/pr_big.jpg, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:11:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:11:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:11:22 +03:00 --- debug: Database Library initialized
2013-08-07 14:11:22 +03:00 --- debug: Session Library initialized
2013-08-07 14:11:22 +03:00 --- debug: Auth Library loaded
2013-08-07 14:11:22 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/products/8/pr_big.jpg, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:11:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:11:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:11:22 +03:00 --- debug: Database Library initialized
2013-08-07 14:11:22 +03:00 --- debug: Session Library initialized
2013-08-07 14:11:22 +03:00 --- debug: Auth Library loaded
2013-08-07 14:11:22 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/products/8/pr_small.jpg, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:11:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:11:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:11:22 +03:00 --- debug: Database Library initialized
2013-08-07 14:11:22 +03:00 --- debug: Session Library initialized
2013-08-07 14:11:22 +03:00 --- debug: Auth Library loaded
2013-08-07 14:11:22 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/products/7/pr_small.jpg, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:11:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:11:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:11:22 +03:00 --- debug: Database Library initialized
2013-08-07 14:11:22 +03:00 --- debug: Session Library initialized
2013-08-07 14:11:22 +03:00 --- debug: Auth Library loaded
2013-08-07 14:11:22 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:11:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:11:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:11:44 +03:00 --- debug: Database Library initialized
2013-08-07 14:11:44 +03:00 --- debug: Session Library initialized
2013-08-07 14:11:44 +03:00 --- debug: Auth Library loaded
2013-08-07 14:11:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:11:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:11:44 +03:00 --- debug: Database Library initialized
2013-08-07 14:11:44 +03:00 --- debug: Session Library initialized
2013-08-07 14:11:44 +03:00 --- debug: Auth Library loaded
2013-08-07 14:11:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:11:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:11:44 +03:00 --- debug: Database Library initialized
2013-08-07 14:11:44 +03:00 --- debug: Session Library initialized
2013-08-07 14:11:44 +03:00 --- debug: Auth Library loaded
2013-08-07 14:11:44 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:11:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:11:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:11:55 +03:00 --- debug: Database Library initialized
2013-08-07 14:11:55 +03:00 --- debug: Session Library initialized
2013-08-07 14:11:55 +03:00 --- debug: Auth Library loaded
2013-08-07 14:11:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:11:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:11:55 +03:00 --- debug: Database Library initialized
2013-08-07 14:11:55 +03:00 --- debug: Session Library initialized
2013-08-07 14:11:55 +03:00 --- debug: Auth Library loaded
2013-08-07 14:11:55 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:11:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:11:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:11:56 +03:00 --- debug: Database Library initialized
2013-08-07 14:11:56 +03:00 --- debug: Session Library initialized
2013-08-07 14:11:56 +03:00 --- debug: Auth Library loaded
2013-08-07 14:11:56 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:12:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:12:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:12:00 +03:00 --- debug: Database Library initialized
2013-08-07 14:12:00 +03:00 --- debug: Session Library initialized
2013-08-07 14:12:00 +03:00 --- debug: Auth Library loaded
2013-08-07 14:12:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:12:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:12:00 +03:00 --- debug: Database Library initialized
2013-08-07 14:12:00 +03:00 --- debug: Session Library initialized
2013-08-07 14:12:00 +03:00 --- debug: Auth Library loaded
2013-08-07 14:12:00 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:12:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:12:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:12:00 +03:00 --- debug: Database Library initialized
2013-08-07 14:12:00 +03:00 --- debug: Session Library initialized
2013-08-07 14:12:00 +03:00 --- debug: Auth Library loaded
2013-08-07 14:12:00 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:12:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:12:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:12:08 +03:00 --- debug: Database Library initialized
2013-08-07 14:12:08 +03:00 --- debug: Session Library initialized
2013-08-07 14:12:08 +03:00 --- debug: Auth Library loaded
2013-08-07 14:12:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:12:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:12:08 +03:00 --- debug: Database Library initialized
2013-08-07 14:12:08 +03:00 --- debug: Session Library initialized
2013-08-07 14:12:08 +03:00 --- debug: Auth Library loaded
2013-08-07 14:12:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:12:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:12:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:12:08 +03:00 --- debug: Database Library initialized
2013-08-07 14:12:08 +03:00 --- debug: Session Library initialized
2013-08-07 14:12:08 +03:00 --- debug: Auth Library loaded
2013-08-07 14:12:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:12:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:12:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:12:12 +03:00 --- debug: Database Library initialized
2013-08-07 14:12:12 +03:00 --- debug: Session Library initialized
2013-08-07 14:12:12 +03:00 --- debug: Auth Library loaded
2013-08-07 14:12:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:12:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:12:12 +03:00 --- debug: Database Library initialized
2013-08-07 14:12:12 +03:00 --- debug: Session Library initialized
2013-08-07 14:12:12 +03:00 --- debug: Auth Library loaded
2013-08-07 14:12:12 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:12:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:12:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:12:12 +03:00 --- debug: Database Library initialized
2013-08-07 14:12:12 +03:00 --- debug: Session Library initialized
2013-08-07 14:12:12 +03:00 --- debug: Auth Library loaded
2013-08-07 14:12:12 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:12:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:12:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:12:16 +03:00 --- debug: Database Library initialized
2013-08-07 14:12:16 +03:00 --- debug: Session Library initialized
2013-08-07 14:12:16 +03:00 --- debug: Auth Library loaded
2013-08-07 14:12:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:12:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:12:16 +03:00 --- debug: Database Library initialized
2013-08-07 14:12:16 +03:00 --- debug: Session Library initialized
2013-08-07 14:12:16 +03:00 --- debug: Auth Library loaded
2013-08-07 14:12:16 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:12:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:12:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:12:18 +03:00 --- debug: Database Library initialized
2013-08-07 14:12:18 +03:00 --- debug: Session Library initialized
2013-08-07 14:12:18 +03:00 --- debug: Auth Library loaded
2013-08-07 14:12:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:12:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:12:20 +03:00 --- debug: Database Library initialized
2013-08-07 14:12:20 +03:00 --- debug: Session Library initialized
2013-08-07 14:12:20 +03:00 --- debug: Auth Library loaded
2013-08-07 14:12:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:12:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:12:22 +03:00 --- debug: Database Library initialized
2013-08-07 14:12:22 +03:00 --- debug: Session Library initialized
2013-08-07 14:12:22 +03:00 --- debug: Auth Library loaded
2013-08-07 14:13:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:13:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:13:41 +03:00 --- debug: Database Library initialized
2013-08-07 14:13:41 +03:00 --- debug: Session Library initialized
2013-08-07 14:13:41 +03:00 --- debug: Auth Library loaded
2013-08-07 14:13:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:13:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:13:41 +03:00 --- debug: Database Library initialized
2013-08-07 14:13:41 +03:00 --- debug: Session Library initialized
2013-08-07 14:13:41 +03:00 --- debug: Auth Library loaded
2013-08-07 14:13:41 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:13:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:13:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:13:44 +03:00 --- debug: Database Library initialized
2013-08-07 14:13:44 +03:00 --- debug: Session Library initialized
2013-08-07 14:13:44 +03:00 --- debug: Auth Library loaded
2013-08-07 14:13:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:13:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:13:44 +03:00 --- debug: Database Library initialized
2013-08-07 14:13:44 +03:00 --- debug: Session Library initialized
2013-08-07 14:13:44 +03:00 --- debug: Auth Library loaded
2013-08-07 14:13:44 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:13:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:13:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:13:47 +03:00 --- debug: Database Library initialized
2013-08-07 14:13:47 +03:00 --- debug: Session Library initialized
2013-08-07 14:13:47 +03:00 --- debug: Auth Library loaded
2013-08-07 14:13:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:13:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:13:47 +03:00 --- debug: Database Library initialized
2013-08-07 14:13:47 +03:00 --- debug: Session Library initialized
2013-08-07 14:13:47 +03:00 --- debug: Auth Library loaded
2013-08-07 14:13:47 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:13:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:13:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:13:50 +03:00 --- debug: Database Library initialized
2013-08-07 14:13:50 +03:00 --- debug: Session Library initialized
2013-08-07 14:13:50 +03:00 --- debug: Auth Library loaded
2013-08-07 14:13:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:13:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:13:50 +03:00 --- debug: Database Library initialized
2013-08-07 14:13:50 +03:00 --- debug: Session Library initialized
2013-08-07 14:13:50 +03:00 --- debug: Auth Library loaded
2013-08-07 14:13:50 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:13:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:13:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:13:50 +03:00 --- debug: Database Library initialized
2013-08-07 14:13:50 +03:00 --- debug: Session Library initialized
2013-08-07 14:13:50 +03:00 --- debug: Auth Library loaded
2013-08-07 14:13:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:13:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:13:50 +03:00 --- debug: Database Library initialized
2013-08-07 14:13:50 +03:00 --- debug: Session Library initialized
2013-08-07 14:13:50 +03:00 --- debug: Auth Library loaded
2013-08-07 14:13:50 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:13:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:13:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:13:51 +03:00 --- debug: Database Library initialized
2013-08-07 14:13:51 +03:00 --- debug: Session Library initialized
2013-08-07 14:13:51 +03:00 --- debug: Auth Library loaded
2013-08-07 14:13:51 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, recipes, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:13:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:13:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:13:51 +03:00 --- debug: Database Library initialized
2013-08-07 14:13:51 +03:00 --- debug: Session Library initialized
2013-08-07 14:13:51 +03:00 --- debug: Auth Library loaded
2013-08-07 14:13:51 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:15:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:15:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:15:18 +03:00 --- debug: Database Library initialized
2013-08-07 14:15:18 +03:00 --- debug: Session Library initialized
2013-08-07 14:15:18 +03:00 --- debug: Auth Library loaded
2013-08-07 14:15:18 +03:00 --- error: Не пойманное Kohana_Exception: Запрошенный вид, recipes, не найден в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 1189
2013-08-07 14:15:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:15:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:15:18 +03:00 --- debug: Database Library initialized
2013-08-07 14:15:18 +03:00 --- debug: Session Library initialized
2013-08-07 14:15:18 +03:00 --- debug: Auth Library loaded
2013-08-07 14:15:18 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:15:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:15:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:15:42 +03:00 --- debug: Database Library initialized
2013-08-07 14:15:42 +03:00 --- debug: Session Library initialized
2013-08-07 14:15:42 +03:00 --- debug: Auth Library loaded
2013-08-07 14:15:42 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Table 'do_smaky.recips' doesn't exist - SHOW COLUMNS FROM `recips` в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-07 14:15:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:15:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:15:42 +03:00 --- debug: Database Library initialized
2013-08-07 14:15:42 +03:00 --- debug: Session Library initialized
2013-08-07 14:15:42 +03:00 --- debug: Auth Library loaded
2013-08-07 14:15:42 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:16:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:16:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:16:00 +03:00 --- debug: Database Library initialized
2013-08-07 14:16:00 +03:00 --- debug: Session Library initialized
2013-08-07 14:16:00 +03:00 --- debug: Auth Library loaded
2013-08-07 14:16:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:16:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:16:00 +03:00 --- debug: Database Library initialized
2013-08-07 14:16:00 +03:00 --- debug: Session Library initialized
2013-08-07 14:16:00 +03:00 --- debug: Auth Library loaded
2013-08-07 14:16:00 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:17:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:06 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:06 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:06 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:07 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:07 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:07 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:07 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:17:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:12 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:12 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:12 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:12 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:12 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:12 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:12 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:17:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:13 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:13 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:13 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:13 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:13 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:13 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:13 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:17:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:14 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:14 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:14 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:14 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:14 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:14 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:14 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:17:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:14 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:14 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:14 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:14 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:14 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:14 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:14 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:17:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:15 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:15 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:15 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:15 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:15 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:15 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:15 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:17:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:15 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:15 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:15 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:15 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:15 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:15 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:15 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:17:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:16 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:16 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:16 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:16 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:16 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:16 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:16 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:17:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:16 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:16 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:16 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:16 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:16 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:16 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:16 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:17:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:17 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:17 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:17 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:17 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:17 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:17 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:17 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:17:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:17 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:17 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:17 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:17 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:17 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:17 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:17 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:17:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:17 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:17 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:17 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:18 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:18 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:18 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:18 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:17:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:18 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:18 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:18 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:18 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:18 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:18 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:18 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:17:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:18 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:18 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:18 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:18 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:18 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:18 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:18 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:17:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:19 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:19 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:19 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:19 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:19 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:19 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:19 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:17:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:22 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:22 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:22 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:17:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:17:22 +03:00 --- debug: Database Library initialized
2013-08-07 14:17:22 +03:00 --- debug: Session Library initialized
2013-08-07 14:17:22 +03:00 --- debug: Auth Library loaded
2013-08-07 14:17:22 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:22:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:22:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:22:33 +03:00 --- debug: Database Library initialized
2013-08-07 14:22:33 +03:00 --- debug: Session Library initialized
2013-08-07 14:22:33 +03:00 --- debug: Auth Library loaded
2013-08-07 14:22:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:22:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:22:33 +03:00 --- debug: Database Library initialized
2013-08-07 14:22:33 +03:00 --- debug: Session Library initialized
2013-08-07 14:22:33 +03:00 --- debug: Auth Library loaded
2013-08-07 14:22:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:22:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:22:33 +03:00 --- debug: Database Library initialized
2013-08-07 14:22:33 +03:00 --- debug: Session Library initialized
2013-08-07 14:22:33 +03:00 --- debug: Auth Library loaded
2013-08-07 14:22:33 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:22:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:22:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:22:36 +03:00 --- debug: Database Library initialized
2013-08-07 14:22:36 +03:00 --- debug: Session Library initialized
2013-08-07 14:22:36 +03:00 --- debug: Auth Library loaded
2013-08-07 14:22:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:22:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:22:38 +03:00 --- debug: Database Library initialized
2013-08-07 14:22:38 +03:00 --- debug: Session Library initialized
2013-08-07 14:22:38 +03:00 --- debug: Auth Library loaded
2013-08-07 14:23:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:23:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:23:00 +03:00 --- debug: Database Library initialized
2013-08-07 14:23:00 +03:00 --- debug: Session Library initialized
2013-08-07 14:23:00 +03:00 --- debug: Auth Library loaded
2013-08-07 14:23:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:23:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:23:01 +03:00 --- debug: Database Library initialized
2013-08-07 14:23:01 +03:00 --- debug: Session Library initialized
2013-08-07 14:23:01 +03:00 --- debug: Auth Library loaded
2013-08-07 14:23:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:23:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:23:01 +03:00 --- debug: Database Library initialized
2013-08-07 14:23:01 +03:00 --- debug: Session Library initialized
2013-08-07 14:23:01 +03:00 --- debug: Auth Library loaded
2013-08-07 14:23:01 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:23:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:23:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:23:03 +03:00 --- debug: Database Library initialized
2013-08-07 14:23:03 +03:00 --- debug: Session Library initialized
2013-08-07 14:23:03 +03:00 --- debug: Auth Library loaded
2013-08-07 14:23:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:23:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:23:17 +03:00 --- debug: Database Library initialized
2013-08-07 14:23:17 +03:00 --- debug: Session Library initialized
2013-08-07 14:23:17 +03:00 --- debug: Auth Library loaded
2013-08-07 14:24:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:24:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:24:21 +03:00 --- debug: Database Library initialized
2013-08-07 14:24:21 +03:00 --- debug: Session Library initialized
2013-08-07 14:24:21 +03:00 --- debug: Auth Library loaded
2013-08-07 14:24:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:24:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:24:22 +03:00 --- debug: Database Library initialized
2013-08-07 14:24:22 +03:00 --- debug: Session Library initialized
2013-08-07 14:24:22 +03:00 --- debug: Auth Library loaded
2013-08-07 14:24:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:24:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:24:22 +03:00 --- debug: Database Library initialized
2013-08-07 14:24:22 +03:00 --- debug: Session Library initialized
2013-08-07 14:24:22 +03:00 --- debug: Auth Library loaded
2013-08-07 14:24:22 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:24:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:24:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:24:24 +03:00 --- debug: Database Library initialized
2013-08-07 14:24:24 +03:00 --- debug: Session Library initialized
2013-08-07 14:24:24 +03:00 --- debug: Auth Library loaded
2013-08-07 14:24:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:24:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:24:26 +03:00 --- debug: Database Library initialized
2013-08-07 14:24:26 +03:00 --- debug: Session Library initialized
2013-08-07 14:24:26 +03:00 --- debug: Auth Library loaded
2013-08-07 14:24:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:24:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:24:31 +03:00 --- debug: Database Library initialized
2013-08-07 14:24:31 +03:00 --- debug: Session Library initialized
2013-08-07 14:24:31 +03:00 --- debug: Auth Library loaded
2013-08-07 14:24:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:24:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:24:33 +03:00 --- debug: Database Library initialized
2013-08-07 14:24:33 +03:00 --- debug: Session Library initialized
2013-08-07 14:24:33 +03:00 --- debug: Auth Library loaded
2013-08-07 14:24:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:24:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:24:36 +03:00 --- debug: Database Library initialized
2013-08-07 14:24:36 +03:00 --- debug: Session Library initialized
2013-08-07 14:24:36 +03:00 --- debug: Auth Library loaded
2013-08-07 14:24:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:24:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:24:37 +03:00 --- debug: Database Library initialized
2013-08-07 14:24:37 +03:00 --- debug: Session Library initialized
2013-08-07 14:24:37 +03:00 --- debug: Auth Library loaded
2013-08-07 14:24:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:24:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:24:46 +03:00 --- debug: Database Library initialized
2013-08-07 14:24:46 +03:00 --- debug: Session Library initialized
2013-08-07 14:24:46 +03:00 --- debug: Auth Library loaded
2013-08-07 14:24:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:24:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:24:46 +03:00 --- debug: Database Library initialized
2013-08-07 14:24:46 +03:00 --- debug: Session Library initialized
2013-08-07 14:24:46 +03:00 --- debug: Auth Library loaded
2013-08-07 14:24:46 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:24:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:24:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:24:46 +03:00 --- debug: Database Library initialized
2013-08-07 14:24:46 +03:00 --- debug: Session Library initialized
2013-08-07 14:24:46 +03:00 --- debug: Auth Library loaded
2013-08-07 14:24:46 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:25:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:25:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:25:03 +03:00 --- debug: Database Library initialized
2013-08-07 14:25:03 +03:00 --- debug: Session Library initialized
2013-08-07 14:25:03 +03:00 --- debug: Auth Library loaded
2013-08-07 14:25:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:25:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:25:03 +03:00 --- debug: Database Library initialized
2013-08-07 14:25:03 +03:00 --- debug: Session Library initialized
2013-08-07 14:25:03 +03:00 --- debug: Auth Library loaded
2013-08-07 14:25:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:25:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:25:03 +03:00 --- debug: Database Library initialized
2013-08-07 14:25:03 +03:00 --- debug: Session Library initialized
2013-08-07 14:25:03 +03:00 --- debug: Auth Library loaded
2013-08-07 14:25:03 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:25:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:25:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:25:10 +03:00 --- debug: Database Library initialized
2013-08-07 14:25:10 +03:00 --- debug: Session Library initialized
2013-08-07 14:25:10 +03:00 --- debug: Auth Library loaded
2013-08-07 14:25:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:25:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:25:24 +03:00 --- debug: Database Library initialized
2013-08-07 14:25:24 +03:00 --- debug: Session Library initialized
2013-08-07 14:25:24 +03:00 --- debug: Auth Library loaded
2013-08-07 14:26:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:26:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:26:30 +03:00 --- debug: Database Library initialized
2013-08-07 14:26:30 +03:00 --- debug: Session Library initialized
2013-08-07 14:26:30 +03:00 --- debug: Auth Library loaded
2013-08-07 14:26:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:26:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:26:32 +03:00 --- debug: Database Library initialized
2013-08-07 14:26:32 +03:00 --- debug: Session Library initialized
2013-08-07 14:26:32 +03:00 --- debug: Auth Library loaded
2013-08-07 14:28:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:28:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:28:15 +03:00 --- debug: Database Library initialized
2013-08-07 14:28:15 +03:00 --- debug: Session Library initialized
2013-08-07 14:28:15 +03:00 --- debug: Auth Library loaded
2013-08-07 14:28:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:28:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:28:15 +03:00 --- debug: Database Library initialized
2013-08-07 14:28:15 +03:00 --- debug: Session Library initialized
2013-08-07 14:28:15 +03:00 --- debug: Auth Library loaded
2013-08-07 14:28:15 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:16 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:16 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:16 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:16 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:16 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:16 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:16 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/pecepts/2/rec_small.jpj, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:16 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:16 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:16 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:16 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/pecepts/6/rec_small.jpj, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:16 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:17 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:17 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:17 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/pecepts/3/rec_small.jpj, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:17 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:17 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:17 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:17 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/pecepts/1/rec_small.jpj, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:17 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:17 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:17 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:17 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/pecepts/4/rec_small.jpj, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:17 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:17 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:17 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:17 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/pecepts/7/rec_small.jpj, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:17 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:17 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:17 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:17 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/pecepts/5/rec_small.jpj, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:17 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:17 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:17 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:17 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:48 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:48 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:48 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:48 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:48 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:48 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:48 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/recepies/3/rec_small.jpj, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:48 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:48 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:48 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:48 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/recepies/6/rec_small.jpj, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:48 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:48 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:48 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:48 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/recepies/5/rec_small.jpj, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:48 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:48 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:48 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:48 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/recepies/1/rec_small.jpj, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:48 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:48 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:48 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:48 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/recepies/2/rec_small.jpj, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:48 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:48 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:48 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:48 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/recepies/4/rec_small.jpj, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:48 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:48 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:48 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:48 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/recepies/7/rec_small.jpj, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:49 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:49 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:49 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:49 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:50 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:50 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:50 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:50 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:50 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:50 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:50 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/recepies/2/rec_small.jpj, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:50 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:50 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:50 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:50 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/recepies/4/rec_small.jpj, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:50 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:50 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:50 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:50 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/recepies/3/rec_small.jpj, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:50 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:50 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:50 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:50 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/recepies/5/rec_small.jpj, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:50 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:50 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:50 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:50 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/recepies/1/rec_small.jpj, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:50 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:50 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:50 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:50 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/recepies/7/rec_small.jpj, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:50 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:50 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:50 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:50 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/recepies/6/rec_small.jpj, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:34:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:34:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:34:50 +03:00 --- debug: Database Library initialized
2013-08-07 14:34:50 +03:00 --- debug: Session Library initialized
2013-08-07 14:34:50 +03:00 --- debug: Auth Library loaded
2013-08-07 14:34:50 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:35:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:35:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:35:02 +03:00 --- debug: Database Library initialized
2013-08-07 14:35:02 +03:00 --- debug: Session Library initialized
2013-08-07 14:35:02 +03:00 --- debug: Auth Library loaded
2013-08-07 14:35:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:35:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:35:02 +03:00 --- debug: Database Library initialized
2013-08-07 14:35:02 +03:00 --- debug: Session Library initialized
2013-08-07 14:35:02 +03:00 --- debug: Auth Library loaded
2013-08-07 14:35:02 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/recepies/2/rec_small.jpg, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:35:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:35:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:35:02 +03:00 --- debug: Database Library initialized
2013-08-07 14:35:02 +03:00 --- debug: Session Library initialized
2013-08-07 14:35:02 +03:00 --- debug: Auth Library loaded
2013-08-07 14:35:02 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/recepies/6/rec_small.jpg, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:35:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:35:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:35:02 +03:00 --- debug: Database Library initialized
2013-08-07 14:35:02 +03:00 --- debug: Session Library initialized
2013-08-07 14:35:02 +03:00 --- debug: Auth Library loaded
2013-08-07 14:35:02 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/recepies/3/rec_small.jpg, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:35:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:35:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:35:02 +03:00 --- debug: Database Library initialized
2013-08-07 14:35:02 +03:00 --- debug: Session Library initialized
2013-08-07 14:35:02 +03:00 --- debug: Auth Library loaded
2013-08-07 14:35:02 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/recepies/7/rec_small.jpg, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:35:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:35:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:35:02 +03:00 --- debug: Database Library initialized
2013-08-07 14:35:02 +03:00 --- debug: Session Library initialized
2013-08-07 14:35:02 +03:00 --- debug: Auth Library loaded
2013-08-07 14:35:02 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/recepies/4/rec_small.jpg, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:35:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:35:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:35:02 +03:00 --- debug: Database Library initialized
2013-08-07 14:35:02 +03:00 --- debug: Session Library initialized
2013-08-07 14:35:02 +03:00 --- debug: Auth Library loaded
2013-08-07 14:35:02 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, upload/recepies/5/rec_small.jpg, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:35:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:35:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:35:02 +03:00 --- debug: Database Library initialized
2013-08-07 14:35:02 +03:00 --- debug: Session Library initialized
2013-08-07 14:35:02 +03:00 --- debug: Auth Library loaded
2013-08-07 14:35:02 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:35:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:35:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:35:39 +03:00 --- debug: Database Library initialized
2013-08-07 14:35:39 +03:00 --- debug: Session Library initialized
2013-08-07 14:35:39 +03:00 --- debug: Auth Library loaded
2013-08-07 14:35:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:35:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:35:39 +03:00 --- debug: Database Library initialized
2013-08-07 14:35:39 +03:00 --- debug: Session Library initialized
2013-08-07 14:35:39 +03:00 --- debug: Auth Library loaded
2013-08-07 14:35:39 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:35:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:35:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:35:39 +03:00 --- debug: Database Library initialized
2013-08-07 14:35:39 +03:00 --- debug: Session Library initialized
2013-08-07 14:35:39 +03:00 --- debug: Auth Library loaded
2013-08-07 14:35:39 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:35:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:35:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:35:46 +03:00 --- debug: Database Library initialized
2013-08-07 14:35:46 +03:00 --- debug: Session Library initialized
2013-08-07 14:35:46 +03:00 --- debug: Auth Library loaded
2013-08-07 14:35:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:35:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:35:53 +03:00 --- debug: Database Library initialized
2013-08-07 14:35:53 +03:00 --- debug: Session Library initialized
2013-08-07 14:35:53 +03:00 --- debug: Auth Library loaded
2013-08-07 14:35:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:35:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:35:53 +03:00 --- debug: Database Library initialized
2013-08-07 14:35:53 +03:00 --- debug: Session Library initialized
2013-08-07 14:35:53 +03:00 --- debug: Auth Library loaded
2013-08-07 14:35:53 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:35:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:35:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:35:53 +03:00 --- debug: Database Library initialized
2013-08-07 14:35:53 +03:00 --- debug: Session Library initialized
2013-08-07 14:35:53 +03:00 --- debug: Auth Library loaded
2013-08-07 14:35:53 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:35:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:35:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:35:56 +03:00 --- debug: Database Library initialized
2013-08-07 14:35:56 +03:00 --- debug: Session Library initialized
2013-08-07 14:35:56 +03:00 --- debug: Auth Library loaded
2013-08-07 14:35:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:35:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:35:56 +03:00 --- debug: Database Library initialized
2013-08-07 14:35:56 +03:00 --- debug: Session Library initialized
2013-08-07 14:35:56 +03:00 --- debug: Auth Library loaded
2013-08-07 14:35:56 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:35:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:35:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:35:56 +03:00 --- debug: Database Library initialized
2013-08-07 14:35:56 +03:00 --- debug: Session Library initialized
2013-08-07 14:35:56 +03:00 --- debug: Auth Library loaded
2013-08-07 14:35:56 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:36:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:00 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:00 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:00 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:00 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:00 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:00 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:00 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:36:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:00 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:00 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:00 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:00 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:36:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:04 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:04 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:04 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:04 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:04 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:04 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:04 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:36:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:04 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:04 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:04 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:04 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:36:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:08 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:08 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:08 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:08 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:08 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:08 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:36:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:08 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:08 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:08 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:36:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:11 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:11 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:11 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:12 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:12 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:12 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:12 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:36:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:18 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:18 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:18 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:18 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:18 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:18 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:18 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:36:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:21 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:21 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:21 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:21 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:21 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:21 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:21 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:36:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:22 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:22 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:22 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:22 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:22 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:22 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:22 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:36:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:23 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:23 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:23 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:23 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:23 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:23 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:23 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:36:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:23 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:23 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:23 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:24 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:24 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:24 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:24 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:36:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:24 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:24 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:24 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:24 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:24 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:24 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:24 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:36:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:25 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:25 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:25 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:25 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:25 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:25 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:25 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:36:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:33 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:33 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:33 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:33 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:33 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:33 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:33 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:36:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:34 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:34 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:34 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:34 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:34 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:34 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:34 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:36:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:35 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:35 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:35 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:35 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:35 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:35 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:35 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:36:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:36:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:36:54 +03:00 --- debug: Database Library initialized
2013-08-07 14:36:54 +03:00 --- debug: Session Library initialized
2013-08-07 14:36:54 +03:00 --- debug: Auth Library loaded
2013-08-07 14:36:54 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:42:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:42:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:42:54 +03:00 --- debug: Database Library initialized
2013-08-07 14:42:54 +03:00 --- debug: Session Library initialized
2013-08-07 14:42:54 +03:00 --- debug: Auth Library loaded
2013-08-07 14:42:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:42:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:42:54 +03:00 --- debug: Database Library initialized
2013-08-07 14:42:54 +03:00 --- debug: Session Library initialized
2013-08-07 14:42:54 +03:00 --- debug: Auth Library loaded
2013-08-07 14:42:54 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:42:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:42:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:42:59 +03:00 --- debug: Database Library initialized
2013-08-07 14:42:59 +03:00 --- debug: Session Library initialized
2013-08-07 14:42:59 +03:00 --- debug: Auth Library loaded
2013-08-07 14:42:59 +03:00 --- error: Не пойманное Kohana_Exception: Вызов метода prepare из файла Recip_Model невозможен в файле /home/adok/WWW/prupravy.local/system/libraries/ORM.php, на строке 257
2013-08-07 14:43:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:43:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:43:36 +03:00 --- debug: Database Library initialized
2013-08-07 14:43:36 +03:00 --- debug: Session Library initialized
2013-08-07 14:43:36 +03:00 --- debug: Auth Library loaded
2013-08-07 14:43:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:43:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:43:36 +03:00 --- debug: Database Library initialized
2013-08-07 14:43:36 +03:00 --- debug: Session Library initialized
2013-08-07 14:43:36 +03:00 --- debug: Auth Library loaded
2013-08-07 14:43:36 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:43:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:43:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:43:39 +03:00 --- debug: Database Library initialized
2013-08-07 14:43:39 +03:00 --- debug: Session Library initialized
2013-08-07 14:43:39 +03:00 --- debug: Auth Library loaded
2013-08-07 14:45:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:45:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:45:18 +03:00 --- debug: Database Library initialized
2013-08-07 14:45:18 +03:00 --- debug: Session Library initialized
2013-08-07 14:45:18 +03:00 --- debug: Auth Library loaded
2013-08-07 14:45:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:45:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:45:19 +03:00 --- debug: Database Library initialized
2013-08-07 14:45:19 +03:00 --- debug: Session Library initialized
2013-08-07 14:45:19 +03:00 --- debug: Auth Library loaded
2013-08-07 14:45:19 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:45:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:45:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:45:19 +03:00 --- debug: Database Library initialized
2013-08-07 14:45:19 +03:00 --- debug: Session Library initialized
2013-08-07 14:45:19 +03:00 --- debug: Auth Library loaded
2013-08-07 14:46:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:46:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:46:11 +03:00 --- debug: Database Library initialized
2013-08-07 14:46:11 +03:00 --- debug: Session Library initialized
2013-08-07 14:46:11 +03:00 --- debug: Auth Library loaded
2013-08-07 14:46:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:46:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:46:42 +03:00 --- debug: Database Library initialized
2013-08-07 14:46:42 +03:00 --- debug: Session Library initialized
2013-08-07 14:46:42 +03:00 --- debug: Auth Library loaded
2013-08-07 14:49:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:49:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:49:53 +03:00 --- debug: Database Library initialized
2013-08-07 14:49:53 +03:00 --- debug: Session Library initialized
2013-08-07 14:49:53 +03:00 --- debug: Auth Library loaded
2013-08-07 14:49:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:49:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:49:53 +03:00 --- debug: Database Library initialized
2013-08-07 14:49:53 +03:00 --- debug: Session Library initialized
2013-08-07 14:49:53 +03:00 --- debug: Auth Library loaded
2013-08-07 14:49:53 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, css/fancybox2.css, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:49:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:49:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:49:54 +03:00 --- debug: Database Library initialized
2013-08-07 14:49:54 +03:00 --- debug: Session Library initialized
2013-08-07 14:49:54 +03:00 --- debug: Auth Library loaded
2013-08-07 14:49:54 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:49:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:49:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:49:55 +03:00 --- debug: Database Library initialized
2013-08-07 14:49:55 +03:00 --- debug: Session Library initialized
2013-08-07 14:49:55 +03:00 --- debug: Auth Library loaded
2013-08-07 14:49:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:49:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:49:55 +03:00 --- debug: Database Library initialized
2013-08-07 14:49:55 +03:00 --- debug: Session Library initialized
2013-08-07 14:49:55 +03:00 --- debug: Auth Library loaded
2013-08-07 14:49:55 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:49:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:49:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:49:56 +03:00 --- debug: Database Library initialized
2013-08-07 14:49:56 +03:00 --- debug: Session Library initialized
2013-08-07 14:49:56 +03:00 --- debug: Auth Library loaded
2013-08-07 14:49:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:49:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:49:58 +03:00 --- debug: Database Library initialized
2013-08-07 14:49:58 +03:00 --- debug: Session Library initialized
2013-08-07 14:49:58 +03:00 --- debug: Auth Library loaded
2013-08-07 14:50:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:50:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:50:00 +03:00 --- debug: Database Library initialized
2013-08-07 14:50:00 +03:00 --- debug: Session Library initialized
2013-08-07 14:50:00 +03:00 --- debug: Auth Library loaded
2013-08-07 14:50:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:50:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:50:00 +03:00 --- debug: Database Library initialized
2013-08-07 14:50:00 +03:00 --- debug: Session Library initialized
2013-08-07 14:50:00 +03:00 --- debug: Auth Library loaded
2013-08-07 14:50:00 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, css/fancybox2.css, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:50:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:50:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:50:00 +03:00 --- debug: Database Library initialized
2013-08-07 14:50:00 +03:00 --- debug: Session Library initialized
2013-08-07 14:50:00 +03:00 --- debug: Auth Library loaded
2013-08-07 14:50:00 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:50:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:50:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:50:02 +03:00 --- debug: Database Library initialized
2013-08-07 14:50:02 +03:00 --- debug: Session Library initialized
2013-08-07 14:50:02 +03:00 --- debug: Auth Library loaded
2013-08-07 14:50:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:50:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:50:36 +03:00 --- debug: Database Library initialized
2013-08-07 14:50:36 +03:00 --- debug: Session Library initialized
2013-08-07 14:50:36 +03:00 --- debug: Auth Library loaded
2013-08-07 14:50:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:50:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:50:36 +03:00 --- debug: Database Library initialized
2013-08-07 14:50:36 +03:00 --- debug: Session Library initialized
2013-08-07 14:50:36 +03:00 --- debug: Auth Library loaded
2013-08-07 14:50:36 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, css/fancybox2.css, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:50:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:50:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:50:37 +03:00 --- debug: Database Library initialized
2013-08-07 14:50:37 +03:00 --- debug: Session Library initialized
2013-08-07 14:50:37 +03:00 --- debug: Auth Library loaded
2013-08-07 14:50:37 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:50:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:50:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:50:38 +03:00 --- debug: Database Library initialized
2013-08-07 14:50:38 +03:00 --- debug: Session Library initialized
2013-08-07 14:50:38 +03:00 --- debug: Auth Library loaded
2013-08-07 14:51:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:51:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:51:33 +03:00 --- debug: Database Library initialized
2013-08-07 14:51:33 +03:00 --- debug: Session Library initialized
2013-08-07 14:51:33 +03:00 --- debug: Auth Library loaded
2013-08-07 14:51:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:51:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:51:33 +03:00 --- debug: Database Library initialized
2013-08-07 14:51:33 +03:00 --- debug: Session Library initialized
2013-08-07 14:51:33 +03:00 --- debug: Auth Library loaded
2013-08-07 14:51:33 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, css/fancybox2.css, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:51:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:51:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:51:33 +03:00 --- debug: Database Library initialized
2013-08-07 14:51:33 +03:00 --- debug: Session Library initialized
2013-08-07 14:51:33 +03:00 --- debug: Auth Library loaded
2013-08-07 14:51:33 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:52:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:52:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:52:03 +03:00 --- debug: Database Library initialized
2013-08-07 14:52:03 +03:00 --- debug: Session Library initialized
2013-08-07 14:52:03 +03:00 --- debug: Auth Library loaded
2013-08-07 14:52:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:52:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:52:03 +03:00 --- debug: Database Library initialized
2013-08-07 14:52:03 +03:00 --- debug: Session Library initialized
2013-08-07 14:52:03 +03:00 --- debug: Auth Library loaded
2013-08-07 14:52:03 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, css/fancybox2.css, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:52:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:52:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:52:03 +03:00 --- debug: Database Library initialized
2013-08-07 14:52:03 +03:00 --- debug: Session Library initialized
2013-08-07 14:52:03 +03:00 --- debug: Auth Library loaded
2013-08-07 14:52:03 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox-x.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:52:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:52:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:52:03 +03:00 --- debug: Database Library initialized
2013-08-07 14:52:03 +03:00 --- debug: Session Library initialized
2013-08-07 14:52:03 +03:00 --- debug: Auth Library loaded
2013-08-07 14:52:03 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox-y.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:52:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:52:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:52:03 +03:00 --- debug: Database Library initialized
2013-08-07 14:52:03 +03:00 --- debug: Session Library initialized
2013-08-07 14:52:03 +03:00 --- debug: Auth Library loaded
2013-08-07 14:52:03 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:52:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:52:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:52:03 +03:00 --- debug: Database Library initialized
2013-08-07 14:52:03 +03:00 --- debug: Session Library initialized
2013-08-07 14:52:03 +03:00 --- debug: Auth Library loaded
2013-08-07 14:52:03 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/blank.gif, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:52:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:52:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:52:03 +03:00 --- debug: Database Library initialized
2013-08-07 14:52:03 +03:00 --- debug: Session Library initialized
2013-08-07 14:52:03 +03:00 --- debug: Auth Library loaded
2013-08-07 14:52:03 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:52:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:52:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:52:16 +03:00 --- debug: Database Library initialized
2013-08-07 14:52:16 +03:00 --- debug: Session Library initialized
2013-08-07 14:52:16 +03:00 --- debug: Auth Library loaded
2013-08-07 14:52:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:52:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:52:17 +03:00 --- debug: Database Library initialized
2013-08-07 14:52:17 +03:00 --- debug: Session Library initialized
2013-08-07 14:52:17 +03:00 --- debug: Auth Library loaded
2013-08-07 14:52:17 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:52:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:52:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:52:19 +03:00 --- debug: Database Library initialized
2013-08-07 14:52:19 +03:00 --- debug: Session Library initialized
2013-08-07 14:52:19 +03:00 --- debug: Auth Library loaded
2013-08-07 14:52:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:52:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:52:19 +03:00 --- debug: Database Library initialized
2013-08-07 14:52:19 +03:00 --- debug: Session Library initialized
2013-08-07 14:52:19 +03:00 --- debug: Auth Library loaded
2013-08-07 14:52:19 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:52:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:52:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:52:19 +03:00 --- debug: Database Library initialized
2013-08-07 14:52:19 +03:00 --- debug: Session Library initialized
2013-08-07 14:52:19 +03:00 --- debug: Auth Library loaded
2013-08-07 14:52:19 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, &quot;/upload/recepies/3/rec_big.jpg/&quot;, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:52:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:52:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:52:19 +03:00 --- debug: Database Library initialized
2013-08-07 14:52:19 +03:00 --- debug: Session Library initialized
2013-08-07 14:52:19 +03:00 --- debug: Auth Library loaded
2013-08-07 14:52:19 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox-x.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:52:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:52:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:52:19 +03:00 --- debug: Database Library initialized
2013-08-07 14:52:19 +03:00 --- debug: Session Library initialized
2013-08-07 14:52:19 +03:00 --- debug: Auth Library loaded
2013-08-07 14:52:19 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox-y.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:52:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:52:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:52:19 +03:00 --- debug: Database Library initialized
2013-08-07 14:52:19 +03:00 --- debug: Session Library initialized
2013-08-07 14:52:19 +03:00 --- debug: Auth Library loaded
2013-08-07 14:52:19 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/blank.gif, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:52:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:52:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:52:37 +03:00 --- debug: Database Library initialized
2013-08-07 14:52:37 +03:00 --- debug: Session Library initialized
2013-08-07 14:52:37 +03:00 --- debug: Auth Library loaded
2013-08-07 14:52:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:52:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:52:37 +03:00 --- debug: Database Library initialized
2013-08-07 14:52:37 +03:00 --- debug: Session Library initialized
2013-08-07 14:52:37 +03:00 --- debug: Auth Library loaded
2013-08-07 14:52:37 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:52:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:52:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:52:38 +03:00 --- debug: Database Library initialized
2013-08-07 14:52:38 +03:00 --- debug: Session Library initialized
2013-08-07 14:52:38 +03:00 --- debug: Auth Library loaded
2013-08-07 14:52:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:52:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:52:51 +03:00 --- debug: Database Library initialized
2013-08-07 14:52:51 +03:00 --- debug: Session Library initialized
2013-08-07 14:52:51 +03:00 --- debug: Auth Library loaded
2013-08-07 14:52:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:52:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:52:51 +03:00 --- debug: Database Library initialized
2013-08-07 14:52:51 +03:00 --- debug: Session Library initialized
2013-08-07 14:52:51 +03:00 --- debug: Auth Library loaded
2013-08-07 14:52:51 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:52:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:52:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:52:52 +03:00 --- debug: Database Library initialized
2013-08-07 14:52:52 +03:00 --- debug: Session Library initialized
2013-08-07 14:52:52 +03:00 --- debug: Auth Library loaded
2013-08-07 14:53:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:53:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:53:29 +03:00 --- debug: Database Library initialized
2013-08-07 14:53:29 +03:00 --- debug: Session Library initialized
2013-08-07 14:53:29 +03:00 --- debug: Auth Library loaded
2013-08-07 14:53:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:53:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:53:29 +03:00 --- debug: Database Library initialized
2013-08-07 14:53:29 +03:00 --- debug: Session Library initialized
2013-08-07 14:53:29 +03:00 --- debug: Auth Library loaded
2013-08-07 14:53:29 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:53:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:53:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:53:30 +03:00 --- debug: Database Library initialized
2013-08-07 14:53:30 +03:00 --- debug: Session Library initialized
2013-08-07 14:53:30 +03:00 --- debug: Auth Library loaded
2013-08-07 14:53:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:53:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:53:43 +03:00 --- debug: Database Library initialized
2013-08-07 14:53:43 +03:00 --- debug: Session Library initialized
2013-08-07 14:53:43 +03:00 --- debug: Auth Library loaded
2013-08-07 14:53:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:53:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:53:44 +03:00 --- debug: Database Library initialized
2013-08-07 14:53:44 +03:00 --- debug: Session Library initialized
2013-08-07 14:53:44 +03:00 --- debug: Auth Library loaded
2013-08-07 14:53:44 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:53:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:53:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:53:45 +03:00 --- debug: Database Library initialized
2013-08-07 14:53:45 +03:00 --- debug: Session Library initialized
2013-08-07 14:53:45 +03:00 --- debug: Auth Library loaded
2013-08-07 14:53:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:53:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:53:50 +03:00 --- debug: Database Library initialized
2013-08-07 14:53:50 +03:00 --- debug: Session Library initialized
2013-08-07 14:53:50 +03:00 --- debug: Auth Library loaded
2013-08-07 14:53:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:53:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:53:51 +03:00 --- debug: Database Library initialized
2013-08-07 14:53:51 +03:00 --- debug: Session Library initialized
2013-08-07 14:53:51 +03:00 --- debug: Auth Library loaded
2013-08-07 14:53:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:53:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:53:51 +03:00 --- debug: Database Library initialized
2013-08-07 14:53:51 +03:00 --- debug: Session Library initialized
2013-08-07 14:53:51 +03:00 --- debug: Auth Library loaded
2013-08-07 14:53:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:53:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:53:53 +03:00 --- debug: Database Library initialized
2013-08-07 14:53:53 +03:00 --- debug: Session Library initialized
2013-08-07 14:53:53 +03:00 --- debug: Auth Library loaded
2013-08-07 14:53:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:53:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:53:53 +03:00 --- debug: Database Library initialized
2013-08-07 14:53:53 +03:00 --- debug: Session Library initialized
2013-08-07 14:53:53 +03:00 --- debug: Auth Library loaded
2013-08-07 14:53:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:53:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:53:55 +03:00 --- debug: Database Library initialized
2013-08-07 14:53:55 +03:00 --- debug: Session Library initialized
2013-08-07 14:53:55 +03:00 --- debug: Auth Library loaded
2013-08-07 14:54:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:54:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:54:00 +03:00 --- debug: Database Library initialized
2013-08-07 14:54:00 +03:00 --- debug: Session Library initialized
2013-08-07 14:54:00 +03:00 --- debug: Auth Library loaded
2013-08-07 14:54:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:54:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:54:00 +03:00 --- debug: Database Library initialized
2013-08-07 14:54:00 +03:00 --- debug: Session Library initialized
2013-08-07 14:54:00 +03:00 --- debug: Auth Library loaded
2013-08-07 14:54:00 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:54:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:54:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:54:01 +03:00 --- debug: Database Library initialized
2013-08-07 14:54:01 +03:00 --- debug: Session Library initialized
2013-08-07 14:54:01 +03:00 --- debug: Auth Library loaded
2013-08-07 14:54:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:54:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:54:42 +03:00 --- debug: Database Library initialized
2013-08-07 14:54:42 +03:00 --- debug: Session Library initialized
2013-08-07 14:54:42 +03:00 --- debug: Auth Library loaded
2013-08-07 14:54:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:54:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:54:42 +03:00 --- debug: Database Library initialized
2013-08-07 14:54:42 +03:00 --- debug: Session Library initialized
2013-08-07 14:54:42 +03:00 --- debug: Auth Library loaded
2013-08-07 14:54:42 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:54:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:54:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:54:43 +03:00 --- debug: Database Library initialized
2013-08-07 14:54:43 +03:00 --- debug: Session Library initialized
2013-08-07 14:54:43 +03:00 --- debug: Auth Library loaded
2013-08-07 14:54:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:54:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:54:59 +03:00 --- debug: Database Library initialized
2013-08-07 14:54:59 +03:00 --- debug: Session Library initialized
2013-08-07 14:54:59 +03:00 --- debug: Auth Library loaded
2013-08-07 14:54:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:54:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:54:59 +03:00 --- debug: Database Library initialized
2013-08-07 14:54:59 +03:00 --- debug: Session Library initialized
2013-08-07 14:54:59 +03:00 --- debug: Auth Library loaded
2013-08-07 14:54:59 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:55:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:55:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:55:00 +03:00 --- debug: Database Library initialized
2013-08-07 14:55:00 +03:00 --- debug: Session Library initialized
2013-08-07 14:55:00 +03:00 --- debug: Auth Library loaded
2013-08-07 14:55:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:55:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:55:14 +03:00 --- debug: Database Library initialized
2013-08-07 14:55:14 +03:00 --- debug: Session Library initialized
2013-08-07 14:55:14 +03:00 --- debug: Auth Library loaded
2013-08-07 14:55:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:55:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:55:15 +03:00 --- debug: Database Library initialized
2013-08-07 14:55:15 +03:00 --- debug: Session Library initialized
2013-08-07 14:55:15 +03:00 --- debug: Auth Library loaded
2013-08-07 14:55:15 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:55:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:55:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:55:16 +03:00 --- debug: Database Library initialized
2013-08-07 14:55:16 +03:00 --- debug: Session Library initialized
2013-08-07 14:55:16 +03:00 --- debug: Auth Library loaded
2013-08-07 14:55:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:55:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:55:30 +03:00 --- debug: Database Library initialized
2013-08-07 14:55:30 +03:00 --- debug: Session Library initialized
2013-08-07 14:55:30 +03:00 --- debug: Auth Library loaded
2013-08-07 14:55:30 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, images/fancybox/fancybox.png, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:55:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:55:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:55:54 +03:00 --- debug: Database Library initialized
2013-08-07 14:55:54 +03:00 --- debug: Session Library initialized
2013-08-07 14:55:54 +03:00 --- debug: Auth Library loaded
2013-08-07 14:55:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:55:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:55:55 +03:00 --- debug: Database Library initialized
2013-08-07 14:55:55 +03:00 --- debug: Session Library initialized
2013-08-07 14:55:55 +03:00 --- debug: Auth Library loaded
2013-08-07 14:55:55 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 14:55:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 14:55:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 14:55:56 +03:00 --- debug: Database Library initialized
2013-08-07 14:55:56 +03:00 --- debug: Session Library initialized
2013-08-07 14:55:56 +03:00 --- debug: Auth Library loaded
2013-08-07 15:00:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:00:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:00:39 +03:00 --- debug: Database Library initialized
2013-08-07 15:00:39 +03:00 --- debug: Session Library initialized
2013-08-07 15:00:39 +03:00 --- debug: Auth Library loaded
2013-08-07 15:00:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:00:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:00:39 +03:00 --- debug: Database Library initialized
2013-08-07 15:00:39 +03:00 --- debug: Session Library initialized
2013-08-07 15:00:39 +03:00 --- debug: Auth Library loaded
2013-08-07 15:00:39 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:00:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:00:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:00:41 +03:00 --- debug: Database Library initialized
2013-08-07 15:00:41 +03:00 --- debug: Session Library initialized
2013-08-07 15:00:41 +03:00 --- debug: Auth Library loaded
2013-08-07 15:01:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:01:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:01:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:01:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:01:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:01:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:01:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:01:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:01:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:01:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:01:09 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:01:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:01:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:01:10 +03:00 --- debug: Database Library initialized
2013-08-07 15:01:10 +03:00 --- debug: Session Library initialized
2013-08-07 15:01:10 +03:00 --- debug: Auth Library loaded
2013-08-07 15:01:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:01:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:01:19 +03:00 --- debug: Database Library initialized
2013-08-07 15:01:19 +03:00 --- debug: Session Library initialized
2013-08-07 15:01:19 +03:00 --- debug: Auth Library loaded
2013-08-07 15:01:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:01:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:01:24 +03:00 --- debug: Database Library initialized
2013-08-07 15:01:24 +03:00 --- debug: Session Library initialized
2013-08-07 15:01:24 +03:00 --- debug: Auth Library loaded
2013-08-07 15:01:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:01:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:01:28 +03:00 --- debug: Database Library initialized
2013-08-07 15:01:28 +03:00 --- debug: Session Library initialized
2013-08-07 15:01:28 +03:00 --- debug: Auth Library loaded
2013-08-07 15:01:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:01:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:01:33 +03:00 --- debug: Database Library initialized
2013-08-07 15:01:33 +03:00 --- debug: Session Library initialized
2013-08-07 15:01:33 +03:00 --- debug: Auth Library loaded
2013-08-07 15:01:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:01:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:01:35 +03:00 --- debug: Database Library initialized
2013-08-07 15:01:35 +03:00 --- debug: Session Library initialized
2013-08-07 15:01:35 +03:00 --- debug: Auth Library loaded
2013-08-07 15:01:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:01:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:01:38 +03:00 --- debug: Database Library initialized
2013-08-07 15:01:38 +03:00 --- debug: Session Library initialized
2013-08-07 15:01:38 +03:00 --- debug: Auth Library loaded
2013-08-07 15:01:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:01:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:01:43 +03:00 --- debug: Database Library initialized
2013-08-07 15:01:43 +03:00 --- debug: Session Library initialized
2013-08-07 15:01:43 +03:00 --- debug: Auth Library loaded
2013-08-07 15:02:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:02:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:02:18 +03:00 --- debug: Database Library initialized
2013-08-07 15:02:18 +03:00 --- debug: Session Library initialized
2013-08-07 15:02:18 +03:00 --- debug: Auth Library loaded
2013-08-07 15:02:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:02:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:02:18 +03:00 --- debug: Database Library initialized
2013-08-07 15:02:18 +03:00 --- debug: Session Library initialized
2013-08-07 15:02:18 +03:00 --- debug: Auth Library loaded
2013-08-07 15:02:18 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:02:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:02:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:02:19 +03:00 --- debug: Database Library initialized
2013-08-07 15:02:19 +03:00 --- debug: Session Library initialized
2013-08-07 15:02:19 +03:00 --- debug: Auth Library loaded
2013-08-07 15:02:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:02:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:02:21 +03:00 --- debug: Database Library initialized
2013-08-07 15:02:21 +03:00 --- debug: Session Library initialized
2013-08-07 15:02:21 +03:00 --- debug: Auth Library loaded
2013-08-07 15:02:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:02:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:02:24 +03:00 --- debug: Database Library initialized
2013-08-07 15:02:24 +03:00 --- debug: Session Library initialized
2013-08-07 15:02:24 +03:00 --- debug: Auth Library loaded
2013-08-07 15:02:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:02:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:02:27 +03:00 --- debug: Database Library initialized
2013-08-07 15:02:27 +03:00 --- debug: Session Library initialized
2013-08-07 15:02:27 +03:00 --- debug: Auth Library loaded
2013-08-07 15:02:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:02:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:02:30 +03:00 --- debug: Database Library initialized
2013-08-07 15:02:30 +03:00 --- debug: Session Library initialized
2013-08-07 15:02:30 +03:00 --- debug: Auth Library loaded
2013-08-07 15:02:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:02:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:02:40 +03:00 --- debug: Database Library initialized
2013-08-07 15:02:40 +03:00 --- debug: Session Library initialized
2013-08-07 15:02:40 +03:00 --- debug: Auth Library loaded
2013-08-07 15:02:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:02:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:02:40 +03:00 --- debug: Database Library initialized
2013-08-07 15:02:40 +03:00 --- debug: Session Library initialized
2013-08-07 15:02:40 +03:00 --- debug: Auth Library loaded
2013-08-07 15:02:40 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:02:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:02:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:02:41 +03:00 --- debug: Database Library initialized
2013-08-07 15:02:41 +03:00 --- debug: Session Library initialized
2013-08-07 15:02:41 +03:00 --- debug: Auth Library loaded
2013-08-07 15:02:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:02:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:02:43 +03:00 --- debug: Database Library initialized
2013-08-07 15:02:43 +03:00 --- debug: Session Library initialized
2013-08-07 15:02:43 +03:00 --- debug: Auth Library loaded
2013-08-07 15:02:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:02:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:02:45 +03:00 --- debug: Database Library initialized
2013-08-07 15:02:45 +03:00 --- debug: Session Library initialized
2013-08-07 15:02:45 +03:00 --- debug: Auth Library loaded
2013-08-07 15:02:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:02:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:02:55 +03:00 --- debug: Database Library initialized
2013-08-07 15:02:55 +03:00 --- debug: Session Library initialized
2013-08-07 15:02:55 +03:00 --- debug: Auth Library loaded
2013-08-07 15:02:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:02:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:02:56 +03:00 --- debug: Database Library initialized
2013-08-07 15:02:56 +03:00 --- debug: Session Library initialized
2013-08-07 15:02:56 +03:00 --- debug: Auth Library loaded
2013-08-07 15:02:56 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:02:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:02:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:02:56 +03:00 --- debug: Database Library initialized
2013-08-07 15:02:56 +03:00 --- debug: Session Library initialized
2013-08-07 15:02:56 +03:00 --- debug: Auth Library loaded
2013-08-07 15:02:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:02:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:02:59 +03:00 --- debug: Database Library initialized
2013-08-07 15:02:59 +03:00 --- debug: Session Library initialized
2013-08-07 15:02:59 +03:00 --- debug: Auth Library loaded
2013-08-07 15:03:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:03:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:03:01 +03:00 --- debug: Database Library initialized
2013-08-07 15:03:01 +03:00 --- debug: Session Library initialized
2013-08-07 15:03:01 +03:00 --- debug: Auth Library loaded
2013-08-07 15:03:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:03:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:03:07 +03:00 --- debug: Database Library initialized
2013-08-07 15:03:07 +03:00 --- debug: Session Library initialized
2013-08-07 15:03:07 +03:00 --- debug: Auth Library loaded
2013-08-07 15:04:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:04:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:04:21 +03:00 --- debug: Database Library initialized
2013-08-07 15:04:21 +03:00 --- debug: Session Library initialized
2013-08-07 15:04:21 +03:00 --- debug: Auth Library loaded
2013-08-07 15:04:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:04:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:04:22 +03:00 --- debug: Database Library initialized
2013-08-07 15:04:22 +03:00 --- debug: Session Library initialized
2013-08-07 15:04:22 +03:00 --- debug: Auth Library loaded
2013-08-07 15:04:22 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:04:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:04:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:04:24 +03:00 --- debug: Database Library initialized
2013-08-07 15:04:24 +03:00 --- debug: Session Library initialized
2013-08-07 15:04:24 +03:00 --- debug: Auth Library loaded
2013-08-07 15:04:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:04:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:04:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:04:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:04:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:04:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:04:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:04:52 +03:00 --- debug: Database Library initialized
2013-08-07 15:04:52 +03:00 --- debug: Session Library initialized
2013-08-07 15:04:52 +03:00 --- debug: Auth Library loaded
2013-08-07 15:04:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:04:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:04:54 +03:00 --- debug: Database Library initialized
2013-08-07 15:04:54 +03:00 --- debug: Session Library initialized
2013-08-07 15:04:54 +03:00 --- debug: Auth Library loaded
2013-08-07 15:04:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:04:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:04:57 +03:00 --- debug: Database Library initialized
2013-08-07 15:04:57 +03:00 --- debug: Session Library initialized
2013-08-07 15:04:57 +03:00 --- debug: Auth Library loaded
2013-08-07 15:05:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:05:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:05:02 +03:00 --- debug: Database Library initialized
2013-08-07 15:05:02 +03:00 --- debug: Session Library initialized
2013-08-07 15:05:02 +03:00 --- debug: Auth Library loaded
2013-08-07 15:05:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:05:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:05:04 +03:00 --- debug: Database Library initialized
2013-08-07 15:05:04 +03:00 --- debug: Session Library initialized
2013-08-07 15:05:04 +03:00 --- debug: Auth Library loaded
2013-08-07 15:05:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:05:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:05:04 +03:00 --- debug: Database Library initialized
2013-08-07 15:05:04 +03:00 --- debug: Session Library initialized
2013-08-07 15:05:04 +03:00 --- debug: Auth Library loaded
2013-08-07 15:05:04 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:05:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:05:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:05:05 +03:00 --- debug: Database Library initialized
2013-08-07 15:05:05 +03:00 --- debug: Session Library initialized
2013-08-07 15:05:05 +03:00 --- debug: Auth Library loaded
2013-08-07 15:05:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:05:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:05:05 +03:00 --- debug: Database Library initialized
2013-08-07 15:05:05 +03:00 --- debug: Session Library initialized
2013-08-07 15:05:05 +03:00 --- debug: Auth Library loaded
2013-08-07 15:05:05 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:05:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:05:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:05:06 +03:00 --- debug: Database Library initialized
2013-08-07 15:05:06 +03:00 --- debug: Session Library initialized
2013-08-07 15:05:06 +03:00 --- debug: Auth Library loaded
2013-08-07 15:05:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:05:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:05:07 +03:00 --- debug: Database Library initialized
2013-08-07 15:05:07 +03:00 --- debug: Session Library initialized
2013-08-07 15:05:07 +03:00 --- debug: Auth Library loaded
2013-08-07 15:05:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:05:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:05:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:05:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:05:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:05:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:05:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:05:11 +03:00 --- debug: Database Library initialized
2013-08-07 15:05:11 +03:00 --- debug: Session Library initialized
2013-08-07 15:05:11 +03:00 --- debug: Auth Library loaded
2013-08-07 15:05:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:05:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:05:11 +03:00 --- debug: Database Library initialized
2013-08-07 15:05:11 +03:00 --- debug: Session Library initialized
2013-08-07 15:05:11 +03:00 --- debug: Auth Library loaded
2013-08-07 15:05:11 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:05:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:05:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:05:13 +03:00 --- debug: Database Library initialized
2013-08-07 15:05:13 +03:00 --- debug: Session Library initialized
2013-08-07 15:05:13 +03:00 --- debug: Auth Library loaded
2013-08-07 15:05:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:05:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:05:50 +03:00 --- debug: Database Library initialized
2013-08-07 15:05:50 +03:00 --- debug: Session Library initialized
2013-08-07 15:05:50 +03:00 --- debug: Auth Library loaded
2013-08-07 15:05:50 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, partners, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:05:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:05:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:05:50 +03:00 --- debug: Database Library initialized
2013-08-07 15:05:50 +03:00 --- debug: Session Library initialized
2013-08-07 15:05:50 +03:00 --- debug: Auth Library loaded
2013-08-07 15:05:50 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:07:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:07:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:07:46 +03:00 --- debug: Database Library initialized
2013-08-07 15:07:46 +03:00 --- debug: Session Library initialized
2013-08-07 15:07:46 +03:00 --- debug: Auth Library loaded
2013-08-07 15:07:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:07:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:07:46 +03:00 --- debug: Database Library initialized
2013-08-07 15:07:46 +03:00 --- debug: Session Library initialized
2013-08-07 15:07:46 +03:00 --- debug: Auth Library loaded
2013-08-07 15:07:46 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:08:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:08:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:08:12 +03:00 --- debug: Database Library initialized
2013-08-07 15:08:12 +03:00 --- debug: Session Library initialized
2013-08-07 15:08:12 +03:00 --- debug: Auth Library loaded
2013-08-07 15:08:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:08:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:08:12 +03:00 --- debug: Database Library initialized
2013-08-07 15:08:12 +03:00 --- debug: Session Library initialized
2013-08-07 15:08:12 +03:00 --- debug: Auth Library loaded
2013-08-07 15:08:12 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:10:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:10:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:10:34 +03:00 --- debug: Database Library initialized
2013-08-07 15:10:34 +03:00 --- debug: Session Library initialized
2013-08-07 15:10:34 +03:00 --- debug: Auth Library loaded
2013-08-07 15:10:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:10:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:10:34 +03:00 --- debug: Database Library initialized
2013-08-07 15:10:34 +03:00 --- debug: Session Library initialized
2013-08-07 15:10:34 +03:00 --- debug: Auth Library loaded
2013-08-07 15:10:34 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:11:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:11:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:11:19 +03:00 --- debug: Database Library initialized
2013-08-07 15:11:19 +03:00 --- debug: Session Library initialized
2013-08-07 15:11:19 +03:00 --- debug: Auth Library loaded
2013-08-07 15:11:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:11:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:11:19 +03:00 --- debug: Database Library initialized
2013-08-07 15:11:19 +03:00 --- debug: Session Library initialized
2013-08-07 15:11:19 +03:00 --- debug: Auth Library loaded
2013-08-07 15:11:19 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:14:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:14:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:14:01 +03:00 --- debug: Database Library initialized
2013-08-07 15:14:01 +03:00 --- debug: Session Library initialized
2013-08-07 15:14:01 +03:00 --- debug: Auth Library loaded
2013-08-07 15:14:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:14:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:14:02 +03:00 --- debug: Database Library initialized
2013-08-07 15:14:02 +03:00 --- debug: Session Library initialized
2013-08-07 15:14:02 +03:00 --- debug: Auth Library loaded
2013-08-07 15:14:02 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:14:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:14:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:14:43 +03:00 --- debug: Database Library initialized
2013-08-07 15:14:43 +03:00 --- debug: Session Library initialized
2013-08-07 15:14:43 +03:00 --- debug: Auth Library loaded
2013-08-07 15:14:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:14:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:14:44 +03:00 --- debug: Database Library initialized
2013-08-07 15:14:44 +03:00 --- debug: Session Library initialized
2013-08-07 15:14:44 +03:00 --- debug: Auth Library loaded
2013-08-07 15:14:44 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:14:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:14:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:14:44 +03:00 --- debug: Database Library initialized
2013-08-07 15:14:44 +03:00 --- debug: Session Library initialized
2013-08-07 15:14:44 +03:00 --- debug: Auth Library loaded
2013-08-07 15:14:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:14:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:14:44 +03:00 --- debug: Database Library initialized
2013-08-07 15:14:44 +03:00 --- debug: Session Library initialized
2013-08-07 15:14:44 +03:00 --- debug: Auth Library loaded
2013-08-07 15:14:44 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:14:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:14:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:14:45 +03:00 --- debug: Database Library initialized
2013-08-07 15:14:45 +03:00 --- debug: Session Library initialized
2013-08-07 15:14:45 +03:00 --- debug: Auth Library loaded
2013-08-07 15:14:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:14:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:14:45 +03:00 --- debug: Database Library initialized
2013-08-07 15:14:45 +03:00 --- debug: Session Library initialized
2013-08-07 15:14:45 +03:00 --- debug: Auth Library loaded
2013-08-07 15:14:45 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:14:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:14:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:14:46 +03:00 --- debug: Database Library initialized
2013-08-07 15:14:46 +03:00 --- debug: Session Library initialized
2013-08-07 15:14:46 +03:00 --- debug: Auth Library loaded
2013-08-07 15:14:46 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:14:46 +03:00 --- error: core.uncaught_exception
2013-08-07 15:14:46 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-07 15:14:46 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:14:46 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:14:46 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:14:46 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:14:46 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:14:46 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:14:46 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:14:46 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:14:46 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:14:46 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:14:46 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:14:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:14:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:14:46 +03:00 --- debug: Database Library initialized
2013-08-07 15:14:46 +03:00 --- debug: Session Library initialized
2013-08-07 15:14:46 +03:00 --- debug: Auth Library loaded
2013-08-07 15:14:46 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:14:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:14:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:14:48 +03:00 --- debug: Database Library initialized
2013-08-07 15:14:48 +03:00 --- debug: Session Library initialized
2013-08-07 15:14:48 +03:00 --- debug: Auth Library loaded
2013-08-07 15:14:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:14:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:14:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:14:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:14:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:14:49 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:14:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:14:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:14:50 +03:00 --- debug: Database Library initialized
2013-08-07 15:14:50 +03:00 --- debug: Session Library initialized
2013-08-07 15:14:50 +03:00 --- debug: Auth Library loaded
2013-08-07 15:14:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:14:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:14:50 +03:00 --- debug: Database Library initialized
2013-08-07 15:14:50 +03:00 --- debug: Session Library initialized
2013-08-07 15:14:50 +03:00 --- debug: Auth Library loaded
2013-08-07 15:14:50 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:16:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:16:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:16:34 +03:00 --- debug: Database Library initialized
2013-08-07 15:16:34 +03:00 --- debug: Session Library initialized
2013-08-07 15:16:34 +03:00 --- debug: Auth Library loaded
2013-08-07 15:16:34 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, contacts, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:16:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:16:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:16:34 +03:00 --- debug: Database Library initialized
2013-08-07 15:16:34 +03:00 --- debug: Session Library initialized
2013-08-07 15:16:34 +03:00 --- debug: Auth Library loaded
2013-08-07 15:16:34 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:18:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:18:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:18:40 +03:00 --- debug: Database Library initialized
2013-08-07 15:18:40 +03:00 --- debug: Session Library initialized
2013-08-07 15:18:40 +03:00 --- debug: Auth Library loaded
2013-08-07 15:18:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:18:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:18:40 +03:00 --- debug: Database Library initialized
2013-08-07 15:18:40 +03:00 --- debug: Session Library initialized
2013-08-07 15:18:40 +03:00 --- debug: Auth Library loaded
2013-08-07 15:18:40 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:18:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:18:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:18:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:18:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:18:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:18:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:18:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:18:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:18:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:18:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:18:49 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:18:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:18:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:18:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:18:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:18:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:18:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:18:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:18:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:18:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:18:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:18:49 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:21:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:21:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:21:36 +03:00 --- debug: Database Library initialized
2013-08-07 15:21:36 +03:00 --- debug: Session Library initialized
2013-08-07 15:21:36 +03:00 --- debug: Auth Library loaded
2013-08-07 15:21:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:21:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:21:36 +03:00 --- debug: Database Library initialized
2013-08-07 15:21:36 +03:00 --- debug: Session Library initialized
2013-08-07 15:21:36 +03:00 --- debug: Auth Library loaded
2013-08-07 15:21:36 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:29:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:29:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:29:19 +03:00 --- debug: Database Library initialized
2013-08-07 15:29:19 +03:00 --- debug: Session Library initialized
2013-08-07 15:29:19 +03:00 --- debug: Auth Library loaded
2013-08-07 15:29:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:29:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:29:20 +03:00 --- debug: Database Library initialized
2013-08-07 15:29:20 +03:00 --- debug: Session Library initialized
2013-08-07 15:29:20 +03:00 --- debug: Auth Library loaded
2013-08-07 15:29:20 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:29:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:29:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:29:20 +03:00 --- debug: Database Library initialized
2013-08-07 15:29:20 +03:00 --- debug: Session Library initialized
2013-08-07 15:29:20 +03:00 --- debug: Auth Library loaded
2013-08-07 15:29:20 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:29:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:29:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:29:20 +03:00 --- debug: Database Library initialized
2013-08-07 15:29:20 +03:00 --- debug: Session Library initialized
2013-08-07 15:29:20 +03:00 --- debug: Auth Library loaded
2013-08-07 15:29:20 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:29:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:29:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:29:27 +03:00 --- debug: Database Library initialized
2013-08-07 15:29:27 +03:00 --- debug: Session Library initialized
2013-08-07 15:29:27 +03:00 --- debug: Auth Library loaded
2013-08-07 15:29:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:29:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:29:27 +03:00 --- debug: Database Library initialized
2013-08-07 15:29:27 +03:00 --- debug: Session Library initialized
2013-08-07 15:29:27 +03:00 --- debug: Auth Library loaded
2013-08-07 15:29:27 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:29:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:29:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:29:28 +03:00 --- debug: Database Library initialized
2013-08-07 15:29:28 +03:00 --- debug: Session Library initialized
2013-08-07 15:29:28 +03:00 --- debug: Auth Library loaded
2013-08-07 15:29:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:29:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:29:28 +03:00 --- debug: Database Library initialized
2013-08-07 15:29:28 +03:00 --- debug: Session Library initialized
2013-08-07 15:29:28 +03:00 --- debug: Auth Library loaded
2013-08-07 15:29:28 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:29:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:29:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:29:29 +03:00 --- debug: Database Library initialized
2013-08-07 15:29:29 +03:00 --- debug: Session Library initialized
2013-08-07 15:29:29 +03:00 --- debug: Auth Library loaded
2013-08-07 15:29:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:29:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:29:29 +03:00 --- debug: Database Library initialized
2013-08-07 15:29:29 +03:00 --- debug: Session Library initialized
2013-08-07 15:29:29 +03:00 --- debug: Auth Library loaded
2013-08-07 15:29:29 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:30:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:30:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:30:28 +03:00 --- debug: Database Library initialized
2013-08-07 15:30:28 +03:00 --- debug: Session Library initialized
2013-08-07 15:30:28 +03:00 --- debug: Auth Library loaded
2013-08-07 15:30:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:30:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:30:29 +03:00 --- debug: Database Library initialized
2013-08-07 15:30:29 +03:00 --- debug: Session Library initialized
2013-08-07 15:30:29 +03:00 --- debug: Auth Library loaded
2013-08-07 15:30:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:30:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:30:29 +03:00 --- debug: Database Library initialized
2013-08-07 15:30:29 +03:00 --- debug: Session Library initialized
2013-08-07 15:30:29 +03:00 --- debug: Auth Library loaded
2013-08-07 15:30:29 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:30:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:30:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:30:31 +03:00 --- debug: Database Library initialized
2013-08-07 15:30:31 +03:00 --- debug: Session Library initialized
2013-08-07 15:30:31 +03:00 --- debug: Auth Library loaded
2013-08-07 15:30:31 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Table 'do_smaky.pages' doesn't exist - SHOW COLUMNS FROM `pages` в файле /home/adok/WWW/prupravy.local/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-08-07 15:36:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:36:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:36:00 +03:00 --- debug: Database Library initialized
2013-08-07 15:36:00 +03:00 --- debug: Session Library initialized
2013-08-07 15:36:00 +03:00 --- debug: Auth Library loaded
2013-08-07 15:36:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:36:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:36:01 +03:00 --- debug: Database Library initialized
2013-08-07 15:36:01 +03:00 --- debug: Session Library initialized
2013-08-07 15:36:01 +03:00 --- debug: Auth Library loaded
2013-08-07 15:36:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:36:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:36:01 +03:00 --- debug: Database Library initialized
2013-08-07 15:36:01 +03:00 --- debug: Session Library initialized
2013-08-07 15:36:01 +03:00 --- debug: Auth Library loaded
2013-08-07 15:36:01 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:36:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:36:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:36:02 +03:00 --- debug: Database Library initialized
2013-08-07 15:36:02 +03:00 --- debug: Session Library initialized
2013-08-07 15:36:02 +03:00 --- debug: Auth Library loaded
2013-08-07 15:36:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:36:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:36:13 +03:00 --- debug: Database Library initialized
2013-08-07 15:36:13 +03:00 --- debug: Session Library initialized
2013-08-07 15:36:13 +03:00 --- debug: Auth Library loaded
2013-08-07 15:36:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:36:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:36:13 +03:00 --- debug: Database Library initialized
2013-08-07 15:36:13 +03:00 --- debug: Session Library initialized
2013-08-07 15:36:13 +03:00 --- debug: Auth Library loaded
2013-08-07 15:36:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:36:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:36:13 +03:00 --- debug: Database Library initialized
2013-08-07 15:36:13 +03:00 --- debug: Session Library initialized
2013-08-07 15:36:13 +03:00 --- debug: Auth Library loaded
2013-08-07 15:36:13 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:36:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:36:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:36:15 +03:00 --- debug: Database Library initialized
2013-08-07 15:36:15 +03:00 --- debug: Session Library initialized
2013-08-07 15:36:15 +03:00 --- debug: Auth Library loaded
2013-08-07 15:36:15 +03:00 --- error: Не пойманное PHP Error: Undefined variable: form_reader в файле /home/adok/WWW/prupravy.local/modules/admin/views/pages_admin.php, на строке 152
2013-08-07 15:36:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:36:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:36:37 +03:00 --- debug: Database Library initialized
2013-08-07 15:36:37 +03:00 --- debug: Session Library initialized
2013-08-07 15:36:37 +03:00 --- debug: Auth Library loaded
2013-08-07 15:36:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:36:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:36:37 +03:00 --- debug: Database Library initialized
2013-08-07 15:36:37 +03:00 --- debug: Session Library initialized
2013-08-07 15:36:37 +03:00 --- debug: Auth Library loaded
2013-08-07 15:36:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:36:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:36:37 +03:00 --- debug: Database Library initialized
2013-08-07 15:36:37 +03:00 --- debug: Session Library initialized
2013-08-07 15:36:37 +03:00 --- debug: Auth Library loaded
2013-08-07 15:36:37 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:36:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:36:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:36:38 +03:00 --- debug: Database Library initialized
2013-08-07 15:36:38 +03:00 --- debug: Session Library initialized
2013-08-07 15:36:38 +03:00 --- debug: Auth Library loaded
2013-08-07 15:36:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:36:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:36:47 +03:00 --- debug: Database Library initialized
2013-08-07 15:36:47 +03:00 --- debug: Session Library initialized
2013-08-07 15:36:47 +03:00 --- debug: Auth Library loaded
2013-08-07 15:36:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:36:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:36:47 +03:00 --- debug: Database Library initialized
2013-08-07 15:36:47 +03:00 --- debug: Session Library initialized
2013-08-07 15:36:47 +03:00 --- debug: Auth Library loaded
2013-08-07 15:36:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:36:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:36:47 +03:00 --- debug: Database Library initialized
2013-08-07 15:36:47 +03:00 --- debug: Session Library initialized
2013-08-07 15:36:47 +03:00 --- debug: Auth Library loaded
2013-08-07 15:36:47 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:36:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:36:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:36:48 +03:00 --- debug: Database Library initialized
2013-08-07 15:36:48 +03:00 --- debug: Session Library initialized
2013-08-07 15:36:48 +03:00 --- debug: Auth Library loaded
2013-08-07 15:37:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:37:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:37:08 +03:00 --- debug: Database Library initialized
2013-08-07 15:37:08 +03:00 --- debug: Session Library initialized
2013-08-07 15:37:08 +03:00 --- debug: Auth Library loaded
2013-08-07 15:37:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:37:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:37:08 +03:00 --- debug: Database Library initialized
2013-08-07 15:37:08 +03:00 --- debug: Session Library initialized
2013-08-07 15:37:08 +03:00 --- debug: Auth Library loaded
2013-08-07 15:37:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:37:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:37:08 +03:00 --- debug: Database Library initialized
2013-08-07 15:37:08 +03:00 --- debug: Session Library initialized
2013-08-07 15:37:08 +03:00 --- debug: Auth Library loaded
2013-08-07 15:37:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:37:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:37:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:37:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:37:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:37:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:37:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:37:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:37:15 +03:00 --- debug: Database Library initialized
2013-08-07 15:37:15 +03:00 --- debug: Session Library initialized
2013-08-07 15:37:15 +03:00 --- debug: Auth Library loaded
2013-08-07 15:37:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:37:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:37:15 +03:00 --- debug: Database Library initialized
2013-08-07 15:37:15 +03:00 --- debug: Session Library initialized
2013-08-07 15:37:15 +03:00 --- debug: Auth Library loaded
2013-08-07 15:37:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:37:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:37:15 +03:00 --- debug: Database Library initialized
2013-08-07 15:37:15 +03:00 --- debug: Session Library initialized
2013-08-07 15:37:15 +03:00 --- debug: Auth Library loaded
2013-08-07 15:37:15 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:37:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:37:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:37:16 +03:00 --- debug: Database Library initialized
2013-08-07 15:37:16 +03:00 --- debug: Session Library initialized
2013-08-07 15:37:16 +03:00 --- debug: Auth Library loaded
2013-08-07 15:37:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:37:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:37:51 +03:00 --- debug: Database Library initialized
2013-08-07 15:37:51 +03:00 --- debug: Session Library initialized
2013-08-07 15:37:51 +03:00 --- debug: Auth Library loaded
2013-08-07 15:37:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:37:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:37:51 +03:00 --- debug: Database Library initialized
2013-08-07 15:37:51 +03:00 --- debug: Session Library initialized
2013-08-07 15:37:51 +03:00 --- debug: Auth Library loaded
2013-08-07 15:37:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:37:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:37:51 +03:00 --- debug: Database Library initialized
2013-08-07 15:37:51 +03:00 --- debug: Session Library initialized
2013-08-07 15:37:51 +03:00 --- debug: Auth Library loaded
2013-08-07 15:37:51 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:37:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:37:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:37:52 +03:00 --- debug: Database Library initialized
2013-08-07 15:37:52 +03:00 --- debug: Session Library initialized
2013-08-07 15:37:52 +03:00 --- debug: Auth Library loaded
2013-08-07 15:38:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:38:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:38:23 +03:00 --- debug: Database Library initialized
2013-08-07 15:38:23 +03:00 --- debug: Session Library initialized
2013-08-07 15:38:23 +03:00 --- debug: Auth Library loaded
2013-08-07 15:38:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:38:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:38:23 +03:00 --- debug: Database Library initialized
2013-08-07 15:38:23 +03:00 --- debug: Session Library initialized
2013-08-07 15:38:23 +03:00 --- debug: Auth Library loaded
2013-08-07 15:38:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:38:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:38:23 +03:00 --- debug: Database Library initialized
2013-08-07 15:38:23 +03:00 --- debug: Session Library initialized
2013-08-07 15:38:23 +03:00 --- debug: Auth Library loaded
2013-08-07 15:38:23 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:38:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:38:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:38:24 +03:00 --- debug: Database Library initialized
2013-08-07 15:38:24 +03:00 --- debug: Session Library initialized
2013-08-07 15:38:24 +03:00 --- debug: Auth Library loaded
2013-08-07 15:40:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:40:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:40:13 +03:00 --- debug: Database Library initialized
2013-08-07 15:40:13 +03:00 --- debug: Session Library initialized
2013-08-07 15:40:13 +03:00 --- debug: Auth Library loaded
2013-08-07 15:40:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:40:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:40:13 +03:00 --- debug: Database Library initialized
2013-08-07 15:40:13 +03:00 --- debug: Session Library initialized
2013-08-07 15:40:13 +03:00 --- debug: Auth Library loaded
2013-08-07 15:40:13 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:40:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:40:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:40:18 +03:00 --- debug: Database Library initialized
2013-08-07 15:40:18 +03:00 --- debug: Session Library initialized
2013-08-07 15:40:18 +03:00 --- debug: Auth Library loaded
2013-08-07 15:40:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:40:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:40:18 +03:00 --- debug: Database Library initialized
2013-08-07 15:40:18 +03:00 --- debug: Session Library initialized
2013-08-07 15:40:18 +03:00 --- debug: Auth Library loaded
2013-08-07 15:40:18 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:40:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:40:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:40:23 +03:00 --- debug: Database Library initialized
2013-08-07 15:40:23 +03:00 --- debug: Session Library initialized
2013-08-07 15:40:23 +03:00 --- debug: Auth Library loaded
2013-08-07 15:40:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:40:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:40:24 +03:00 --- debug: Database Library initialized
2013-08-07 15:40:24 +03:00 --- debug: Session Library initialized
2013-08-07 15:40:24 +03:00 --- debug: Auth Library loaded
2013-08-07 15:40:24 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:40:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:40:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:40:29 +03:00 --- debug: Database Library initialized
2013-08-07 15:40:29 +03:00 --- debug: Session Library initialized
2013-08-07 15:40:29 +03:00 --- debug: Auth Library loaded
2013-08-07 15:40:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:40:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:40:30 +03:00 --- debug: Database Library initialized
2013-08-07 15:40:30 +03:00 --- debug: Session Library initialized
2013-08-07 15:40:30 +03:00 --- debug: Auth Library loaded
2013-08-07 15:40:30 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:45:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:45:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:45:18 +03:00 --- debug: Database Library initialized
2013-08-07 15:45:18 +03:00 --- debug: Session Library initialized
2013-08-07 15:45:18 +03:00 --- debug: Auth Library loaded
2013-08-07 15:45:18 +03:00 --- error: Не пойманное Kohana_Exception: Вызов метода title из файла Page_Model невозможен в файле /home/adok/WWW/prupravy.local/system/libraries/ORM.php, на строке 257
2013-08-07 15:45:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:45:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:45:18 +03:00 --- debug: Database Library initialized
2013-08-07 15:45:18 +03:00 --- debug: Session Library initialized
2013-08-07 15:45:18 +03:00 --- debug: Auth Library loaded
2013-08-07 15:45:18 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:45:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:45:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:45:35 +03:00 --- debug: Database Library initialized
2013-08-07 15:45:35 +03:00 --- debug: Session Library initialized
2013-08-07 15:45:35 +03:00 --- debug: Auth Library loaded
2013-08-07 15:45:35 +03:00 --- error: Не пойманное Kohana_Exception: Вызов метода title из файла Page_Model невозможен в файле /home/adok/WWW/prupravy.local/system/libraries/ORM.php, на строке 257
2013-08-07 15:45:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:45:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:45:35 +03:00 --- debug: Database Library initialized
2013-08-07 15:45:35 +03:00 --- debug: Session Library initialized
2013-08-07 15:45:35 +03:00 --- debug: Auth Library loaded
2013-08-07 15:45:35 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:45:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:45:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:45:50 +03:00 --- debug: Database Library initialized
2013-08-07 15:45:50 +03:00 --- debug: Session Library initialized
2013-08-07 15:45:50 +03:00 --- debug: Auth Library loaded
2013-08-07 15:45:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:45:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:45:51 +03:00 --- debug: Database Library initialized
2013-08-07 15:45:51 +03:00 --- debug: Session Library initialized
2013-08-07 15:45:51 +03:00 --- debug: Auth Library loaded
2013-08-07 15:45:51 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:45:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:45:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:45:51 +03:00 --- debug: Database Library initialized
2013-08-07 15:45:51 +03:00 --- debug: Session Library initialized
2013-08-07 15:45:51 +03:00 --- debug: Auth Library loaded
2013-08-07 15:45:51 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:45:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:45:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:45:51 +03:00 --- debug: Database Library initialized
2013-08-07 15:45:51 +03:00 --- debug: Session Library initialized
2013-08-07 15:45:51 +03:00 --- debug: Auth Library loaded
2013-08-07 15:45:51 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:45:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:45:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:45:58 +03:00 --- debug: Database Library initialized
2013-08-07 15:45:58 +03:00 --- debug: Session Library initialized
2013-08-07 15:45:58 +03:00 --- debug: Auth Library loaded
2013-08-07 15:45:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:45:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:45:58 +03:00 --- debug: Database Library initialized
2013-08-07 15:45:58 +03:00 --- debug: Session Library initialized
2013-08-07 15:45:58 +03:00 --- debug: Auth Library loaded
2013-08-07 15:45:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:45:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:45:58 +03:00 --- debug: Database Library initialized
2013-08-07 15:45:58 +03:00 --- debug: Session Library initialized
2013-08-07 15:45:58 +03:00 --- debug: Auth Library loaded
2013-08-07 15:45:58 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:45:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:45:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:45:59 +03:00 --- debug: Database Library initialized
2013-08-07 15:45:59 +03:00 --- debug: Session Library initialized
2013-08-07 15:45:59 +03:00 --- debug: Auth Library loaded
2013-08-07 15:46:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:46:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:46:24 +03:00 --- debug: Database Library initialized
2013-08-07 15:46:24 +03:00 --- debug: Session Library initialized
2013-08-07 15:46:24 +03:00 --- debug: Auth Library loaded
2013-08-07 15:46:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:46:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:46:25 +03:00 --- debug: Database Library initialized
2013-08-07 15:46:25 +03:00 --- debug: Session Library initialized
2013-08-07 15:46:25 +03:00 --- debug: Auth Library loaded
2013-08-07 15:46:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:46:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:46:25 +03:00 --- debug: Database Library initialized
2013-08-07 15:46:25 +03:00 --- debug: Session Library initialized
2013-08-07 15:46:25 +03:00 --- debug: Auth Library loaded
2013-08-07 15:46:25 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:46:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:46:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:46:25 +03:00 --- debug: Database Library initialized
2013-08-07 15:46:25 +03:00 --- debug: Session Library initialized
2013-08-07 15:46:25 +03:00 --- debug: Auth Library loaded
2013-08-07 15:46:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:46:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:46:35 +03:00 --- debug: Database Library initialized
2013-08-07 15:46:35 +03:00 --- debug: Session Library initialized
2013-08-07 15:46:35 +03:00 --- debug: Auth Library loaded
2013-08-07 15:46:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:46:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:46:36 +03:00 --- debug: Database Library initialized
2013-08-07 15:46:36 +03:00 --- debug: Session Library initialized
2013-08-07 15:46:36 +03:00 --- debug: Auth Library loaded
2013-08-07 15:46:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:46:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:46:36 +03:00 --- debug: Database Library initialized
2013-08-07 15:46:36 +03:00 --- debug: Session Library initialized
2013-08-07 15:46:36 +03:00 --- debug: Auth Library loaded
2013-08-07 15:46:36 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:46:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:46:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:46:36 +03:00 --- debug: Database Library initialized
2013-08-07 15:46:36 +03:00 --- debug: Session Library initialized
2013-08-07 15:46:36 +03:00 --- debug: Auth Library loaded
2013-08-07 15:47:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:47:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:47:26 +03:00 --- debug: Database Library initialized
2013-08-07 15:47:26 +03:00 --- debug: Session Library initialized
2013-08-07 15:47:26 +03:00 --- debug: Auth Library loaded
2013-08-07 15:47:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:47:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:47:29 +03:00 --- debug: Database Library initialized
2013-08-07 15:47:29 +03:00 --- debug: Session Library initialized
2013-08-07 15:47:29 +03:00 --- debug: Auth Library loaded
2013-08-07 15:47:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:47:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:47:30 +03:00 --- debug: Database Library initialized
2013-08-07 15:47:30 +03:00 --- debug: Session Library initialized
2013-08-07 15:47:30 +03:00 --- debug: Auth Library loaded
2013-08-07 15:47:30 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:47:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:47:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:47:30 +03:00 --- debug: Database Library initialized
2013-08-07 15:47:30 +03:00 --- debug: Session Library initialized
2013-08-07 15:47:30 +03:00 --- debug: Auth Library loaded
2013-08-07 15:47:30 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:47:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:47:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:47:30 +03:00 --- debug: Database Library initialized
2013-08-07 15:47:30 +03:00 --- debug: Session Library initialized
2013-08-07 15:47:30 +03:00 --- debug: Auth Library loaded
2013-08-07 15:47:30 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:47:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:47:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:47:33 +03:00 --- debug: Database Library initialized
2013-08-07 15:47:33 +03:00 --- debug: Session Library initialized
2013-08-07 15:47:33 +03:00 --- debug: Auth Library loaded
2013-08-07 15:47:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:47:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:47:34 +03:00 --- debug: Database Library initialized
2013-08-07 15:47:34 +03:00 --- debug: Session Library initialized
2013-08-07 15:47:34 +03:00 --- debug: Auth Library loaded
2013-08-07 15:47:34 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:47:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:47:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:47:59 +03:00 --- debug: Database Library initialized
2013-08-07 15:47:59 +03:00 --- debug: Session Library initialized
2013-08-07 15:47:59 +03:00 --- debug: Auth Library loaded
2013-08-07 15:48:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:48:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:48:00 +03:00 --- debug: Database Library initialized
2013-08-07 15:48:00 +03:00 --- debug: Session Library initialized
2013-08-07 15:48:00 +03:00 --- debug: Auth Library loaded
2013-08-07 15:48:00 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:48:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:48:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:48:00 +03:00 --- debug: Database Library initialized
2013-08-07 15:48:00 +03:00 --- debug: Session Library initialized
2013-08-07 15:48:00 +03:00 --- debug: Auth Library loaded
2013-08-07 15:48:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:48:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:48:00 +03:00 --- debug: Database Library initialized
2013-08-07 15:48:00 +03:00 --- debug: Session Library initialized
2013-08-07 15:48:00 +03:00 --- debug: Auth Library loaded
2013-08-07 15:48:00 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:48:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:48:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:48:01 +03:00 --- debug: Database Library initialized
2013-08-07 15:48:01 +03:00 --- debug: Session Library initialized
2013-08-07 15:48:01 +03:00 --- debug: Auth Library loaded
2013-08-07 15:48:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:48:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:48:01 +03:00 --- debug: Database Library initialized
2013-08-07 15:48:01 +03:00 --- debug: Session Library initialized
2013-08-07 15:48:01 +03:00 --- debug: Auth Library loaded
2013-08-07 15:48:01 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:48:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:48:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:48:02 +03:00 --- debug: Database Library initialized
2013-08-07 15:48:02 +03:00 --- debug: Session Library initialized
2013-08-07 15:48:02 +03:00 --- debug: Auth Library loaded
2013-08-07 15:48:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:48:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:48:02 +03:00 --- debug: Database Library initialized
2013-08-07 15:48:02 +03:00 --- debug: Session Library initialized
2013-08-07 15:48:02 +03:00 --- debug: Auth Library loaded
2013-08-07 15:48:02 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:49:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:00 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:00 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:00 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:00 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:00 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:00 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:00 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:49:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:07 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:07 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:07 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:07 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:07 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:07 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:07 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:49:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:08 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:08 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:08 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:08 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:08 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:08 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:49:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:09 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:49:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:10 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:10 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:10 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:10 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:49:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:10 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:10 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:10 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:11 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:11 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:11 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:11 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:49:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:11 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:11 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:11 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:11 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:49:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:11 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:11 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:11 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:11 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:49:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:29 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:29 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:29 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:30 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:30 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:30 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:30 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:49:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:30 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:30 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:30 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:30 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:49:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:30 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:30 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:30 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:30 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:49:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:40 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:40 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:40 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:40 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:40 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:40 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:40 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:49:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:41 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:41 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:41 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:41 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:41 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:41 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:41 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:49:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:41 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:41 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:41 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:42 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:42 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:42 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:42 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:49:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:42 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:42 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:42 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:43 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:43 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:43 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:43 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:49:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:44 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:44 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:44 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:44 +03:00 --- error: Uncaught PHP Error: Undefined index: menu in file /home/adok/WWW/prupravy.local/application/views/header.php on line 29
2013-08-07 15:49:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:44 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:44 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:44 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:44 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:49:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:47 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:47 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:47 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:47 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:47 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:47 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:47 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:49:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:48 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:48 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:48 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:48 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:49:48 +03:00 --- error: core.uncaught_exception
2013-08-07 15:49:48 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-07 15:49:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:49:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:49:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:49:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:49:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:49:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:49:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:49:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:49:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:49:48 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:49:48 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:49:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:48 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:48 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:48 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:48 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:49:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:50 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:50 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:50 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:50 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:50 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:50 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:50 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:49:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:51 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:51 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:51 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:49:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:49:51 +03:00 --- debug: Database Library initialized
2013-08-07 15:49:51 +03:00 --- debug: Session Library initialized
2013-08-07 15:49:51 +03:00 --- debug: Auth Library loaded
2013-08-07 15:49:51 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:50:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:50:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:50:40 +03:00 --- debug: Database Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Session Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Auth Library loaded
2013-08-07 15:50:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:50:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:50:40 +03:00 --- debug: Database Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Session Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Auth Library loaded
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: core.uncaught_exception
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:50:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:50:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:50:40 +03:00 --- debug: Database Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Session Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Auth Library loaded
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: core.uncaught_exception
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:50:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:50:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:50:40 +03:00 --- debug: Database Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Session Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Auth Library loaded
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: core.uncaught_exception
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:50:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:50:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:50:40 +03:00 --- debug: Database Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Session Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Auth Library loaded
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: core.uncaught_exception
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:50:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:50:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:50:40 +03:00 --- debug: Database Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Session Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Auth Library loaded
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: core.uncaught_exception
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:50:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:50:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:50:40 +03:00 --- debug: Database Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Session Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Auth Library loaded
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: core.uncaught_exception
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:50:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:50:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:50:40 +03:00 --- debug: Database Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Session Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Auth Library loaded
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: core.uncaught_exception
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:50:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:50:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:50:40 +03:00 --- debug: Database Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Session Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Auth Library loaded
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: core.uncaught_exception
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:50:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:50:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:50:40 +03:00 --- debug: Database Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Session Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Auth Library loaded
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: core.uncaught_exception
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:50:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:50:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:50:40 +03:00 --- debug: Database Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Session Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Auth Library loaded
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: core.uncaught_exception
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:50:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:50:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:50:40 +03:00 --- debug: Database Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Session Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Auth Library loaded
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: core.uncaught_exception
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:50:40 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:50:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:50:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:50:40 +03:00 --- debug: Database Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Session Library initialized
2013-08-07 15:50:40 +03:00 --- debug: Auth Library loaded
2013-08-07 15:50:40 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:51:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:51:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:51:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:51:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:51:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:51:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: core.uncaught_exception
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:51:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:51:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:51:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: core.uncaught_exception
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:51:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:51:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:51:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: core.uncaught_exception
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:51:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:51:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:51:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: core.uncaught_exception
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:51:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:51:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:51:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: core.uncaught_exception
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:51:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:51:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:51:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: core.uncaught_exception
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:51:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:51:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:51:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: core.uncaught_exception
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:51:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:51:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:51:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: core.uncaught_exception
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:51:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:51:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:51:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: core.uncaught_exception
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:51:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:51:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:51:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: core.uncaught_exception
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:51:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:51:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:51:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: core.uncaught_exception
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:51:49 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:51:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:51:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:51:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:51:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:51:49 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:52:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:52:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:52:27 +03:00 --- debug: Database Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Session Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Auth Library loaded
2013-08-07 15:52:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:52:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:52:27 +03:00 --- debug: Database Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Session Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Auth Library loaded
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: core.uncaught_exception
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:52:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:52:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:52:27 +03:00 --- debug: Database Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Session Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Auth Library loaded
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: core.uncaught_exception
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:52:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:52:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:52:27 +03:00 --- debug: Database Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Session Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Auth Library loaded
2013-08-07 15:52:27 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, http:/prupravy.local/ua/js/jquery.js, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:52:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:52:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:52:27 +03:00 --- debug: Database Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Session Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Auth Library loaded
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: core.uncaught_exception
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:52:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:52:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:52:27 +03:00 --- debug: Database Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Session Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Auth Library loaded
2013-08-07 15:52:27 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, http:/prupravy.local/ua/js/jqueryui.js, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:52:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:52:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:52:27 +03:00 --- debug: Database Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Session Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Auth Library loaded
2013-08-07 15:52:27 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, http:/prupravy.local/ua/js/cufon/cufon-yui.js, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:52:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:52:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:52:27 +03:00 --- debug: Database Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Session Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Auth Library loaded
2013-08-07 15:52:27 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, http:/prupravy.local/ua/js/cufon/cufon-settings.js, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:52:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:52:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:52:27 +03:00 --- debug: Database Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Session Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Auth Library loaded
2013-08-07 15:52:27 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, http:/prupravy.local/ua/js/custom.js, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:52:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:52:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:52:27 +03:00 --- debug: Database Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Session Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Auth Library loaded
2013-08-07 15:52:27 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, http:/prupravy.local/ua/js/cufon/OfficinaSansC_700.font.js, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:52:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:52:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:52:27 +03:00 --- debug: Database Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Session Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Auth Library loaded
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: core.uncaught_exception
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:52:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:52:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:52:27 +03:00 --- debug: Database Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Session Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Auth Library loaded
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: core.uncaught_exception
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:52:27 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:52:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:52:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:52:27 +03:00 --- debug: Database Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Session Library initialized
2013-08-07 15:52:27 +03:00 --- debug: Auth Library loaded
2013-08-07 15:52:27 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:53:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:09 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:09 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:53:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:21 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:21 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:21 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:21 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:21 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:21 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:21 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:21 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:21 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:21 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:21 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:22 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:22 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:22 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:22 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:22 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:22 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:22 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:22 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:22 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:22 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:22 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:22 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:22 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:22 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:53:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:31 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:31 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:31 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:32 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:32 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:32 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:32 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:32 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:32 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:32 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:32 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:32 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:32 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:32 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:32 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:32 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:32 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:32 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: core.uncaught_exception
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:53:32 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:53:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:53:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:53:32 +03:00 --- debug: Database Library initialized
2013-08-07 15:53:32 +03:00 --- debug: Session Library initialized
2013-08-07 15:53:32 +03:00 --- debug: Auth Library loaded
2013-08-07 15:53:32 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:54:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:54:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:54:17 +03:00 --- debug: Database Library initialized
2013-08-07 15:54:17 +03:00 --- debug: Session Library initialized
2013-08-07 15:54:17 +03:00 --- debug: Auth Library loaded
2013-08-07 15:54:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:54:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:54:17 +03:00 --- debug: Database Library initialized
2013-08-07 15:54:17 +03:00 --- debug: Session Library initialized
2013-08-07 15:54:17 +03:00 --- debug: Auth Library loaded
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:54:17 +03:00 --- error: core.uncaught_exception
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:54:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:54:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:54:17 +03:00 --- debug: Database Library initialized
2013-08-07 15:54:17 +03:00 --- debug: Session Library initialized
2013-08-07 15:54:17 +03:00 --- debug: Auth Library loaded
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:54:17 +03:00 --- error: core.uncaught_exception
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:54:17 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:54:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:54:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:54:17 +03:00 --- debug: Database Library initialized
2013-08-07 15:54:17 +03:00 --- debug: Session Library initialized
2013-08-07 15:54:17 +03:00 --- debug: Auth Library loaded
2013-08-07 15:54:17 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:54:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:54:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:54:37 +03:00 --- debug: Database Library initialized
2013-08-07 15:54:37 +03:00 --- debug: Session Library initialized
2013-08-07 15:54:37 +03:00 --- debug: Auth Library loaded
2013-08-07 15:54:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:54:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:54:37 +03:00 --- debug: Database Library initialized
2013-08-07 15:54:37 +03:00 --- debug: Session Library initialized
2013-08-07 15:54:37 +03:00 --- debug: Auth Library loaded
2013-08-07 15:54:37 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:54:37 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:54:37 +03:00 --- error: core.uncaught_exception
2013-08-07 15:54:37 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:54:37 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:54:37 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:54:37 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:54:37 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:54:37 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:54:37 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:54:37 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:54:37 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:54:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:54:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:54:37 +03:00 --- debug: Database Library initialized
2013-08-07 15:54:37 +03:00 --- debug: Session Library initialized
2013-08-07 15:54:37 +03:00 --- debug: Auth Library loaded
2013-08-07 15:54:37 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:55:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:55:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:55:43 +03:00 --- debug: Database Library initialized
2013-08-07 15:55:43 +03:00 --- debug: Session Library initialized
2013-08-07 15:55:43 +03:00 --- debug: Auth Library loaded
2013-08-07 15:55:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:55:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:55:43 +03:00 --- debug: Database Library initialized
2013-08-07 15:55:43 +03:00 --- debug: Session Library initialized
2013-08-07 15:55:43 +03:00 --- debug: Auth Library loaded
2013-08-07 15:55:43 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-07 15:55:43 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-07 15:55:43 +03:00 --- error: core.uncaught_exception
2013-08-07 15:55:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:55:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:55:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:55:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:55:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:55:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:55:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-07 15:55:43 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-07 15:55:43 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-07 15:55:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:55:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:55:43 +03:00 --- debug: Database Library initialized
2013-08-07 15:55:43 +03:00 --- debug: Session Library initialized
2013-08-07 15:55:43 +03:00 --- debug: Auth Library loaded
2013-08-07 15:55:43 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:56:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:56:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:56:03 +03:00 --- debug: Database Library initialized
2013-08-07 15:56:03 +03:00 --- debug: Session Library initialized
2013-08-07 15:56:03 +03:00 --- debug: Auth Library loaded
2013-08-07 15:56:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:56:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:56:03 +03:00 --- debug: Database Library initialized
2013-08-07 15:56:03 +03:00 --- debug: Session Library initialized
2013-08-07 15:56:03 +03:00 --- debug: Auth Library loaded
2013-08-07 15:56:03 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:56:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:56:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:56:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:56:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:56:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:56:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:56:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:56:09 +03:00 --- debug: Database Library initialized
2013-08-07 15:56:09 +03:00 --- debug: Session Library initialized
2013-08-07 15:56:09 +03:00 --- debug: Auth Library loaded
2013-08-07 15:56:09 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:56:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:56:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:56:10 +03:00 --- debug: Database Library initialized
2013-08-07 15:56:10 +03:00 --- debug: Session Library initialized
2013-08-07 15:56:10 +03:00 --- debug: Auth Library loaded
2013-08-07 15:56:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:56:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:56:10 +03:00 --- debug: Database Library initialized
2013-08-07 15:56:10 +03:00 --- debug: Session Library initialized
2013-08-07 15:56:10 +03:00 --- debug: Auth Library loaded
2013-08-07 15:56:10 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:56:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:56:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:56:11 +03:00 --- debug: Database Library initialized
2013-08-07 15:56:11 +03:00 --- debug: Session Library initialized
2013-08-07 15:56:11 +03:00 --- debug: Auth Library loaded
2013-08-07 15:56:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:56:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:56:11 +03:00 --- debug: Database Library initialized
2013-08-07 15:56:11 +03:00 --- debug: Session Library initialized
2013-08-07 15:56:11 +03:00 --- debug: Auth Library loaded
2013-08-07 15:56:11 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:56:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:56:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:56:12 +03:00 --- debug: Database Library initialized
2013-08-07 15:56:12 +03:00 --- debug: Session Library initialized
2013-08-07 15:56:12 +03:00 --- debug: Auth Library loaded
2013-08-07 15:56:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:56:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:56:12 +03:00 --- debug: Database Library initialized
2013-08-07 15:56:12 +03:00 --- debug: Session Library initialized
2013-08-07 15:56:12 +03:00 --- debug: Auth Library loaded
2013-08-07 15:56:12 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:56:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:56:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:56:13 +03:00 --- debug: Database Library initialized
2013-08-07 15:56:13 +03:00 --- debug: Session Library initialized
2013-08-07 15:56:13 +03:00 --- debug: Auth Library loaded
2013-08-07 15:56:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:56:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:56:13 +03:00 --- debug: Database Library initialized
2013-08-07 15:56:13 +03:00 --- debug: Session Library initialized
2013-08-07 15:56:13 +03:00 --- debug: Auth Library loaded
2013-08-07 15:56:13 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:56:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:56:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:56:15 +03:00 --- debug: Database Library initialized
2013-08-07 15:56:15 +03:00 --- debug: Session Library initialized
2013-08-07 15:56:15 +03:00 --- debug: Auth Library loaded
2013-08-07 15:56:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:56:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:56:15 +03:00 --- debug: Database Library initialized
2013-08-07 15:56:15 +03:00 --- debug: Session Library initialized
2013-08-07 15:56:15 +03:00 --- debug: Auth Library loaded
2013-08-07 15:56:15 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:56:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:56:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:56:16 +03:00 --- debug: Database Library initialized
2013-08-07 15:56:16 +03:00 --- debug: Session Library initialized
2013-08-07 15:56:16 +03:00 --- debug: Auth Library loaded
2013-08-07 15:56:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:56:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:56:16 +03:00 --- debug: Database Library initialized
2013-08-07 15:56:16 +03:00 --- debug: Session Library initialized
2013-08-07 15:56:16 +03:00 --- debug: Auth Library loaded
2013-08-07 15:56:16 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:56:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:56:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:56:17 +03:00 --- debug: Database Library initialized
2013-08-07 15:56:17 +03:00 --- debug: Session Library initialized
2013-08-07 15:56:17 +03:00 --- debug: Auth Library loaded
2013-08-07 15:56:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:56:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:56:17 +03:00 --- debug: Database Library initialized
2013-08-07 15:56:17 +03:00 --- debug: Session Library initialized
2013-08-07 15:56:17 +03:00 --- debug: Auth Library loaded
2013-08-07 15:56:17 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:57:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:57:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:57:47 +03:00 --- debug: Database Library initialized
2013-08-07 15:57:47 +03:00 --- debug: Session Library initialized
2013-08-07 15:57:47 +03:00 --- debug: Auth Library loaded
2013-08-07 15:57:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:57:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:57:47 +03:00 --- debug: Database Library initialized
2013-08-07 15:57:47 +03:00 --- debug: Session Library initialized
2013-08-07 15:57:47 +03:00 --- debug: Auth Library loaded
2013-08-07 15:57:47 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:57:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:57:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:57:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:57:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:57:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:57:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:57:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:57:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:57:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:57:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:57:49 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:57:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:57:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:57:51 +03:00 --- debug: Database Library initialized
2013-08-07 15:57:51 +03:00 --- debug: Session Library initialized
2013-08-07 15:57:51 +03:00 --- debug: Auth Library loaded
2013-08-07 15:57:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:57:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:57:51 +03:00 --- debug: Database Library initialized
2013-08-07 15:57:51 +03:00 --- debug: Session Library initialized
2013-08-07 15:57:51 +03:00 --- debug: Auth Library loaded
2013-08-07 15:57:51 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:57:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:57:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:57:52 +03:00 --- debug: Database Library initialized
2013-08-07 15:57:52 +03:00 --- debug: Session Library initialized
2013-08-07 15:57:52 +03:00 --- debug: Auth Library loaded
2013-08-07 15:57:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:57:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:57:52 +03:00 --- debug: Database Library initialized
2013-08-07 15:57:52 +03:00 --- debug: Session Library initialized
2013-08-07 15:57:52 +03:00 --- debug: Auth Library loaded
2013-08-07 15:57:52 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:57:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:57:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:57:53 +03:00 --- debug: Database Library initialized
2013-08-07 15:57:53 +03:00 --- debug: Session Library initialized
2013-08-07 15:57:53 +03:00 --- debug: Auth Library loaded
2013-08-07 15:57:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:57:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:57:53 +03:00 --- debug: Database Library initialized
2013-08-07 15:57:53 +03:00 --- debug: Session Library initialized
2013-08-07 15:57:53 +03:00 --- debug: Auth Library loaded
2013-08-07 15:57:53 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:57:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:57:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:57:55 +03:00 --- debug: Database Library initialized
2013-08-07 15:57:55 +03:00 --- debug: Session Library initialized
2013-08-07 15:57:55 +03:00 --- debug: Auth Library loaded
2013-08-07 15:57:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:57:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:57:56 +03:00 --- debug: Database Library initialized
2013-08-07 15:57:56 +03:00 --- debug: Session Library initialized
2013-08-07 15:57:56 +03:00 --- debug: Auth Library loaded
2013-08-07 15:57:56 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:57:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:57:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:57:57 +03:00 --- debug: Database Library initialized
2013-08-07 15:57:57 +03:00 --- debug: Session Library initialized
2013-08-07 15:57:57 +03:00 --- debug: Auth Library loaded
2013-08-07 15:57:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:57:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:57:57 +03:00 --- debug: Database Library initialized
2013-08-07 15:57:57 +03:00 --- debug: Session Library initialized
2013-08-07 15:57:57 +03:00 --- debug: Auth Library loaded
2013-08-07 15:57:57 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:58:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:58:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:58:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:58:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:58:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:58:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:58:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:58:49 +03:00 --- debug: Database Library initialized
2013-08-07 15:58:49 +03:00 --- debug: Session Library initialized
2013-08-07 15:58:49 +03:00 --- debug: Auth Library loaded
2013-08-07 15:58:49 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:59:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:34 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:34 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:34 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:34 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:34 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:34 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:34 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:59:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:41 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:41 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:41 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:41 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:41 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:41 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:41 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:59:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:43 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:43 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:43 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:43 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:43 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:43 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:43 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:59:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:47 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:47 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:47 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:48 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:48 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:48 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:48 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:59:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:48 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:48 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:48 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:48 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:59:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:48 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:48 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:48 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:48 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:59:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:50 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:50 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:50 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:50 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:50 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:50 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:50 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:59:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:51 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:51 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:51 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:51 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:51 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:51 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:51 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:59:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:51 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:51 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:51 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:51 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:51 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:51 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:51 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:59:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:53 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:53 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:53 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:53 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:53 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:53 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:53 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:59:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:57 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:57 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:57 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:57 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:57 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:57 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:57 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:59:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:58 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:58 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:58 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:58 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:58 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:58 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:58 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 15:59:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:59 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:59 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:59 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 15:59:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 15:59:59 +03:00 --- debug: Database Library initialized
2013-08-07 15:59:59 +03:00 --- debug: Session Library initialized
2013-08-07 15:59:59 +03:00 --- debug: Auth Library loaded
2013-08-07 15:59:59 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:00:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:00 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:00 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:00 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:00 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:00 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:00 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:00 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:00:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:00 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:00 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:00 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:00 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:00 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:00 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:00 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:00:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:01 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:01 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:01 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:01 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:01 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:01 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:01 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:00:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:02 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:02 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:02 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:02 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:02 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:02 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:02 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:00:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:03 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:03 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:03 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:03 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:03 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:03 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:03 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:00:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:07 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:07 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:07 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:07 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:07 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:07 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:07 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:00:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:07 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:07 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:07 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:08 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:08 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:08 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:00:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:22 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:22 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:22 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:22 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:22 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:22 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:22 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:00:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:23 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:23 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:23 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:23 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:00:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:23 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:23 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:23 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:23 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:00:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:24 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:24 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:24 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:24 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:24 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:24 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:24 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:00:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:26 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:26 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:26 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:27 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:27 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:27 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:27 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:00:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:29 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:29 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:29 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:29 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:29 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:29 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:29 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:00:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:31 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:31 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:31 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:31 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:31 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:31 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:31 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:00:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:40 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:40 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:40 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:00:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:00:40 +03:00 --- debug: Database Library initialized
2013-08-07 16:00:40 +03:00 --- debug: Session Library initialized
2013-08-07 16:00:40 +03:00 --- debug: Auth Library loaded
2013-08-07 16:00:40 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:02:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:02:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:02:27 +03:00 --- debug: Database Library initialized
2013-08-07 16:02:27 +03:00 --- debug: Session Library initialized
2013-08-07 16:02:27 +03:00 --- debug: Auth Library loaded
2013-08-07 16:02:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:02:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:02:27 +03:00 --- debug: Database Library initialized
2013-08-07 16:02:27 +03:00 --- debug: Session Library initialized
2013-08-07 16:02:27 +03:00 --- debug: Auth Library loaded
2013-08-07 16:02:27 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:03:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:03:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:03:09 +03:00 --- debug: Database Library initialized
2013-08-07 16:03:09 +03:00 --- debug: Session Library initialized
2013-08-07 16:03:09 +03:00 --- debug: Auth Library loaded
2013-08-07 16:03:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:03:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:03:09 +03:00 --- debug: Database Library initialized
2013-08-07 16:03:09 +03:00 --- debug: Session Library initialized
2013-08-07 16:03:09 +03:00 --- debug: Auth Library loaded
2013-08-07 16:03:09 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:03:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:03:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:03:39 +03:00 --- debug: Database Library initialized
2013-08-07 16:03:39 +03:00 --- debug: Session Library initialized
2013-08-07 16:03:39 +03:00 --- debug: Auth Library loaded
2013-08-07 16:03:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:03:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:03:40 +03:00 --- debug: Database Library initialized
2013-08-07 16:03:40 +03:00 --- debug: Session Library initialized
2013-08-07 16:03:40 +03:00 --- debug: Auth Library loaded
2013-08-07 16:03:40 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:03:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:03:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:03:46 +03:00 --- debug: Database Library initialized
2013-08-07 16:03:46 +03:00 --- debug: Session Library initialized
2013-08-07 16:03:46 +03:00 --- debug: Auth Library loaded
2013-08-07 16:03:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:03:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:03:46 +03:00 --- debug: Database Library initialized
2013-08-07 16:03:46 +03:00 --- debug: Session Library initialized
2013-08-07 16:03:46 +03:00 --- debug: Auth Library loaded
2013-08-07 16:03:46 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:04:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:04:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:04:55 +03:00 --- debug: Database Library initialized
2013-08-07 16:04:55 +03:00 --- debug: Session Library initialized
2013-08-07 16:04:55 +03:00 --- debug: Auth Library loaded
2013-08-07 16:04:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:04:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:04:55 +03:00 --- debug: Database Library initialized
2013-08-07 16:04:55 +03:00 --- debug: Session Library initialized
2013-08-07 16:04:55 +03:00 --- debug: Auth Library loaded
2013-08-07 16:04:55 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:05:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:05:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:05:00 +03:00 --- debug: Database Library initialized
2013-08-07 16:05:00 +03:00 --- debug: Session Library initialized
2013-08-07 16:05:00 +03:00 --- debug: Auth Library loaded
2013-08-07 16:05:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:05:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:05:00 +03:00 --- debug: Database Library initialized
2013-08-07 16:05:00 +03:00 --- debug: Session Library initialized
2013-08-07 16:05:00 +03:00 --- debug: Auth Library loaded
2013-08-07 16:05:00 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:05:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:05:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:05:18 +03:00 --- debug: Database Library initialized
2013-08-07 16:05:18 +03:00 --- debug: Session Library initialized
2013-08-07 16:05:18 +03:00 --- debug: Auth Library loaded
2013-08-07 16:05:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:05:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:05:18 +03:00 --- debug: Database Library initialized
2013-08-07 16:05:18 +03:00 --- debug: Session Library initialized
2013-08-07 16:05:18 +03:00 --- debug: Auth Library loaded
2013-08-07 16:05:18 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:05:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:05:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:05:24 +03:00 --- debug: Database Library initialized
2013-08-07 16:05:24 +03:00 --- debug: Session Library initialized
2013-08-07 16:05:24 +03:00 --- debug: Auth Library loaded
2013-08-07 16:05:24 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:05:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:05:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:05:24 +03:00 --- debug: Database Library initialized
2013-08-07 16:05:24 +03:00 --- debug: Session Library initialized
2013-08-07 16:05:24 +03:00 --- debug: Auth Library loaded
2013-08-07 16:05:24 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:05:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:05:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:05:25 +03:00 --- debug: Database Library initialized
2013-08-07 16:05:25 +03:00 --- debug: Session Library initialized
2013-08-07 16:05:25 +03:00 --- debug: Auth Library loaded
2013-08-07 16:05:25 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:05:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:05:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:05:25 +03:00 --- debug: Database Library initialized
2013-08-07 16:05:25 +03:00 --- debug: Session Library initialized
2013-08-07 16:05:25 +03:00 --- debug: Auth Library loaded
2013-08-07 16:05:25 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:05:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:05:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:05:27 +03:00 --- debug: Database Library initialized
2013-08-07 16:05:27 +03:00 --- debug: Session Library initialized
2013-08-07 16:05:27 +03:00 --- debug: Auth Library loaded
2013-08-07 16:05:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:05:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:05:27 +03:00 --- debug: Database Library initialized
2013-08-07 16:05:27 +03:00 --- debug: Session Library initialized
2013-08-07 16:05:27 +03:00 --- debug: Auth Library loaded
2013-08-07 16:05:27 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:05:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:05:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:05:28 +03:00 --- debug: Database Library initialized
2013-08-07 16:05:28 +03:00 --- debug: Session Library initialized
2013-08-07 16:05:28 +03:00 --- debug: Auth Library loaded
2013-08-07 16:05:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:05:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:05:28 +03:00 --- debug: Database Library initialized
2013-08-07 16:05:28 +03:00 --- debug: Session Library initialized
2013-08-07 16:05:28 +03:00 --- debug: Auth Library loaded
2013-08-07 16:05:28 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:05:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:05:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:05:31 +03:00 --- debug: Database Library initialized
2013-08-07 16:05:31 +03:00 --- debug: Session Library initialized
2013-08-07 16:05:31 +03:00 --- debug: Auth Library loaded
2013-08-07 16:05:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:05:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:05:32 +03:00 --- debug: Database Library initialized
2013-08-07 16:05:32 +03:00 --- debug: Session Library initialized
2013-08-07 16:05:32 +03:00 --- debug: Auth Library loaded
2013-08-07 16:05:32 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:05:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:05:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:05:34 +03:00 --- debug: Database Library initialized
2013-08-07 16:05:34 +03:00 --- debug: Session Library initialized
2013-08-07 16:05:34 +03:00 --- debug: Auth Library loaded
2013-08-07 16:05:34 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:05:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:05:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:05:40 +03:00 --- debug: Database Library initialized
2013-08-07 16:05:40 +03:00 --- debug: Session Library initialized
2013-08-07 16:05:40 +03:00 --- debug: Auth Library loaded
2013-08-07 16:05:40 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:05:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:05:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:05:40 +03:00 --- debug: Database Library initialized
2013-08-07 16:05:40 +03:00 --- debug: Session Library initialized
2013-08-07 16:05:40 +03:00 --- debug: Auth Library loaded
2013-08-07 16:05:40 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:05:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:05:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:05:40 +03:00 --- debug: Database Library initialized
2013-08-07 16:05:40 +03:00 --- debug: Session Library initialized
2013-08-07 16:05:40 +03:00 --- debug: Auth Library loaded
2013-08-07 16:05:40 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:05:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:05:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:05:55 +03:00 --- debug: Database Library initialized
2013-08-07 16:05:55 +03:00 --- debug: Session Library initialized
2013-08-07 16:05:55 +03:00 --- debug: Auth Library loaded
2013-08-07 16:05:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:05:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:05:56 +03:00 --- debug: Database Library initialized
2013-08-07 16:05:56 +03:00 --- debug: Session Library initialized
2013-08-07 16:05:56 +03:00 --- debug: Auth Library loaded
2013-08-07 16:05:56 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:06:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:06:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:06:09 +03:00 --- debug: Database Library initialized
2013-08-07 16:06:09 +03:00 --- debug: Session Library initialized
2013-08-07 16:06:09 +03:00 --- debug: Auth Library loaded
2013-08-07 16:06:09 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:06:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:06:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:06:10 +03:00 --- debug: Database Library initialized
2013-08-07 16:06:10 +03:00 --- debug: Session Library initialized
2013-08-07 16:06:10 +03:00 --- debug: Auth Library loaded
2013-08-07 16:06:10 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:06:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:06:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:06:12 +03:00 --- debug: Database Library initialized
2013-08-07 16:06:12 +03:00 --- debug: Session Library initialized
2013-08-07 16:06:12 +03:00 --- debug: Auth Library loaded
2013-08-07 16:06:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:06:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:06:12 +03:00 --- debug: Database Library initialized
2013-08-07 16:06:12 +03:00 --- debug: Session Library initialized
2013-08-07 16:06:12 +03:00 --- debug: Auth Library loaded
2013-08-07 16:06:12 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:06:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:06:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:06:13 +03:00 --- debug: Database Library initialized
2013-08-07 16:06:13 +03:00 --- debug: Session Library initialized
2013-08-07 16:06:13 +03:00 --- debug: Auth Library loaded
2013-08-07 16:06:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:06:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:06:13 +03:00 --- debug: Database Library initialized
2013-08-07 16:06:13 +03:00 --- debug: Session Library initialized
2013-08-07 16:06:13 +03:00 --- debug: Auth Library loaded
2013-08-07 16:06:13 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:06:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:06:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:06:13 +03:00 --- debug: Database Library initialized
2013-08-07 16:06:13 +03:00 --- debug: Session Library initialized
2013-08-07 16:06:13 +03:00 --- debug: Auth Library loaded
2013-08-07 16:06:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:06:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:06:14 +03:00 --- debug: Database Library initialized
2013-08-07 16:06:14 +03:00 --- debug: Session Library initialized
2013-08-07 16:06:14 +03:00 --- debug: Auth Library loaded
2013-08-07 16:06:14 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:07:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:07:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:07:06 +03:00 --- debug: Database Library initialized
2013-08-07 16:07:06 +03:00 --- debug: Session Library initialized
2013-08-07 16:07:06 +03:00 --- debug: Auth Library loaded
2013-08-07 16:07:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:07:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:07:07 +03:00 --- debug: Database Library initialized
2013-08-07 16:07:07 +03:00 --- debug: Session Library initialized
2013-08-07 16:07:07 +03:00 --- debug: Auth Library loaded
2013-08-07 16:07:07 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:07:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:07:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:07:09 +03:00 --- debug: Database Library initialized
2013-08-07 16:07:09 +03:00 --- debug: Session Library initialized
2013-08-07 16:07:09 +03:00 --- debug: Auth Library loaded
2013-08-07 16:07:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:07:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:07:09 +03:00 --- debug: Database Library initialized
2013-08-07 16:07:09 +03:00 --- debug: Session Library initialized
2013-08-07 16:07:09 +03:00 --- debug: Auth Library loaded
2013-08-07 16:07:09 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:07:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:07:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:07:20 +03:00 --- debug: Database Library initialized
2013-08-07 16:07:20 +03:00 --- debug: Session Library initialized
2013-08-07 16:07:20 +03:00 --- debug: Auth Library loaded
2013-08-07 16:07:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:07:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:07:20 +03:00 --- debug: Database Library initialized
2013-08-07 16:07:20 +03:00 --- debug: Session Library initialized
2013-08-07 16:07:20 +03:00 --- debug: Auth Library loaded
2013-08-07 16:07:20 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:07:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:07:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:07:23 +03:00 --- debug: Database Library initialized
2013-08-07 16:07:23 +03:00 --- debug: Session Library initialized
2013-08-07 16:07:23 +03:00 --- debug: Auth Library loaded
2013-08-07 16:07:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:07:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:07:23 +03:00 --- debug: Database Library initialized
2013-08-07 16:07:23 +03:00 --- debug: Session Library initialized
2013-08-07 16:07:23 +03:00 --- debug: Auth Library loaded
2013-08-07 16:07:23 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:08:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:08:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:08:13 +03:00 --- debug: Database Library initialized
2013-08-07 16:08:13 +03:00 --- debug: Session Library initialized
2013-08-07 16:08:13 +03:00 --- debug: Auth Library loaded
2013-08-07 16:08:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:08:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:08:13 +03:00 --- debug: Database Library initialized
2013-08-07 16:08:13 +03:00 --- debug: Session Library initialized
2013-08-07 16:08:13 +03:00 --- debug: Auth Library loaded
2013-08-07 16:08:13 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:08:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:08:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:08:15 +03:00 --- debug: Database Library initialized
2013-08-07 16:08:15 +03:00 --- debug: Session Library initialized
2013-08-07 16:08:15 +03:00 --- debug: Auth Library loaded
2013-08-07 16:08:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:08:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:08:15 +03:00 --- debug: Database Library initialized
2013-08-07 16:08:15 +03:00 --- debug: Session Library initialized
2013-08-07 16:08:15 +03:00 --- debug: Auth Library loaded
2013-08-07 16:08:15 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:08:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:08:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:08:16 +03:00 --- debug: Database Library initialized
2013-08-07 16:08:16 +03:00 --- debug: Session Library initialized
2013-08-07 16:08:16 +03:00 --- debug: Auth Library loaded
2013-08-07 16:08:16 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:08:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:08:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:08:17 +03:00 --- debug: Database Library initialized
2013-08-07 16:08:17 +03:00 --- debug: Session Library initialized
2013-08-07 16:08:17 +03:00 --- debug: Auth Library loaded
2013-08-07 16:08:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:08:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:08:17 +03:00 --- debug: Database Library initialized
2013-08-07 16:08:17 +03:00 --- debug: Session Library initialized
2013-08-07 16:08:17 +03:00 --- debug: Auth Library loaded
2013-08-07 16:08:17 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:08:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:08:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:08:20 +03:00 --- debug: Database Library initialized
2013-08-07 16:08:20 +03:00 --- debug: Session Library initialized
2013-08-07 16:08:20 +03:00 --- debug: Auth Library loaded
2013-08-07 16:08:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:08:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:08:20 +03:00 --- debug: Database Library initialized
2013-08-07 16:08:20 +03:00 --- debug: Session Library initialized
2013-08-07 16:08:20 +03:00 --- debug: Auth Library loaded
2013-08-07 16:08:20 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:08:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:08:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:08:22 +03:00 --- debug: Database Library initialized
2013-08-07 16:08:22 +03:00 --- debug: Session Library initialized
2013-08-07 16:08:22 +03:00 --- debug: Auth Library loaded
2013-08-07 16:08:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:08:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:08:22 +03:00 --- debug: Database Library initialized
2013-08-07 16:08:22 +03:00 --- debug: Session Library initialized
2013-08-07 16:08:22 +03:00 --- debug: Auth Library loaded
2013-08-07 16:08:22 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:08:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:08:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:08:24 +03:00 --- debug: Database Library initialized
2013-08-07 16:08:24 +03:00 --- debug: Session Library initialized
2013-08-07 16:08:24 +03:00 --- debug: Auth Library loaded
2013-08-07 16:08:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:08:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:08:24 +03:00 --- debug: Database Library initialized
2013-08-07 16:08:24 +03:00 --- debug: Session Library initialized
2013-08-07 16:08:24 +03:00 --- debug: Auth Library loaded
2013-08-07 16:08:24 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:08:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:08:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:08:25 +03:00 --- debug: Database Library initialized
2013-08-07 16:08:25 +03:00 --- debug: Session Library initialized
2013-08-07 16:08:25 +03:00 --- debug: Auth Library loaded
2013-08-07 16:08:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:08:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:08:25 +03:00 --- debug: Database Library initialized
2013-08-07 16:08:25 +03:00 --- debug: Session Library initialized
2013-08-07 16:08:25 +03:00 --- debug: Auth Library loaded
2013-08-07 16:08:25 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:08 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:08 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:08 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:08 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:08 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:08 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:10 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:10 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:10 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:10 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:10 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:10 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:10 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:11 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:11 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:11 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:12 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:12 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:12 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:12 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:13 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:13 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:13 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:13 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:13 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:13 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:13 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:14 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:14 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:14 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:15 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:15 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:15 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:15 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:16 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:16 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:16 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:16 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:16 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:16 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:16 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:17 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:17 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:17 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:17 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:17 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:17 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:17 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:18 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:18 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:18 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:18 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:18 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:18 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:18 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:21 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:21 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:21 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:21 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:21 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:21 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:21 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:24 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:24 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:24 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:24 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:24 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:24 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:24 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:24 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:24 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:24 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:24 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:24 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:24 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:24 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:24 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:25 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:25 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:25 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:25 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:25 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:25 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:25 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:25 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:25 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:25 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:26 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:26 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:26 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:26 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:26 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:26 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:26 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:26 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:26 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:26 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:26 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:26 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:26 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:26 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:27 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:27 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:27 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:27 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:31 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:31 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:31 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:31 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:31 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:31 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:31 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:32 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:32 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:32 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:32 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:32 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:32 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:32 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:32 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:32 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:32 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:32 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:32 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:32 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:32 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:32 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:33 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:33 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:33 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:33 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:33 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:33 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:33 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:33 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:33 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:33 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:33 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:33 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:33 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:33 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:33 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:09:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:35 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:35 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:35 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:09:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:09:35 +03:00 --- debug: Database Library initialized
2013-08-07 16:09:35 +03:00 --- debug: Session Library initialized
2013-08-07 16:09:35 +03:00 --- debug: Auth Library loaded
2013-08-07 16:09:35 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:11:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:11:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:11:15 +03:00 --- debug: Database Library initialized
2013-08-07 16:11:15 +03:00 --- debug: Session Library initialized
2013-08-07 16:11:15 +03:00 --- debug: Auth Library loaded
2013-08-07 16:11:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:11:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:11:15 +03:00 --- debug: Database Library initialized
2013-08-07 16:11:15 +03:00 --- debug: Session Library initialized
2013-08-07 16:11:15 +03:00 --- debug: Auth Library loaded
2013-08-07 16:11:15 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:11:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:11:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:11:15 +03:00 --- debug: Database Library initialized
2013-08-07 16:11:15 +03:00 --- debug: Session Library initialized
2013-08-07 16:11:15 +03:00 --- debug: Auth Library loaded
2013-08-07 16:11:15 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:11:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:11:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:11:15 +03:00 --- debug: Database Library initialized
2013-08-07 16:11:15 +03:00 --- debug: Session Library initialized
2013-08-07 16:11:15 +03:00 --- debug: Auth Library loaded
2013-08-07 16:11:15 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:11:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:11:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:11:16 +03:00 --- debug: Database Library initialized
2013-08-07 16:11:16 +03:00 --- debug: Session Library initialized
2013-08-07 16:11:16 +03:00 --- debug: Auth Library loaded
2013-08-07 16:11:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:11:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:11:16 +03:00 --- debug: Database Library initialized
2013-08-07 16:11:16 +03:00 --- debug: Session Library initialized
2013-08-07 16:11:16 +03:00 --- debug: Auth Library loaded
2013-08-07 16:11:16 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:11:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:11:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:11:34 +03:00 --- debug: Database Library initialized
2013-08-07 16:11:34 +03:00 --- debug: Session Library initialized
2013-08-07 16:11:34 +03:00 --- debug: Auth Library loaded
2013-08-07 16:11:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:11:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:11:35 +03:00 --- debug: Database Library initialized
2013-08-07 16:11:35 +03:00 --- debug: Session Library initialized
2013-08-07 16:11:35 +03:00 --- debug: Auth Library loaded
2013-08-07 16:11:35 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:11:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:11:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:11:36 +03:00 --- debug: Database Library initialized
2013-08-07 16:11:36 +03:00 --- debug: Session Library initialized
2013-08-07 16:11:36 +03:00 --- debug: Auth Library loaded
2013-08-07 16:11:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:11:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:11:36 +03:00 --- debug: Database Library initialized
2013-08-07 16:11:36 +03:00 --- debug: Session Library initialized
2013-08-07 16:11:36 +03:00 --- debug: Auth Library loaded
2013-08-07 16:11:36 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:11:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:11:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:11:39 +03:00 --- debug: Database Library initialized
2013-08-07 16:11:39 +03:00 --- debug: Session Library initialized
2013-08-07 16:11:39 +03:00 --- debug: Auth Library loaded
2013-08-07 16:11:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:11:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:11:39 +03:00 --- debug: Database Library initialized
2013-08-07 16:11:39 +03:00 --- debug: Session Library initialized
2013-08-07 16:11:39 +03:00 --- debug: Auth Library loaded
2013-08-07 16:11:39 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:14:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:03 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:03 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:03 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:03 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:03 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:03 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:03 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:14:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:05 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:05 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:05 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:05 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:05 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:05 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:05 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:14:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:08 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:08 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:08 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:08 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:08 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:08 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:14:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:10 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:10 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:10 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:10 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:10 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:10 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:10 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:14:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:19 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:19 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:19 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:20 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:20 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:20 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:20 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:14:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:21 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:21 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:21 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:21 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:21 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:21 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:21 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:14:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:22 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:22 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:22 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:22 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:22 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:22 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:22 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:14:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:23 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:23 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:23 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:23 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:23 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:23 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:23 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:14:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:27 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:27 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:27 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:27 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:27 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:27 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:27 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:14:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:28 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:28 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:28 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:28 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:28 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:28 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:28 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:14:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:31 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:31 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:31 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:33 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:33 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:33 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:35 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:35 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:35 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:43 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:43 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:43 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:43 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:43 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:43 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:43 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:14:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:44 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:44 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:44 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:44 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:44 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:44 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:44 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:14:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:48 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:48 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:48 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:48 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:48 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:48 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:48 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 16:14:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:49 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:49 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:49 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 16:14:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 16:14:50 +03:00 --- debug: Database Library initialized
2013-08-07 16:14:50 +03:00 --- debug: Session Library initialized
2013-08-07 16:14:50 +03:00 --- debug: Auth Library loaded
2013-08-07 16:14:50 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 17:55:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:22 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:22 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 17:55:22 +03:00 --- debug: Database Library initialized
2013-08-07 17:55:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:22 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:22 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:22 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 17:55:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:25 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:25 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 17:55:25 +03:00 --- debug: Database Library initialized
2013-08-07 17:55:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:25 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:25 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:25 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 17:55:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:30 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:30 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 17:55:30 +03:00 --- debug: Database Library initialized
2013-08-07 17:55:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:31 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:31 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 17:55:31 +03:00 --- debug: Database Library initialized
2013-08-07 17:55:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:31 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:31 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:31 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 17:55:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:31 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:31 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:31 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 17:55:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:32 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:32 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 17:55:32 +03:00 --- debug: Database Library initialized
2013-08-07 17:55:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:33 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:33 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:33 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 17:55:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:33 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:33 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 17:55:33 +03:00 --- debug: Database Library initialized
2013-08-07 17:55:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:33 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:33 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:33 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 17:55:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:33 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:33 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 17:55:33 +03:00 --- debug: Database Library initialized
2013-08-07 17:55:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:34 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:34 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:34 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 17:55:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:34 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:34 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 17:55:34 +03:00 --- debug: Database Library initialized
2013-08-07 17:55:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:34 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:34 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:34 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 17:55:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:34 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:34 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 17:55:34 +03:00 --- debug: Database Library initialized
2013-08-07 17:55:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:34 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:34 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:34 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 17:55:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:35 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:35 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 17:55:35 +03:00 --- debug: Database Library initialized
2013-08-07 17:55:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:35 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:35 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:35 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 17:55:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:36 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:36 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 17:55:36 +03:00 --- debug: Database Library initialized
2013-08-07 17:55:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:36 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:36 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 17:55:36 +03:00 --- debug: Database Library initialized
2013-08-07 17:55:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:36 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:36 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:36 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 17:55:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:36 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:36 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:36 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 17:55:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:37 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:37 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 17:55:37 +03:00 --- debug: Database Library initialized
2013-08-07 17:55:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:37 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:37 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:37 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 17:55:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:37 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:37 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 17:55:37 +03:00 --- debug: Database Library initialized
2013-08-07 17:55:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:37 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:37 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:37 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 17:55:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:38 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:38 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 17:55:38 +03:00 --- debug: Database Library initialized
2013-08-07 17:55:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:38 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:38 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:38 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 17:55:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:38 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:38 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 17:55:38 +03:00 --- debug: Database Library initialized
2013-08-07 17:55:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:39 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:39 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:39 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 17:55:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:39 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:39 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 17:55:39 +03:00 --- debug: Database Library initialized
2013-08-07 17:55:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:39 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:39 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:39 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 17:55:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:40 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:40 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 17:55:40 +03:00 --- debug: Database Library initialized
2013-08-07 17:55:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:40 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:40 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:40 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 17:55:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:40 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:40 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 17:55:40 +03:00 --- debug: Database Library initialized
2013-08-07 17:55:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:59 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:59 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:59 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 17:55:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:59 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:59 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:59 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 17:55:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 17:55:59 +03:00 --- debug: Session Library initialized
2013-08-07 17:55:59 +03:00 --- debug: Auth Library loaded
2013-08-07 17:55:59 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 18:20:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 18:20:55 +03:00 --- debug: Session Library initialized
2013-08-07 18:20:55 +03:00 --- debug: Auth Library loaded
2013-08-07 18:20:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 18:20:55 +03:00 --- debug: Database Library initialized
2013-08-07 18:20:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 18:20:55 +03:00 --- debug: Session Library initialized
2013-08-07 18:20:55 +03:00 --- debug: Auth Library loaded
2013-08-07 18:20:55 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 18:21:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 18:21:00 +03:00 --- debug: Session Library initialized
2013-08-07 18:21:00 +03:00 --- debug: Auth Library loaded
2013-08-07 18:21:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 18:21:00 +03:00 --- debug: Database Library initialized
2013-08-07 18:21:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 18:21:00 +03:00 --- debug: Session Library initialized
2013-08-07 18:21:00 +03:00 --- debug: Auth Library loaded
2013-08-07 18:21:00 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 18:21:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 18:21:02 +03:00 --- debug: Session Library initialized
2013-08-07 18:21:02 +03:00 --- debug: Auth Library loaded
2013-08-07 18:21:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 18:21:02 +03:00 --- debug: Database Library initialized
2013-08-07 18:21:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 18:21:02 +03:00 --- debug: Session Library initialized
2013-08-07 18:21:02 +03:00 --- debug: Auth Library loaded
2013-08-07 18:21:02 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 18:21:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 18:21:02 +03:00 --- debug: Session Library initialized
2013-08-07 18:21:02 +03:00 --- debug: Auth Library loaded
2013-08-07 18:21:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 18:21:02 +03:00 --- debug: Database Library initialized
2013-08-07 18:21:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 18:21:02 +03:00 --- debug: Session Library initialized
2013-08-07 18:21:02 +03:00 --- debug: Auth Library loaded
2013-08-07 18:21:02 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 18:21:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 18:21:06 +03:00 --- debug: Session Library initialized
2013-08-07 18:21:06 +03:00 --- debug: Auth Library loaded
2013-08-07 18:21:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 18:21:06 +03:00 --- debug: Database Library initialized
2013-08-07 18:21:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 18:21:07 +03:00 --- debug: Session Library initialized
2013-08-07 18:21:07 +03:00 --- debug: Auth Library loaded
2013-08-07 18:21:07 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 18:21:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 18:21:07 +03:00 --- debug: Session Library initialized
2013-08-07 18:21:07 +03:00 --- debug: Auth Library loaded
2013-08-07 18:21:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 18:21:07 +03:00 --- debug: Database Library initialized
2013-08-07 18:21:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 18:21:07 +03:00 --- debug: Session Library initialized
2013-08-07 18:21:07 +03:00 --- debug: Auth Library loaded
2013-08-07 18:21:07 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
2013-08-07 18:21:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 18:21:08 +03:00 --- debug: Session Library initialized
2013-08-07 18:21:08 +03:00 --- debug: Auth Library loaded
2013-08-07 18:21:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-07 18:21:08 +03:00 --- debug: Database Library initialized
2013-08-07 18:21:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-07 18:21:08 +03:00 --- debug: Session Library initialized
2013-08-07 18:21:08 +03:00 --- debug: Auth Library loaded
2013-08-07 18:21:08 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, favicon.ico, не найдена. в файле /home/adok/WWW/prupravy.local/system/core/Kohana.php, на строке 862
