<?php include Kohana::find_file('views','header'); ?>
<div class="static_page_content" style="text-align: center;">
	<span style="font-size: xx-large;"><strong>Страница не найдена></strong></span>
</div>
<?php include Kohana::find_file('views','footer'); ?>