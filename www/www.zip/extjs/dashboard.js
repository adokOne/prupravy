Ext.onReady(function(){
	
	Ext.QuickTips.init();
	
	
	
	
	
		
			
			
	
	
});